; ------------------------------------------------------------------------------
; Features — code aggregate
;
; Pulls in each enabled feature's code, allocating it into the regions the
; game config declared. Included once from src/main.asm, after the game
; config — mirrors src/features/macros.asm's aggregation of the config-time
; macro APIs, but gated per feature flag here since a feature's code (unlike
; its macros) must not be assembled unless the build actually enables it.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

IF DEF(_SAVESTATES)
INCLUDE "src/features/savestates/code.asm"
ENDC
IF DEF(_BATTERYLESS)
INCLUDE "src/features/batteryless/code.asm"
ENDC
IF DEF(_NORTC)
INCLUDE "src/features/rtc/code.asm"
ENDC
