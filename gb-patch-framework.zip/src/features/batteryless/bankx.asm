; Game Boy battery-less patching for bootleg cartridges
; based on BennVennElectronic's tutorial (https://www.youtube.com/watch?v=l2bx-udTN84)
; ------------------------------------------------------------------------------------
; see README file
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2024 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------


copy_save_flash_to_sram:
	;copy code from Flash ROM to SRAM, this is executed during game's intercepted boot
	ld		a, CART_SRAM_ENABLE
	ld		[rRAMG], a ;enable SRAM

	xor		a
	ld		[rRAMB], a ;set RAM bank 0
	ld		hl, $4000 ;source (Flash ROM)
	ld		de, _SRAM ;target (SRAM)
	ld		bc, $2000 ;size
	ld		a, flash_data_bank ;set source ROM bank
	call	bank_switch_and_copy_from_flash_to_sram

	IF sram_size_32kb
		;8kb-16kb
		ld		a, 1
		ld		[rRAMB], a ;set RAM bank 1
		;hl is $6000 here
		ld		de, _SRAM ;target (SRAM)
		ld		bc, $2000 ;size
		ld		a, flash_data_bank ;set source ROM bank
		call	bank_switch_and_copy_from_flash_to_sram

		;16kb-24kb
		ld		a, 2
		ld		[rRAMB], a ;set RAM bank 2
		ld		hl, $4000 ;source (Flash ROM)
		ld		de, _SRAM ;target (SRAM)
		ld		bc, $2000 ;size
		ld		a, flash_data_bank + 1 ;set source ROM bank
		call	bank_switch_and_copy_from_flash_to_sram

		;24kb-32kb
		ld		a, 3
		ld		[rRAMB], a ;set RAM bank 3
		;hl is $6000 here
		ld		de, _SRAM ;target (SRAM)
		ld		bc, $2000 ;size
		ld		a, flash_data_bank + 1 ;set source ROM bank
		call	bank_switch_and_copy_from_flash_to_sram
	ENDC

	ld		a, CART_SRAM_DISABLE
	ld		[rRAMG], a ;disable SRAM
	
	ret



;parameters:
; - hl: source
; - de: target
; - bc: size
copy_data:
.loop:
	ld		a, [hli]
	ld		[de], a
	inc		de
	dec		bc
	ld		a, c
	or		b
	jr		nz, .loop
	ret


erase_and_write_ram_banks:
	;safe to be run from ROM, since it will copy the needed subroutines to RAM and call them there
	;reports the outcome in wBootlegType's FLASH_SAVE_FAILED_BIT (set =
	;unsupported cartridge or a flash operation timed out; the save did not
	;persist) for feedback code to surface to the player

	;ld a, BOOTLEG_CARTRIDGE_TYPE
	ld		hl, bootleg_read_identifier
	ld		de, wram_bootleg_read_identifier
	ld		bc, bootleg_read_identifier.end - bootleg_read_identifier
	call	copy_data
	call	wram_bootleg_read_identifier
	ld [wBootlegType], a
	cp a, $0
	jr nz, .bootleg_detected
	;no compatible flash chip: the save only reached SRAM and will not
	;survive a power cycle
	jp .failed
.bootleg_detected

	;erase 64kb block
	ld		hl, erase_one_flash_erase_block
	ld		de, wram_erase_one_flash_erase_block
	ld		bc, erase_one_flash_erase_block.end - erase_one_flash_erase_block
	call	copy_data
	; patch code for bootleg_cartridge_type
	ld a, [wBootlegType]
	bit 1, a
	jr z, .AA_cartridge_1
	ld a, $3
	ld [wram_erase_one_flash_erase_block.set_bootleg_cartridge_swapped_datalines + 1], a
.AA_cartridge_1
	ld a, [wBootlegType]
	bit 2, a
	jr z, .AAA_cartridge_1
	ld		hl, erase_one_flash_erase_block_555_code
	ld		de, wram_erase_one_flash_erase_block.bootleg_code
	ld		bc, erase_one_flash_erase_block_555_code.end - erase_one_flash_erase_block_555_code
	call	copy_data
.AAA_cartridge_1
	; run code from wram
	call	wram_erase_one_flash_erase_block
	nop
	jp		c, .failed ;erase timed out

	;write
	ld		hl, write_sram_to_flash_rom
	ld		de, wram_write_sram_to_flash_rom
	ld		bc, write_sram_to_flash_rom.end - write_sram_to_flash_rom
	call	copy_data
	; patch code for bootleg_cartridge_type
	ld a, [wBootlegType]
	bit 1, a
	jr z, .AA_cartridge_2
	ld a, $3
	ld [wram_write_sram_to_flash_rom.set_bootleg_cartridge_swapped_datalines + 1], a
.AA_cartridge_2
	ld a, [wBootlegType]
	bit 2, a
	jr z, .AAA_cartridge_2
	ld		hl, write_sram_to_flash_rom_555_code
	ld		de, wram_write_sram_to_flash_rom.bootleg_code
	ld		bc, write_sram_to_flash_rom_555_code.end - write_sram_to_flash_rom_555_code
	call	copy_data
.AAA_cartridge_2
	call	wram_write_sram_to_flash_rom
	nop
	jp		c, .failed ;a byte program timed out

	IF sram_size_32kb
		REPT 7 - 1
			nop ;some dummy nops to guarantee correct flashing, might not be needed?
		ENDR

		;8kb-16kb
		;edit subroutine directly in RAM, changing some values
		ld		a, HIGH($6000)
		ld		[wram_write_sram_to_flash_rom.set_destination_offset + 2], a ;destination ROM offset=$6000
		ld		a, 1
		ld		[wram_write_sram_to_flash_rom.set_source_copy_bank + 1], a ;source SRAM bank=1
		call	wram_write_sram_to_flash_rom
		nop
		jp		c, .failed ;a byte program timed out
		REPT 7 - 1
			nop ;some dummy nops to guarantee correct flashing, might not be needed?
		ENDR

		;16kb-24kb
		;edit subroutine directly in RAM, changing some values
		ld		a, flash_data_bank + 1
		ld		[wram_write_sram_to_flash_rom.set_destination_bank + 1], a ;destination ROM bank=flash_data_bank + 1
		ld		a, HIGH($4000)
		ld		[wram_write_sram_to_flash_rom.set_destination_offset + 2], a ;destination ROM offset=$4000
		ld		a, 2
		ld		[wram_write_sram_to_flash_rom.set_source_copy_bank + 1], a ;source SRAM bank=2
		call	wram_write_sram_to_flash_rom
		nop
		jp		c, .failed ;a byte program timed out
		REPT 7 - 1
			nop ;some dummy nops to guarantee correct flashing, might not be needed?
		ENDR

		;24kb-32kb
		;edit subroutine directly in RAM, changing some values
		ld		a, HIGH($6000)
		ld		[wram_write_sram_to_flash_rom.set_destination_offset + 2], a ;destination ROM offset=$6000
		ld		a, 3
		ld		[wram_write_sram_to_flash_rom.set_source_copy_bank + 1], a ;source SRAM bank=3
		call	wram_write_sram_to_flash_rom
		nop
		jp		c, .failed ;a byte program timed out
	ENDC

	ret

.failed:
	ld		a, [wBootlegType]
	set		FLASH_SAVE_FAILED_BIT, a
	ld		[wBootlegType], a
	ret

erase_one_flash_erase_block:
	wram_overlay
wram_erase_one_flash_erase_block:

.set_bootleg_cartridge_swapped_datalines
	ld		b, $0

.set_erase_bank
	ld		a, flash_data_bank
	ld		[rROMB0], a
	nop

	ld		a, $f0
	ld		[$4000], a

.bootleg_code
	ld		a, $aa
	xor		a, b
	ld		[$0aaa], a

	ld		a, $55
	xor		a, b
	ld		[$0555], a
	nop

	ld		a, $80
	ld		[$0aaa], a

	ld		a, $aa
	xor		a, b
	ld		[$0aaa], a

	ld		a, $55
	xor		a, b
	ld		[$0555], a

	nop

	ld		a, $30
	ld		[$4000], a
	nop

	;poll for erase completion, but bounded: a worn-out or misdetected chip
	;must not hang the game forever with interrupts off. Typical NOR sector
	;erase is 0.5-2s (worst case ~10s); one inner-counter round of 65536
	;polls is ~0.8s on DMG, so 24 outer rounds ≈ 20s — beyond any healthy
	;chip. On timeout: reset the chip ($f0) and return with carry set
	;(the tail below is all `ld`s, which preserve carry).
	ld		de, 0
	ld		c, 24
.loop:
	ld		a, [$4000]
	cp		a, $ff
	jr		z, .end ;erased: carry is clear (cp found equality)
	dec		de
	ld		a, d
	or		a, e
	jr		nz, .loop
	dec		c
	jr		nz, .loop
	ld		a, $f0
	ld		[$4000], a
	scf
.end:
	nop

	ld		a, $f0
	ld		[rRAMB], a
	ld		a, FREE_ROMX_BANK
	ld		[rROMB0], a
	ret
	end_wram_overlay
.end




write_sram_to_flash_rom:
	wram_overlay
wram_write_sram_to_flash_rom:
.set_destination_bank:
	ld		a, flash_data_bank
	ld		[rROMB0], a
	ld		hl, _SRAM
.set_destination_offset:
	ld		de, $4000
.loop:
	ld		a, CART_SRAM_ENABLE
	ld		[rRAMG], a ;enable SRAM

	;RTC (not needed?)
	;ld		a, 1
	;ld		[$6000], a
	
.set_source_copy_bank:
	IF sram_size_32kb
		ld		a, $00 ;so we can replace $00 with following block indexes later
	ELSE
		xor		a
	ENDC
	ld		[rRAMB], a
	ld		a, [hl]
	ld		b, a

	xor		a

.set_bootleg_cartridge_swapped_datalines
	ld		c, $0

	;RTC (not needed?)
	;ld		[$6000], a

	ld		[rRAMG], a ;disable SRAM
	ld		a, $f0
	ld		[rRAMB], a

.bootleg_code
	ld		a, $aa
	xor		a, c
	ld		[$0aaa], a

	ld		a, $55
	xor		a, c
	ld		[$0555], a

	nop
	ld		a, $a0
	ld		[$0aaa], a
	nop

	ld		a, b
	ld		[de], a
	;poll for byte-program completion, but bounded: typical NOR byte
	;program is ~10µs (worst case ~ms); 2048 polls ≈ 20ms on DMG is a
	;generous budget. hl (the SRAM source pointer) doubles as the counter
	;while saved on the stack. On timeout: reset the chip and bail out of
	;the whole bank write with carry set (a half-written bank is already
	;lost; continuing byte-by-byte would just take seconds to fail).
	push	hl
	ld		hl, 2048
.verify_loop:
	ld		a, [de]
	xor		b
	jr		z, .byte_done
	dec		hl
	ld		a, h
	or		a, l
	jr		nz, .verify_loop
	ld		a, $f0
	ld		[de], a
	pop		hl
	scf
	jr		.banks
.byte_done:
	pop		hl
	inc		hl
	inc		de
	ld		a, h
	cp		a, $c0
	jr		nz, .loop
	;bank done: carry is clear here (cp found equality)
.banks:
	ld		a, $f0
	ld		[rRAMB], a
	ld		a, FREE_ROMX_BANK
	ld		[rROMB0], a

	ret
	end_wram_overlay
.end

IF DEF(cgb_streaming_savestates)
; Feature 1b: streams a CGB save state's WRAM/VRAM straight to flash instead
; of staging it in dedicated SRAM banks first (see
; src/features/batteryless/cgb_streaming_savestates.asm). Both routines are
; copies of write_sram_to_flash_rom above with the source changed to
; hardware WRAM/VRAM instead of _SRAM — same unlock sequence, same polling,
; same .bootleg_code shape (write_sram_to_flash_rom_555_code, already
; generic, is reused unmodified for the 555-style unlock patch here too).
;
; They run from an hram_overlay, not a wram_overlay: this routine's own
; *source* is WRAM (for write_wram_to_flash_rom) or VRAM (for
; write_vram_to_flash_rom), so if its code lived in a WRAM/VRAM bank it
; would risk reading (and flashing) its own instruction bytes instead of
; the game's real data at that address whenever that exact bank is the one
; being captured. HRAM is disjoint from every WRAM bank and both VRAM
; banks, so this hazard doesn't apply there.
;
; SVBK is switched to the source bank only around the single source-byte
; read (.set_source_bank), then immediately switched back to the pinned
; scratch bank (.set_restore_bank — the caller's stack and scratch live
; there, see the bank discipline note in cgb_streaming_savestates.asm):
; the verify loop below pushes hl on the stack, and a push made while
; SVBK still pointed at the *captured* bank would land in that bank at
; the stack address — scribbling on (and capturing garbage into) every
; WRAM bank except the one the stack really lives in.
;
; a: WRAM(SVBK)/VRAM(VBK) bank to read from (patched into .set_source_bank)

write_wram_to_flash_rom:
	hram_overlay
hram_write_wram_to_flash_rom:
.set_destination_bank:
	ld		a, flash_data_bank
	ld		[rROMB0], a
.set_source_address:
	ld		hl, $c000
.set_destination_offset:
	ld		de, $4000
.loop:
.set_source_bank:
	ld		a, $00 ;so we can replace $00 with the SVBK value later
	ldh		[rSVBK], a
	ld		a, [hl]
	ld		b, a
.set_restore_bank:
	ld		a, $00 ;patched with the pinned scratch bank (see comment above)
	ldh		[rSVBK], a

	xor		a

.set_bootleg_cartridge_swapped_datalines
	ld		c, $0

	ld		[rRAMG], a ;gate the flash chip into command mode
	ld		a, $f0
	ld		[rRAMB], a

.bootleg_code
	ld		a, $aa
	xor		a, c
	ld		[$0aaa], a

	ld		a, $55
	xor		a, c
	ld		[$0555], a

	nop
	ld		a, $a0
	ld		[$0aaa], a
	nop

	ld		a, b
	ld		[de], a
	push	hl
	ld		hl, 2048
.verify_loop:
	ld		a, [de]
	xor		b
	jr		z, .byte_done
	dec		hl
	ld		a, h
	or		a, l
	jr		nz, .verify_loop
	ld		a, $f0
	ld		[de], a
	pop		hl
	scf
	jr		.banks
.byte_done:
	pop		hl
	inc		hl
	inc		de
	ld		a, h
	cp		a, $e0 ;$c000 + $2000 = $e000: WRAM banks are 8kb
	jr		nz, .loop
.banks:
	ld		a, $f0
	ld		[rRAMB], a
	ld		a, FREE_ROMX_BANK
	ld		[rROMB0], a

	ret
	end_hram_overlay
.end

write_vram_to_flash_rom:
	hram_overlay
hram_write_vram_to_flash_rom:
.set_destination_bank:
	ld		a, flash_data_bank
	ld		[rROMB0], a
	ld		hl, $8000
.set_destination_offset:
	ld		de, $4000
.loop:
.set_source_bank:
	ld		a, $00 ;so we can replace $00 with the VBK value later
	ldh		[rVBK], a
	ld		a, [hl]
	ld		b, a

	xor		a

.set_bootleg_cartridge_swapped_datalines
	ld		c, $0

	ld		[rRAMG], a ;gate the flash chip into command mode
	ld		a, $f0
	ld		[rRAMB], a

.bootleg_code
	ld		a, $aa
	xor		a, c
	ld		[$0aaa], a

	ld		a, $55
	xor		a, c
	ld		[$0555], a

	nop
	ld		a, $a0
	ld		[$0aaa], a
	nop

	ld		a, b
	ld		[de], a
	push	hl
	ld		hl, 2048
.verify_loop:
	ld		a, [de]
	xor		b
	jr		z, .byte_done
	dec		hl
	ld		a, h
	or		a, l
	jr		nz, .verify_loop
	ld		a, $f0
	ld		[de], a
	pop		hl
	scf
	jr		.banks
.byte_done:
	pop		hl
	inc		hl
	inc		de
	ld		a, h
	; $8000 + $2000 = $a000: VRAM banks are also 8kb, but start $2000
	; lower than WRAM's window, so the terminator differs from
	; write_wram_to_flash_rom's ($a0, not $e0)
	cp		a, $a0
	jr		nz, .loop
.banks:
	ld		a, $f0
	ld		[rRAMB], a
	ld		a, FREE_ROMX_BANK
	ld		[rROMB0], a

	ret
	end_hram_overlay
.end


; Flashes a small, arbitrary-length linear range (I/O regs, OAM, or a small
; WRAM scratch buffer) — the metadata pieces of a streamed CGB save state
; (magic byte, IO/HRAM, OAM, staged palette/SP bytes; see
; cgb_streaming_savestates.asm). None of these sources are WRAM/VRAM bank
; content, so this runs from the plain wram_overlay (shared with
; write_sram_to_flash_rom and the erase/detect routines above), not
; hram_overlay — no self-overlap risk to avoid here, just the ordinary
; "flash is unreadable as ROM while its own unlock sequence runs" reason
; every flash-write routine in this file needs RAM residency at all.
;
; Terminates by comparing the source pointer against an exact patched end
; address (not a page-boundary high-byte check like the two routines
; above, since I/O's 256-byte range wraps $ff00+256 to $0000, and OAM's
; 160 bytes don't end on a page boundary at all) — 4 bytes of scratch
; (`a`, reused for both halves of the compare) instead of a dedicated
; counter register, since bc's low byte is already spoken for by
; .set_bootleg_cartridge_swapped_datalines every iteration.
write_metadata_range_to_flash_rom:
	wram_overlay
wram_write_metadata_range_to_flash_rom:
.set_destination_bank:
	ld		a, flash_data_bank
	ld		[rROMB0], a
.set_source_address:
	ld		hl, $ff00
.set_destination_offset:
	ld		de, $4000
.loop:
	; plain [hl], NOT [hl+]: .byte_done below already does the `inc hl`
	; (the loop tail is shared with write_sram_to_flash_rom's shape). The
	; original [hl+] advanced the source pointer by TWO per byte on real
	; hardware, so every metadata chunk longer than one byte (IO, OAM,
	; both palettes, SP) flashed every-other-byte garbage — invisible in
	; the smoke test while FlashEmu skipped this routine instead of
	; letting it run natively (it no longer does; see FlashEmu's
	; verify-loop hook in tests/smoke/run.py)
	ld		a, [hl]
	ld		b, a

	xor		a

.set_bootleg_cartridge_swapped_datalines
	ld		c, $0

	ld		[rRAMG], a ;gate the flash chip into command mode
	ld		a, $f0
	ld		[rRAMB], a

.bootleg_code
	ld		a, $aa
	xor		a, c
	ld		[$0aaa], a

	ld		a, $55
	xor		a, c
	ld		[$0555], a

	nop
	ld		a, $a0
	ld		[$0aaa], a
	nop

	ld		a, b
	ld		[de], a
	push	hl
	ld		hl, 2048
.verify_loop:
	ld		a, [de]
	xor		b
	jr		z, .byte_done
	dec		hl
	ld		a, h
	or		a, l
	jr		nz, .verify_loop
	ld		a, $f0
	ld		[de], a
	pop		hl
	scf
	jr		.banks
.byte_done:
	pop		hl
	inc		hl
	inc		de
	ld		a, l
.set_source_end_low:
	cp		a, $00 ;patched: LOW(source start + length)
	jr		nz, .loop
	ld		a, h
.set_source_end_high:
	cp		a, $00 ;patched: HIGH(source start + length)
	jr		nz, .loop
.banks:
	ld		a, $f0
	ld		[rRAMB], a
	ld		a, FREE_ROMX_BANK
	ld		[rROMB0], a

	ret
	end_wram_overlay
.end
ENDC


erase_one_flash_erase_block_555_code:
	ld		a, $aa
	xor		a, b
	ld		[$0555], a

    ld		a, $55
	xor		a, b
    ld		[$02aa], a
	nop

    ld		a, $80
    ld		[$0555], a

    ld		a, $aa
	xor		a, b
    ld		[$0555], a

    ld		a, $55
	xor		a, b
    ld		[$02aa], a
.end

write_sram_to_flash_rom_555_code:
	ld		a, $aa
	xor		a, c
	ld		[$0555], a

	ld		a, $55
	xor		a, c
	ld		[$02aa], a

	nop
	ld		a, $a0
	ld		[$0555], a
	nop
.end

bootleg_read_identifier:
	wram_overlay
wram_bootleg_read_identifier:
	ld a,[$0000]
	ld h,a ; the content of $0000 should not be equal to the manufacturer ids

	; detect WRAAAA9_64KB cart
	ld a,$F0
	ld [$0000],a
	nop
	ld a,$A9
	ld [$0AAA],a
	nop
	ld a,$56
	ld [$0555],a
	nop
	ld a,$90
	ld [$0AAA],a
	nop
	
	ld a,[$0000]
	cp h
	jp z, .not_cartridgetype_WRAAAA9_64KB
	ld a,$F0
	ld [$0000],a
	ld a,WRAAAA9_64KB
	ret
	
	.not_cartridgetype_WRAAAA9_64KB
	; detect 555/A9 cart
	ld a,$F0
	ld [$0000],a
	nop
	ld a,$A9
	nop
	ld [$0555],a
	nop
	ld a,$56
	nop
	ld [$02AA],a
	nop
	ld a,$90
	ld [$0555],a
	nop
	
	ld a,[$0000]
	cp h
	jp z, .not_cartridgetype_WR555A9_64KB
	ld a,$F0
	ld [$0000],a
	ld a,WR555A9_64KB
	ret
	
	.not_cartridgetype_WR555A9_64KB
	
	; detect AAA/AA cart
	ld a,$F0
	ld [$0000],a
	nop
	ld a,$AA
	ld [$0AAA],a
	nop
	ld a,$55
	ld [$0555],a
	nop
	ld a,$90
	ld [$0AAA],a
	nop
	
	ld a,[$0000]
	cp h
	jp z, .not_cartridgetype_WRAAAAA_64KB
	ld a,$F0
	ld [$0000],a
	ld a,WRAAAAA_64KB
	ret
	
	.not_cartridgetype_WRAAAAA_64KB
	
	; detect 555/AA cart
	ld a,$F0
	ld [$0000],a
	nop
	ld a,$AA
	ld [$0555],a
	nop
	ld a,$55
	ld [$02AA],a
	nop
	ld a,$90
	ld [$0555],a
	nop
	
	ld a,[$0000]
	cp h
	jp z, .not_cartridgetype_WR555AA_64KB
	ld a,$F0
	ld [$0000],a
	ld a,WR555AA_64KB
	ret
	
	.not_cartridgetype_WR555AA_64KB
	ld a,$F0
	ld [$0000],a
	ld a,$0 ; no compatible cartridge detected
	ret
	end_wram_overlay
.end
