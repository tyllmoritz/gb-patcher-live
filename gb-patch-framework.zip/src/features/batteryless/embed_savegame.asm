; ------------------------------------------------------------------------------
; Embed a savegame into the flash data banks.
;
; The build system passes -DEMBED_SAVEGAME='"path/to/game.sav"' when a .sav
; file exists next to the original ROM; otherwise an empty savegame is
; embedded so the game finds valid (erased) SRAM contents on first boot.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2024 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

IF !DEF(EMBED_SAVEGAME)
    DEF EMBED_SAVEGAME EQUS "\"src/features/batteryless/empty_savegame.sav\""
ENDC

    SECTION "Flash ROM - Embed savegame (first 16kb)", ROMX[$4000], BANK[flash_data_bank]
    INCBIN EMBED_SAVEGAME, 0, 8192
    IF SRAM_SIZE == CART_SRAM_32KB
        INCBIN EMBED_SAVEGAME, 8192, 8192
        SECTION "Flash ROM - Embed savegame (last 16kb)", ROMX[$4000], BANK[flash_data_bank + 1]
        INCBIN EMBED_SAVEGAME, 16384, 16384
    ENDC
