; ------------------------------------------------------------------------------
; Feature 1b: CGB save states without dedicated SRAM banks
;
; The plain CGB save-state design (save_cgb.asm/load_cgb.asm) stages a state
; in up to 11 dedicated SRAM banks before/after copying it, which needs a
; 128kb SRAM chip. This file replaces that staging with streaming straight
; to/from flash, so a CGB save state fits on a cartridge whose physical SRAM
; chip is only 32kb (game_uses_save_ram 8kb shape) or has none of its own.
; Only built when the game config sets `cgb_streaming_savestates` — see
; FEATURES.md Feature 1b for the full design and the corrections made to it
; while implementing.
;
; Requires _BATTERYLESS (flash is the only place a state can live at all
; once there's no spare SRAM for it — a `_SAVESTATES`-only build combined
; with this flag would have nowhere to put a state).
;
; Ordering note that isn't obvious from the flash layout alone: IO/OAM are
; captured *directly from live hardware* before anything of ours touches
; HRAM, because that capture includes HRAM itself. Only *after* that
; capture is HRAM safe to reuse as scratch for the palette port-reads and
; then for write_wram_to_flash_rom/write_vram_to_flash_rom's own code (see
; write_metadata_range_to_flash_rom's comment in bankx.asm for why the
; flash-write code itself needs RAM residency at all, separately from the
; self-overlap reason HRAM specifically is used for the WRAM/VRAM pieces).
;
; Bank discipline: every wram_scratch byte and wram_overlay routine below
; resolves to a fixed address in FREE_WRAM_BANK, but the joypad hook can
; fire with ANY bank mapped — Metroid II DX runs on SVBK=2 in-game (with
; its stack in banked WRAM) and flips between 0/1/2 even on the title
; screen. Both directions therefore pin SVBK to the scratch bank before
; touching any scratch or overlay, and only hand the game's own bank back
; at the very end. (The first implementation didn't: scratch silently
; landed in whichever bank the game was on, so a save taken on SVBK=2 put
; wHramBackup in bank 2 while the load side read it from bank 1 — the
; final HRAM restore then wrote stale bank-1 bytes over the game's live
; HRAM, including its joypad variables. Save in-game, load, hang.)
;
; SP handling: both directions repoint SP. The save side moves onto the
; reserved scratch stack (wStreamStack) right after snapshotting the
; game's SP — with the scratch bank pinned, pushes on the game's own
; stack would land in the scratch bank at the stack address, scribbling
; on data that isn't ours and getting captured as garbage. The load side
; overwrites every WRAM bank, so it moves through two scratch stacks (see
; restore_streaming_savestate's comment) before finally switching to the
; restored save-time SP. Neither direction needs a large WRAM0 staging
; buffer (a buffer big enough for IO+OAM+both palettes+SP, ~547 bytes,
; would sit inside one of the exact WRAM banks being captured as live game
; data; capturing IO/OAM directly from hardware and staging only the much
; smaller port-read pieces — BG/OBJ palette, 64B each, reused sequentially —
; in HRAM avoids that collision entirely).
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

IF !DEF(_BATTERYLESS)
    FAIL "cgb_streaming_savestates requires _BATTERYLESS — flash is the only place a state can live without dedicated SRAM banks"
ENDC
IF DEF(game_uses_save_ram) && DEF(current_sram_bank)
    FAIL "cgb_streaming_savestates: the 32kb game-SRAM shape (current_sram_bank) isn't implemented yet — only the 8kb game_uses_save_ram shape and no-SRAM-at-all are"
ENDC

; a dedicated, fresh 64kb-aligned flash block — same convention as Feature
; 1's plain-shape SAVESTATE_FLASH_BANK (flash_data_bank + 4), just a
; different bridge (a game only ever uses one savestates bridge shape).
DEF STREAM_FLASH_BANK EQU flash_data_bank + 4

; metadata sub-offsets, all packed into one 8kb slot at STREAM_FLASH_BANK:$4000
DEF STREAM_IO_OFFSET     EQU $4000   ; 256B ($ff00-$ffff, captured whole)
DEF STREAM_OAM_OFFSET    EQU $4100   ; 160B ($fe00-$fe9f)
DEF STREAM_BGPAL_OFFSET  EQU $41a0   ; 64B
DEF STREAM_OBJPAL_OFFSET EQU $41e0   ; 64B
DEF STREAM_SP_OFFSET     EQU $4220   ; 2B
DEF STREAM_MAGIC_OFFSET  EQU $4222   ; 1B — written last, once everything
                                     ; else has landed
DEF STREAM_FLASH_BANK_MAGIC_ADDR EQU STREAM_MAGIC_OFFSET

; WRAM/VRAM 8kb slots — one 64kb block holds all of it:
;   STREAM_FLASH_BANK + 0: metadata ($4000) / WRAM 0+1 ($6000)
;   STREAM_FLASH_BANK + 1: WRAM 2+3 ($4000, two 4kb halves) / WRAM 4+5 ($6000, ditto)
;   STREAM_FLASH_BANK + 2: WRAM 6+7 ($4000, ditto) / VRAM bank 0 ($6000)
;   STREAM_FLASH_BANK + 3: VRAM bank 1 ($4000) / game's own SRAM bank 0 ($6000,
;                          only if game_uses_save_ram)
DEF STREAM_WRAM01_BANK   EQU STREAM_FLASH_BANK + 0
DEF STREAM_WRAM01_OFFSET EQU $6000
DEF STREAM_WRAM23_BANK   EQU STREAM_FLASH_BANK + 1
DEF STREAM_WRAM45_BANK   EQU STREAM_FLASH_BANK + 1
DEF STREAM_WRAM67_BANK   EQU STREAM_FLASH_BANK + 2
DEF STREAM_VRAM0_BANK    EQU STREAM_FLASH_BANK + 2
DEF STREAM_VRAM0_OFFSET  EQU $6000
DEF STREAM_VRAM1_BANK    EQU STREAM_FLASH_BANK + 3
DEF STREAM_VRAM1_OFFSET  EQU $4000
DEF STREAM_SRAM0_BANK    EQU STREAM_FLASH_BANK + 3
DEF STREAM_SRAM0_OFFSET  EQU $6000

; wStreamSPLow/wStreamSPHigh/wStreamMagicByte (persistent WRAM scratch —
; survive the wram_overlay/hram_overlay routines coming and going, for the
; 2-byte SP snapshot and the 1-byte magic-byte staging) are reserved in
; code.asm, before bankx.asm's own wram_overlay uses — see the comment
; there for why the ordering matters.

; A plain data buffer for the palette port-reads and the flash-side SP/
; magic-byte staging, reusing the same HRAM window hram_overlay's routines
; occupy — safe because it's only ever used *before* those routines become
; resident (see the ordering note above), never at the same time.
DEF hHramScratch EQU FREE_HRAM_START

; the bank all scratch/overlay accesses are pinned to (see the bank
; discipline note in the header) — used by both directions
IF DEF(FREE_WRAM_BANK)
    DEF STREAM_SCRATCH_SVBK EQU FREE_WRAM_BANK
ELSE
    DEF STREAM_SCRATCH_SVBK EQU 1  ; scratch is in WRAM0; any bank works
ENDC

; ---- hardware-bisection instrumentation (stream_debug builds only) -----
;
; PyBoy can't emulate the flash chip's timing, its unlock sequences, or
; the CGB's double-speed cartridge bus (Metroid II DX switches to double
; speed at boot), so a failure that only happens on a real cartridge has
; to be bisected on the real cartridge. The screen is off for the whole
; save/load, which leaves exactly one feedback channel: the speaker.
;
; A stream_debug build beeps N times after stage N completes (the count
; tells you the LAST stage that finished) and plays one long low buzz on
; the .failed path or when a load finds no state in flash. Note an erase
; or byte-program that times out sits silent for up to ~10-20 seconds
; before its buzz — wait for it before pulling power.
;
;   save (Select+A):  1 hook reached   2 chip detected   3 erase done
;                     4 metadata done  5 WRAM done        6 VRAM done
;                     7 SRAM done      8 magic written = save complete
;   load (Select+B):  1 state found (commit point)  2 OAM/IO/palettes
;                     3 WRAM restored  4 VRAM+SRAM restored
;                     5 restore complete (resuming the game)
;
; The checkpoints deliberately clobber only a/b/d/e and the channel-1
; sound registers (the IO capture on the save side runs after checkpoints
; 1-3, so a saved state carries the debug NR values — harmless, and the
; load side doesn't restore $ff10-$ff26 at all). Each call uses 4 bytes
; of the active stack, which every insertion point has to spare.
MACRO stream_checkpoint ; N
IF DEF(stream_debug)
    ld      a, \1
    call    stream_debug_beeps
ENDC
ENDM

MACRO stream_checkpoint_fail
IF DEF(stream_debug)
    call    stream_debug_fail_buzz
ENDC
ENDM

IF DEF(stream_debug)
stream_debug_beeps:  ; a = beep count; clobbers a/b/d/e + channel-1 regs
    ld      b, a
    call    .sound_on
.one:
    ld      a, $80              ; 50% duty
    ldh     [rNR11], a
    ld      a, $f0              ; full volume, no envelope
    ldh     [rNR12], a
    ld      a, LOW(1900)        ; ~886 Hz
    ldh     [rNR13], a
    ld      a, $80 | HIGH(1900) ; trigger
    ldh     [rNR14], a
    ld      de, $8000
    call    .delay
    xor     a
    ldh     [rNR12], a          ; DAC off = silence
    ld      de, $4000
    call    .delay
    dec     b
    jr      nz, .one
    ld      de, $c000           ; longer gap separates checkpoint groups
.delay:
    dec     de
    ld      a, d
    or      a, e
    jr      nz, .delay
    ret
.sound_on:
    ld      a, $80
    ldh     [rNR52], a
    ld      a, $ff
    ldh     [rNR51], a
    ld      a, $77
    ldh     [rNR50], a
    xor     a
    ldh     [rNR10], a
    ret

stream_debug_fail_buzz:  ; one long low buzz; clobbers a/b/d/e
    call    stream_debug_beeps.sound_on
    ld      a, $80
    ldh     [rNR11], a
    ld      a, $f0
    ldh     [rNR12], a
    ld      a, LOW(1048)        ; ~131 Hz
    ldh     [rNR13], a
    ld      a, $80 | HIGH(1048)
    ldh     [rNR14], a
    ld      de, $0000           ; full 65536 rounds ≈ 0.5-1s
    call    stream_debug_beeps.delay
    xor     a
    ldh     [rNR12], a
    ret
ENDC


; ---- save direction ----------------------------------------------------

; The .hook_* labels on the flash-touching call instructions below (and in
; persist_streaming_savestate_to_flash) are for the smoke test only: PyBoy
; can't emulate a bootleg flash chip, so tests/smoke/run.py hooks these
; exact addresses and emulates each flash operation (see FlashEmu there).
; They cost zero bytes and have no runtime effect.
MACRO flash_metadata_chunk ; SRC_ADDR, LEN, FLASH_OFFSET
    ld      a, LOW(\1)
    ld      [wram_write_metadata_range_to_flash_rom.set_source_address + 1], a
    ld      a, HIGH(\1)
    ld      [wram_write_metadata_range_to_flash_rom.set_source_address + 2], a
    ld      a, LOW((\1) + (\2))
    ld      [wram_write_metadata_range_to_flash_rom.set_source_end_low + 1], a
    ld      a, HIGH((\1) + (\2))
    ld      [wram_write_metadata_range_to_flash_rom.set_source_end_high + 1], a
    ld      a, STREAM_FLASH_BANK
    ld      [wram_write_metadata_range_to_flash_rom.set_destination_bank + 1], a
    ; both offset bytes: several chunks ($41a0, $4220, ...) don't start on
    ; a page boundary, so patching only HIGH would collapse them onto $xx00
    ld      a, LOW(\3)
    ld      [wram_write_metadata_range_to_flash_rom.set_destination_offset + 1], a
    ld      a, HIGH(\3)
    ld      [wram_write_metadata_range_to_flash_rom.set_destination_offset + 2], a
.hook_flash_metadata\@:
    call    wram_write_metadata_range_to_flash_rom
    nop
    jp      c, .failed
ENDM

MACRO flash_wram_pair_half ; SVBK, SOURCE_ADDR, FLASH_BANK, FLASH_OFFSET
    ld      a, \1
    ld      [hram_write_wram_to_flash_rom.set_source_bank + 1], a
    ld      a, HIGH(\2)
    ld      [hram_write_wram_to_flash_rom.set_source_address + 2], a
    ld      a, \3
    ld      [hram_write_wram_to_flash_rom.set_destination_bank + 1], a
    ld      a, HIGH(\4)
    ld      [hram_write_wram_to_flash_rom.set_destination_offset + 2], a
.hook_flash_wram\@:
    call    hram_write_wram_to_flash_rom
    nop
    jp      c, .failed
ENDM

MACRO flash_vram_bank ; VBK, FLASH_BANK, FLASH_OFFSET
    ld      a, \1
    ld      [hram_write_vram_to_flash_rom.set_source_bank + 1], a
    ld      a, \2
    ld      [hram_write_vram_to_flash_rom.set_destination_bank + 1], a
    ld      a, HIGH(\3)
    ld      [hram_write_vram_to_flash_rom.set_destination_offset + 2], a
.hook_flash_vram\@:
    call    hram_write_vram_to_flash_rom
    nop
    jp      c, .failed
ENDM

; Backs up the borrowed HRAM window to WRAM / restores it afterward — see
; the wram_scratch_block call in code.asm. Call backup_hram_to_wram once,
; right before the first thing in a sequence uses HRAM as scratch or code
; (the palette capture/restore buffer, or hram_overlay's routines), and
; restore_wram_to_hram once, right after the last.
backup_hram_to_wram:
    ld      hl, FREE_HRAM_START
    ld      de, wHramBackup
    ld      bc, FREE_HRAM_END - FREE_HRAM_START
    jp      copy_data

restore_wram_to_hram:
    ld      hl, wHramBackup
    ld      de, FREE_HRAM_START
    ld      bc, FREE_HRAM_END - FREE_HRAM_START
    jp      copy_data

; Reads one palette (BG or OBJ) via its port into the HRAM scratch buffer —
; same protocol as save_cgb.asm's save_palette, just targeting HRAM instead
; of a dedicated SRAM bank. Runs from ROM0/ROMX directly: it never touches
; the flash chip's command lines, so it has none of the RAM-residency
; requirements the flash-write routines do.
; @param hl palette control address ($ff68 BG / $ff6a OBJ)
; @param c  low byte of the palette data port ($69 BG / $6b OBJ)
; @param de destination (HRAM scratch)
capture_palette_to_hram:
    xor     a
    ld      [hl], a
    ld      b, 64
.loop:
    ldh     a, [c]
    ld      [de], a
    inc     de
    inc     [hl]
    dec     b
    jr      nz, .loop
    ret

; Called from SAVE_GAME (load_and_save.asm) with the screen still off (the
; PPU must be idle: OAM, VRAM and palette RAM are captured from live
; hardware below, and none of them read reliably while the LCD is running).
; Captures and flashes every piece of a CGB save state.
persist_streaming_savestate_to_flash:
    di
    ; snapshot the game's live SVBK, then pin the scratch bank BEFORE the
    ; first scratch write (wStreamSVBK itself is scratch — writing it
    ; while the game's own bank is still mapped would put it in the wrong
    ; bank, the exact bug the bank-discipline header note describes). The
    ; snapshot serves double duty: the capture cycles SVBK/VBK through
    ; every bank and must hand back the ones the game was actually on.
    ldh     a, [rSVBK]
    and     a, $07
    ld      b, a
    ld      a, STREAM_SCRATCH_SVBK
    ldh     [rSVBK], a
    ld      a, b
    ld      [wStreamSVBK], a
    ldh     a, [rVBK]
    and     a, $01
    ld      [wStreamVBK], a

    ; snapshot the game's SP (the restore resumes on it — it points at the
    ; return address back into SAVE_GAME), then move onto the reserved
    ; scratch stack: the game's stack lives in the game's own SVBK bank,
    ; and with the scratch bank pinned every push here would land in the
    ; scratch bank at the stack address instead. No registers need
    ; preserving across this routine — the joypad hook already pushed them
    ; onto the game's stack, where the capture below records them.
    ld      [wStreamSPLow], sp
    ld      sp, wStreamStackTop
    stream_checkpoint 1

    ; back up the borrowed HRAM window right away — reading it is free, and
    ; doing it this early means every .failed exit below can restore it
    ; unconditionally (a failure while flash code was resident in HRAM used
    ; to hand the game back its HRAM full of our instruction bytes)
    call    backup_hram_to_wram

    ; bootleg cartridge detection, shared by every write below (same
    ; pattern as erase_and_write_ram_banks/erase_and_write_savestate_banks)
    ld      hl, bootleg_read_identifier
    ld      de, wram_bootleg_read_identifier
    ld      bc, bootleg_read_identifier.end - bootleg_read_identifier
    call    copy_data
.hook_detect:
    call    wram_bootleg_read_identifier
    ld      [wBootlegType], a
    cp      a, $0
    jp      z, .failed  ; no bootleg cartridge — the state won't survive power-off
    stream_checkpoint 2

    ; erase STREAM_FLASH_BANK's block once, up front (every chunk below
    ; lands in this one 64kb block)
    ld      hl, erase_one_flash_erase_block
    ld      de, wram_erase_one_flash_erase_block
    ld      bc, erase_one_flash_erase_block.end - erase_one_flash_erase_block
    call    copy_data
    ld      a, [wBootlegType]
    bit     1, a
    jr      z, .aa_cartridge_1
    ld      a, $3
    ld      [wram_erase_one_flash_erase_block.set_bootleg_cartridge_swapped_datalines + 1], a
.aa_cartridge_1
    ld      a, STREAM_FLASH_BANK
    ld      [wram_erase_one_flash_erase_block.set_erase_bank + 1], a
    ld      a, [wBootlegType]
    bit     2, a
    jr      z, .aaa_cartridge_1
    ld      hl, erase_one_flash_erase_block_555_code
    ld      de, wram_erase_one_flash_erase_block.bootleg_code
    ld      bc, erase_one_flash_erase_block_555_code.end - erase_one_flash_erase_block_555_code
    call    copy_data
.aaa_cartridge_1
.hook_erase:
    call    wram_erase_one_flash_erase_block
    nop
    jp      c, .failed  ; erase timed out
    stream_checkpoint 3

    ; --- metadata: IO/HRAM and OAM captured directly, before we ever touch
    ; HRAM ourselves ---
    ld      hl, write_metadata_range_to_flash_rom
    ld      de, wram_write_metadata_range_to_flash_rom
    ld      bc, write_metadata_range_to_flash_rom.end - write_metadata_range_to_flash_rom
    call    copy_data
    ld      a, [wBootlegType]
    bit     1, a
    jr      z, .aa_cartridge_2
    ld      a, $3
    ld      [wram_write_metadata_range_to_flash_rom.set_bootleg_cartridge_swapped_datalines + 1], a
.aa_cartridge_2
    ld      a, [wBootlegType]
    bit     2, a
    jr      z, .aaa_cartridge_2
    ld      hl, write_sram_to_flash_rom_555_code
    ld      de, wram_write_metadata_range_to_flash_rom.bootleg_code
    ld      bc, write_sram_to_flash_rom_555_code.end - write_sram_to_flash_rom_555_code
    call    copy_data
.aaa_cartridge_2

    flash_metadata_chunk $ff00, 256, STREAM_IO_OFFSET
    flash_metadata_chunk $fe00, 160, STREAM_OAM_OFFSET

    ; --- palettes: HRAM is safe to use as scratch now (the IO chunk above
    ; already flashed its real content, and it was backed up to wHramBackup
    ; at entry); restored below once the last hram-resident routine (VRAM)
    ; is done with it
    ld      hl, $ff68
    ld      c, $69
    ld      de, hHramScratch
    call    capture_palette_to_hram
    flash_metadata_chunk hHramScratch, 64, STREAM_BGPAL_OFFSET

    ld      hl, $ff6a
    ld      c, $6b
    ld      de, hHramScratch
    call    capture_palette_to_hram
    flash_metadata_chunk hHramScratch, 64, STREAM_OBJPAL_OFFSET

    ; --- SP, captured at the very top of this routine ---
    flash_metadata_chunk wStreamSPLow, 2, STREAM_SP_OFFSET
    stream_checkpoint 4

    ; --- WRAM pairs: HRAM now holds write_wram_to_flash_rom instead ---
    ld      hl, write_wram_to_flash_rom
    ld      de, hram_write_wram_to_flash_rom
    ld      bc, write_wram_to_flash_rom.end - write_wram_to_flash_rom
    call    copy_data
    ld      a, [wBootlegType]
    bit     1, a
    jr      z, .aa_cartridge_3
    ld      a, $3
    ld      [hram_write_wram_to_flash_rom.set_bootleg_cartridge_swapped_datalines + 1], a
.aa_cartridge_3
    ld      a, [wBootlegType]
    bit     2, a
    jr      z, .aaa_cartridge_3
    ld      hl, write_sram_to_flash_rom_555_code
    ld      de, hram_write_wram_to_flash_rom.bootleg_code
    ld      bc, write_sram_to_flash_rom_555_code.end - write_sram_to_flash_rom_555_code
    call    copy_data
.aaa_cartridge_3
    ; the bank the routine switches back to after every source-byte read —
    ; the pinned scratch bank, where this save's stack and scratch live —
    ; so its stack pushes land in the right bank and SVBK is back on the
    ; scratch bank the moment each capture returns (see .set_restore_bank's
    ; comment in bankx.asm)
    ld      a, STREAM_SCRATCH_SVBK
    ld      [hram_write_wram_to_flash_rom.set_restore_bank + 1], a

    flash_wram_pair_half 1, $c000, STREAM_WRAM01_BANK, STREAM_WRAM01_OFFSET
    flash_wram_pair_half 2, $d000, STREAM_WRAM23_BANK, $4000
    flash_wram_pair_half 3, $d000, STREAM_WRAM23_BANK, $5000
    flash_wram_pair_half 4, $d000, STREAM_WRAM45_BANK, $6000
    flash_wram_pair_half 5, $d000, STREAM_WRAM45_BANK, $7000
    flash_wram_pair_half 6, $d000, STREAM_WRAM67_BANK, $4000
    flash_wram_pair_half 7, $d000, STREAM_WRAM67_BANK, $5000
    stream_checkpoint 5

    ; --- VRAM banks: HRAM now holds write_vram_to_flash_rom instead ---
    ld      hl, write_vram_to_flash_rom
    ld      de, hram_write_vram_to_flash_rom
    ld      bc, write_vram_to_flash_rom.end - write_vram_to_flash_rom
    call    copy_data
    ld      a, [wBootlegType]
    bit     1, a
    jr      z, .aa_cartridge_4
    ld      a, $3
    ld      [hram_write_vram_to_flash_rom.set_bootleg_cartridge_swapped_datalines + 1], a
.aa_cartridge_4
    ld      a, [wBootlegType]
    bit     2, a
    jr      z, .aaa_cartridge_4
    ld      hl, write_sram_to_flash_rom_555_code
    ld      de, hram_write_vram_to_flash_rom.bootleg_code
    ld      bc, write_sram_to_flash_rom_555_code.end - write_sram_to_flash_rom_555_code
    call    copy_data
.aaa_cartridge_4

    flash_vram_bank 0, STREAM_VRAM0_BANK, STREAM_VRAM0_OFFSET
    flash_vram_bank 1, STREAM_VRAM1_BANK, STREAM_VRAM1_OFFSET
    stream_checkpoint 6

    ; (HRAM still holds the VRAM-capture code and VBK is still 1 here —
    ; both are handed back in the shared .exit tail below; nothing between
    ; here and there reads either)

    ; --- the game's own SRAM (8kb game_uses_save_ram shape only) ---
IF DEF(game_uses_save_ram)
    ld      hl, write_sram_to_flash_rom
    ld      de, wram_write_sram_to_flash_rom
    ld      bc, write_sram_to_flash_rom.end - write_sram_to_flash_rom
    call    copy_data
    ld      a, [wBootlegType]
    bit     1, a
    jr      z, .aa_cartridge_5
    ld      a, $3
    ld      [wram_write_sram_to_flash_rom.set_bootleg_cartridge_swapped_datalines + 1], a
.aa_cartridge_5
    ld      a, [wBootlegType]
    bit     2, a
    jr      z, .aaa_cartridge_5
    ld      hl, write_sram_to_flash_rom_555_code
    ld      de, wram_write_sram_to_flash_rom.bootleg_code
    ld      bc, write_sram_to_flash_rom_555_code.end - write_sram_to_flash_rom_555_code
    call    copy_data
.aaa_cartridge_5
    ld      a, STREAM_SRAM0_BANK
    ld      [wram_write_sram_to_flash_rom.set_destination_bank + 1], a
    ld      a, HIGH(STREAM_SRAM0_OFFSET)
    ld      [wram_write_sram_to_flash_rom.set_destination_offset + 2], a
    ; NO .set_source_copy_bank patch: in the 8kb shape (the only one this
    ; bridge supports) that label is `xor a` — a one-byte instruction with
    ; no operand. Patching "+1" here used to overwrite the opcode of the
    ; following `ld [rRAMB],a` with $00, so the routine never selected
    ; SRAM bank 0 and instead captured whatever bank the joypad hook had
    ; left mapped — garbage/aliased data that a later savestate LOAD then
    ; wrote back over the game's real save. The unpatched `xor a` +
    ; `ld [rRAMB],a` already select bank 0.
.hook_flash_sram:
    call    wram_write_sram_to_flash_rom
    nop
    jp      c, .failed
    stream_checkpoint 7
ENDC

    ; magic byte last, once every other chunk has landed — see FEATURES.md
    ; Feature 1b step 8 for why (a power loss mid-save must leave the
    ; *previous* complete state loadable, not a mix of old/new chunks).
    ;
    ; The metadata routine MUST be re-copied here: every wram_overlay
    ; routine unions at the same WRAM base, and the SRAM write above just
    ; evicted it with write_sram_to_flash_rom. Without this re-copy the
    ; magic chunk patches and calls SRAM-shaped code — which happens to
    ; write the magic byte (the source/dest operand offsets coincide) but
    ; then runs away: its terminator compares H against $c0, which a
    ; source pointer starting at wStreamMagicByte only reaches after
    ; wrapping through the whole address space, flashing ~57k garbage
    ; bytes and (once DE crosses $8000) scribbling on VRAM/WRAM/IO/HRAM.
    ; On hardware this was the "save beeps 7 times, never 8, machine
    ; dead afterwards" failure, and the cartridge dump shows its trail
    ; right after the magic offset.
    ld      hl, write_metadata_range_to_flash_rom
    ld      de, wram_write_metadata_range_to_flash_rom
    ld      bc, write_metadata_range_to_flash_rom.end - write_metadata_range_to_flash_rom
    call    copy_data
    ld      a, [wBootlegType]
    bit     1, a
    jr      z, .aa_cartridge_6
    ld      a, $3
    ld      [wram_write_metadata_range_to_flash_rom.set_bootleg_cartridge_swapped_datalines + 1], a
.aa_cartridge_6
    ld      a, [wBootlegType]
    bit     2, a
    jr      z, .aaa_cartridge_6
    ld      hl, write_sram_to_flash_rom_555_code
    ld      de, wram_write_metadata_range_to_flash_rom.bootleg_code
    ld      bc, write_sram_to_flash_rom_555_code.end - write_sram_to_flash_rom_555_code
    call    copy_data
.aaa_cartridge_6
    ld      a, magic_byte_value
    ld      [wStreamMagicByte], a
    flash_metadata_chunk wStreamMagicByte, 1, STREAM_MAGIC_OFFSET
    stream_checkpoint 8

.exit:
    ; shared success/failure exit. Hand everything back in dependency
    ; order: the game's VRAM bank (the VRAM capture ends on VBK=1; a
    ; no-op when a failure came before it — wStreamVBK still holds the
    ; live value), its real HRAM bytes (flash-write code may be resident
    ; in the window; the backup was taken at entry so this is always
    ; safe), then — after the last scratch read, since wStream* is only
    ; visible while the scratch bank is mapped — its own SVBK and stack.
    ld      a, [wStreamVBK]
    ldh     [rVBK], a
    call    restore_wram_to_hram
    ld      a, [wStreamSPLow]
    ld      l, a
    ld      a, [wStreamSPHigh]
    ld      h, a
    ld      a, [wStreamSVBK]
    ldh     [rSVBK], a
    ld      sp, hl
    IF flash_save_enables_ime
    reti
    ELSE
    ret
    ENDC

.failed:
    stream_checkpoint_fail
    ld      a, [wBootlegType]
    set     FLASH_SAVE_FAILED_BIT, a
    ld      [wBootlegType], a
    jr      .exit


; ---- load direction ------------------------------------------------------

; Reads the flash-resident magic byte, running from WRAM like
; read_savestate_magic_byte in savestates_bridge.asm and for the same
; reason (this routine lives in ROMX and would evict itself the instant
; its own ROMB0 switch took effect if it ran inline there).
read_streaming_magic_byte:
    wram_overlay
wram_read_streaming_magic_byte:
    ld      a, STREAM_FLASH_BANK
    ld      [rROMB0], a
    ld      a, [STREAM_FLASH_BANK_MAGIC_ADDR]
    push    af
    ld      a, BANK(copy_save_flash_to_sram)
    ld      [rROMB0], a
    pop     af
    ret
    end_wram_overlay
.end

; Called from LOAD_GAME (load_and_save.asm). Sets zero flag iff a state is
; present in flash (magic byte matches) — mirrors the plain SRAM check but
; reads flash instead. Pins the scratch bank around the overlay copy+call
; (bank discipline, see the header note): this runs before the load's
; commit point, so on the no-state path the game resumes — copying overlay
; code into whatever bank it happened to be on would corrupt live data.
check_streaming_savestate_present:
    ldh     a, [rSVBK]
    push    af
    ld      a, STREAM_SCRATCH_SVBK
    ldh     [rSVBK], a
    ld      hl, read_streaming_magic_byte
    ld      de, wram_read_streaming_magic_byte
    ld      bc, read_streaming_magic_byte.end - read_streaming_magic_byte
    call    copy_data
    call    wram_read_streaming_magic_byte
    ld      b, a
    pop     af
    ldh     [rSVBK], a
    ld      a, b
    cp      magic_byte_value
    ret

; Restores every piece of a CGB save state from flash directly into live
; hardware. bank_switch_and_copy_from_flash_to_sram (rom0.asm) already
; takes an arbitrary destination and runs from ROM0, so restoring needs no
; new routines at all — just call sites with different destinations.
;
; Entered via `jp` from LOAD_GAME's streaming branch and NEVER RETURNS: it
; ends by switching to the restored stack and jumping into ABORT_LOAD,
; whose closing `ret` resumes the call chain that was live at save time.
; It can't be an ordinary `call`ed subroutine — the WRAM restore below
; overwrites all eight banks, including wherever the current stack (and
; with it any pending return address) happens to live.
;
; For the same reason the work is split into two phases, each running on a
; scratch stack that its own phase doesn't overwrite:
;   phase 1 (OAM/IO/palettes — touches no WRAM): stack in wStreamStack,
;     the reserved scratch-WRAM block; the game's own stack can't be used
;     even here, because it may live in HRAM, which the IO restore
;     overwrites mid-copy.
;   phase 2 (WRAM/VRAM/SRAM — overwrites all WRAM): stack at the top of
;     the borrowed HRAM window, which is stable scratch by then (its
;     restored bytes were backed up to wHramBackup at the end of phase 1;
;     the WRAM restore rewrites wHramBackup itself, but with the save-time
;     backup of the very same game HRAM bytes, so the final
;     restore_wram_to_hram still puts back exactly the right content).
;
; SVBK/VBK are applied *last*, from the flash image: the IO restore writes
; the saved $ff70/$ff4f early, but the WRAM/VRAM copy loops afterwards
; cycle both registers through every bank, so those early writes get
; clobbered and must be re-applied once nothing switches banks anymore
; (resuming the game on SVBK=7/VBK=1 instead of its own banks was one of
; the ways a load ended in a hang).
restore_streaming_savestate:
    ; commit point: from here on the current machine state is discarded
    ; piece by piece — map the scratch bank and move onto the phase-1 stack
    ld      a, STREAM_SCRATCH_SVBK
    ldh     [rSVBK], a
    ld      sp, wStreamStackTop
    stream_checkpoint 1

    ; OAM (its own chunk, no DMA-register hazard — plain sprite memory)
    ld      hl, STREAM_OAM_OFFSET
    ld      de, $fe00
    ld      bc, 160
    ld      a, STREAM_FLASH_BANK
    call    bank_switch_and_copy_from_flash_to_sram

    ; IO, split exactly like LOAD_GAME's own restore to skip $ff46 (OAM DMA
    ; trigger) and $ff55 (HDMA5) — see load_and_save.asm's is_cgb branch.
    ; (The $ff56-$ffff range includes IE at $ffff, but the capture ran
    ; inside the joypad hook's IE=0 window, so the image always has IE=0 —
    ; the hook's own epilogue restores the real IE from the restored stack.)
    ld      hl, STREAM_IO_OFFSET + 1
    ld      de, $ff01
    ld      bc, 15
    ld      a, STREAM_FLASH_BANK
    call    bank_switch_and_copy_from_flash_to_sram

    ld      hl, STREAM_IO_OFFSET + $40
    ld      de, $ff40
    ld      bc, 6
    ld      a, STREAM_FLASH_BANK
    call    bank_switch_and_copy_from_flash_to_sram

    ld      hl, STREAM_IO_OFFSET + $47
    ld      de, $ff47
    ld      bc, $ff54 - $ff47 + 1
    ld      a, STREAM_FLASH_BANK
    call    bank_switch_and_copy_from_flash_to_sram

    ld      hl, STREAM_IO_OFFSET + $56
    ld      de, $ff56
    ld      bc, $ffff - $ff56 + 1
    ld      a, STREAM_FLASH_BANK
    call    bank_switch_and_copy_from_flash_to_sram

    ; that last range covered $ff70 (SVBK) — re-pin the scratch bank, our
    ; phase-1 stack lives there; the saved SVBK is re-applied at the end
    ld      a, STREAM_SCRATCH_SVBK
    ldh     [rSVBK], a

    ; the IO restore above already wrote the saved state's real HRAM bytes
    ; into place (the $ff56-$ffff range covers $ff80-$fffe) — back them up
    ; before using HRAM as scratch for the palette staging below and the
    ; phase-2 stack, so they land back correctly once we're done
    call    backup_hram_to_wram

    ; palettes, via HRAM scratch (flash -> HRAM -> port write, mirroring
    ; load_cgb.asm's load_palette protocol)
    ld      hl, STREAM_BGPAL_OFFSET
    ld      de, hHramScratch
    ld      bc, 64
    ld      a, STREAM_FLASH_BANK
    call    bank_switch_and_copy_from_flash_to_sram
    ld      c, $68
    ld      hl, hHramScratch
    call    restore_palette_from_hram

    ld      hl, STREAM_OBJPAL_OFFSET
    ld      de, hHramScratch
    ld      bc, 64
    ld      a, STREAM_FLASH_BANK
    call    bank_switch_and_copy_from_flash_to_sram
    ld      c, $6a
    ld      hl, hHramScratch
    call    restore_palette_from_hram
    stream_checkpoint 2

    ; phase 2: the WRAM restore below overwrites the phase-1 stack (it's
    ; WRAM like everything else) — move to the top of the HRAM window
    ld      sp, FREE_HRAM_END

    ; WRAM pairs, direct to their live windows
    ld      a, 1
    ldh     [rSVBK], a
    ld      hl, STREAM_WRAM01_OFFSET
    ld      de, $c000
    ld      bc, $2000
    ld      a, STREAM_WRAM01_BANK
    call    bank_switch_and_copy_from_flash_to_sram

    ld      a, 2
    ldh     [rSVBK], a
    ld      hl, $4000
    ld      de, $d000
    ld      bc, $1000
    ld      a, STREAM_WRAM23_BANK
    call    bank_switch_and_copy_from_flash_to_sram
    ld      a, 3
    ldh     [rSVBK], a
    ld      hl, $5000
    ld      de, $d000
    ld      bc, $1000
    ld      a, STREAM_WRAM23_BANK
    call    bank_switch_and_copy_from_flash_to_sram

    ld      a, 4
    ldh     [rSVBK], a
    ld      hl, $6000
    ld      de, $d000
    ld      bc, $1000
    ld      a, STREAM_WRAM45_BANK
    call    bank_switch_and_copy_from_flash_to_sram
    ld      a, 5
    ldh     [rSVBK], a
    ld      hl, $7000
    ld      de, $d000
    ld      bc, $1000
    ld      a, STREAM_WRAM45_BANK
    call    bank_switch_and_copy_from_flash_to_sram

    ld      a, 6
    ldh     [rSVBK], a
    ld      hl, $4000
    ld      de, $d000
    ld      bc, $1000
    ld      a, STREAM_WRAM67_BANK
    call    bank_switch_and_copy_from_flash_to_sram
    ld      a, 7
    ldh     [rSVBK], a
    ld      hl, $5000
    ld      de, $d000
    ld      bc, $1000
    ld      a, STREAM_WRAM67_BANK
    call    bank_switch_and_copy_from_flash_to_sram
    stream_checkpoint 3

    ; VRAM banks
    xor     a
    ldh     [rVBK], a
    ld      hl, STREAM_VRAM0_OFFSET
    ld      de, $8000
    ld      bc, $2000
    ld      a, STREAM_VRAM0_BANK
    call    bank_switch_and_copy_from_flash_to_sram

    ld      a, 1
    ldh     [rVBK], a
    ld      hl, STREAM_VRAM1_OFFSET
    ld      de, $8000
    ld      bc, $2000
    ld      a, STREAM_VRAM1_BANK
    call    bank_switch_and_copy_from_flash_to_sram

IF DEF(game_uses_save_ram)
    ld      a, CART_SRAM_ENABLE
    ld      [rRAMG], a
    xor     a
    ld      [rRAMB], a
    ld      hl, STREAM_SRAM0_OFFSET
    ld      de, _SRAM
    ld      bc, $2000
    ld      a, STREAM_SRAM0_BANK
    call    bank_switch_and_copy_from_flash_to_sram
    ld      a, CART_SRAM_DISABLE
    ld      [rRAMG], a
ENDC
    stream_checkpoint 4

    ; read the captured SP and the saved SVBK/VBK bytes (from the IO chunk)
    ; into HRAM scratch — the last flash reads of the restore
    ld      hl, STREAM_SP_OFFSET
    ld      de, hHramScratch
    ld      bc, 2
    ld      a, STREAM_FLASH_BANK
    call    bank_switch_and_copy_from_flash_to_sram
    ld      hl, STREAM_IO_OFFSET + $70
    ld      de, hHramScratch + 2
    ld      bc, 1
    ld      a, STREAM_FLASH_BANK
    call    bank_switch_and_copy_from_flash_to_sram
    ld      hl, STREAM_IO_OFFSET + $4f
    ld      de, hHramScratch + 3
    ld      bc, 1
    ld      a, STREAM_FLASH_BANK
    call    bank_switch_and_copy_from_flash_to_sram

    ; stage the saved SVBK/VBK in scratch WRAM: the HRAM restore below
    ; wipes hHramScratch (writing into the just-restored bank-1 window
    ; scribbles only on our own reserved region — nothing of the game's)
    ld      a, STREAM_SCRATCH_SVBK
    ldh     [rSVBK], a
    ld      a, [hHramScratch + 2]
    ld      [wStreamSVBK], a
    ld      a, [hHramScratch + 3]
    ld      [wStreamVBK], a

    ; switch to the restored stack: pushes from here on land below the
    ; saved SP — memory that was already dead at save time
    ld      a, [hHramScratch]
    ld      l, a
    ld      a, [hHramScratch + 1]
    ld      h, a
    ld      sp, hl

    ; done with HRAM — put the game's real (just-restored-from-flash)
    ; bytes back
    call    restore_wram_to_hram

    ; hand the machine back on its saved banks — SVBK last, since the
    ; wStream* staging bytes are only visible while the scratch bank is
    ; mapped. ABORT_LOAD's closing `ret` then pops from the restored
    ; stack, resuming the call chain that was live at save time.
    ld      a, [wStreamVBK]
    ldh     [rVBK], a
    ld      a, [wStreamSVBK]
    ldh     [rSVBK], a
.restore_done:  ; smoke-test hook point: full machine state is restored here
    ; (the checkpoint's two calls push 4 bytes below the restored SP —
    ; memory that was already dead at save time)
    stream_checkpoint 5
    jp      ABORT_LOAD

; Writes 64 bytes from an HRAM buffer into a palette via its port —
; mirrors load_cgb.asm's load_palette protocol.
; @param hl source (HRAM buffer)
; @param c  low byte of the palette control address ($68 BG / $6a OBJ)
restore_palette_from_hram:
    ld      a, $80
    ldh     [c], a      ; auto-increment mode
    inc     c
    ld      b, 64
.loop:
    ld      a, [hl+]
    ldh     [c], a
    dec     b
    jr      nz, .loop
    dec     c
    ret
