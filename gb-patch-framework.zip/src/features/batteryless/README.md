# batteryless

Redirects a game's SRAM saving to the cartridge's Flash ROM, so the game
runs correctly on battery-less bootleg cartridges (a single Flash ROM chip
that stores both the game and the "save RAM", instead of battery-backed
SRAM). On boot, the savegame is copied from Flash ROM into SRAM; after every
save, SRAM is copied back to Flash ROM. Originally based on
[BennVennElectronic's tutorial](https://www.youtube.com/watch?v=l2bx-udTN84)
and Marc Robledo's RGBDS skeleton for it.

The bootleg cartridge's flash-write protocol (WR/AAA/AA, WR/AAA/A9,
WR/555/AA, or WR/555/A9; 64kb erase sectors) is detected at runtime — no
config needed for that part.

Flash operations are bounded: the erase-completion poll times out after
~20s and the per-byte program poll after ~2ms (both far beyond healthy
NOR-chip worst cases), so a worn-out or misdetected chip degrades to "the
save didn't persist" instead of hanging the game with interrupts off. The
outcome of the last save attempt is reported in bit 7 of `wBootlegType`
(`FLASH_SAVE_FAILED_BIT`; set = not persisted — unsupported cartridge or a
timed-out flash operation) for future feedback code to surface to the
player. The write path itself cannot be exercised in the PyBoy smoke tests
(PyBoy does not emulate bootleg flash commands, so detection reports "no
bootleg" there); changes to it need a hardware check — see
docs/TESTING.md.

## Enabling

Add `_BATTERYLESS` to the game's `; builds` line, and:

```asm
DEF SRAM_SIZE EQU CART_SRAM_32KB          ; CART_SRAM_8KB for 8kb SRAM games
DEF flash_data_bank EQU $80              ; first bank of the erasable 64kb
                                         ; flash block that will hold the save
DEF current_rom_bank EQU $ff9d          ; where the game caches its own
                                         ; current ROM bank
entry_point $016e                        ; needed for the boot-time restore
save_hook $05, $4b85, $4c10              ; needed for the post-save flash write
free_space_rom0 ...
free_space_romx ...
free_space_wram ...
```

See [`code.asm`](code.asm) for the exact region-size requirements (also
below) and [docs/CONFIG-KEYS.md](../../../docs/CONFIG-KEYS.md#batteryless-srcfeaturesbatteryless)
for the full key reference.

Optional: `DEF flash_save_enables_ime EQU 0` if the game saves with
interrupts deliberately disabled and expects them to stay disabled — the
flash-write hooks then end in `ret` instead of the default `reti`. The
default matches games that save from normal gameplay with IME on (the
Gold/Silver/Crystal engine). Verify with a debugger (breakpoint on the
`save_hook` call site, inspect IME); an interrupt force-enabled behind a
game's back is a subtle, game-specific corruption source.

## Footprint (measured via `rgblink -m`, Pokemon Crystal, 32kb SRAM)

| Region | Size | Notes |
| --- | --- | --- |
| ROM0 | $57 bytes | boot copy + save-to-flash entry points |
| ROMX | $2BB bytes | flash erase/write/detect routines |
| WRAM | $AB bytes | 1 scratch byte (`wBootlegType`) + the flash routines, copied into WRAM one at a time before each flash operation — the stack must live outside this region |

8kb-SRAM games (`SRAM_SIZE = CART_SRAM_8KB`) need less ROMX (fewer flash-write
iterations — the loop that erases/writes each 8kb SRAM bank runs once
instead of four times).

## Embedding a savegame

If a `.sav` file exists next to the original ROM in `original-roms/`,
`tools/build.sh` embeds it into the flash data automatically
(`-DEMBED_SAVEGAME`). Otherwise an empty (all-zero) savegame is embedded so
the game finds valid, erased SRAM on first boot.

## Licence

MIT (Marc Robledo, Robin Bertram); `bootleg_types.inc`,
`save_sram_to_flash.asm`, `bank_switch_and_copy_from_flash_to_sram.asm`,
`batteryless_boot.asm`, `flash/*.asm`, and `embed_savegame.asm` are dual
GPL-3.0-only OR MIT — see individual file headers.
