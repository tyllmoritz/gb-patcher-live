; Game Boy battery-less patching for bootleg cartridges
; based on BennVennElectronic's tutorial (https://www.youtube.com/watch?v=l2bx-udTN84)
; ------------------------------------------------------------------------------------
; see README file
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2024 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

batteryless_boot:
	;run during boot (before the game's entry point) via on_boot:
	;copies the savegame from Flash ROM into SRAM.
	;preserves all registers: the game reads a (hardware revision) and b
	;(bit 0: GBA flag, used by e.g. Polished Crystal for AGB palette
	;correction) at its entry point, and the copy loops below clobber
	;bc/de/hl
	push	af
	push	bc
	push	de
	push	hl
	ld		a, BANK(copy_save_flash_to_sram)
	ld		[rROMB0], a
	call	copy_save_flash_to_sram
	; see batteryless_savestates_boot_hook (src/features/batteryless_savestates/macros.asm)
	batteryless_savestates_boot_hook
	ld		a, 1
	ld		[rROMB0], a
	pop		hl
	pop		de
	pop		bc
	pop		af
	ret
