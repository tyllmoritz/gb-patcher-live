; ------------------------------------------------------------------------------
; Batteryless + savestates bridge
;
; Persists the save-state SRAM banks (not the game's own save — that's
; save_sram_to_flash/copy_save_flash_to_sram, already unconditional) to a
; *dedicated* flash region, so a save state survives a power cycle too. Only
; built when both _SAVESTATES and _BATTERYLESS are defined; see FEATURES.md
; Feature 1 for the design and what shapes are covered:
;
;   - not a sub-region of the game's own flash_data_bank block. NOR flash
;     erases whole 64kb blocks; if the save-state data lived inside the same
;     block as the game's own save, persisting a save state would force
;     re-erasing (and therefore having to also rewrite) the game's own save
;     data in the same pass. To keep the two fully independent, save-state
;     data gets its own block starting at SAVESTATE_FLASH_BANK
;     (flash_data_bank + 4 — flash_data_bank is already required to start a
;     64kb-aligned block, so +4 banks is exactly the next one, and the
;     block's remaining banks are enough for either shape below).
;   - two of defines.asm's four save-state bank shapes are implemented:
;       * plain DMG (no game_uses_save_ram): 2 banks, 1 flash bank
;       * DMG + game_uses_save_ram + 32kb game SRAM (current_sram_bank
;         defined — the "128kb SRAM cartridge" shape, since defines.asm
;         requires CART_SRAM_128KB whenever the game itself uses 32kb):
;         6 banks across 3 flash banks
;     Still unimplemented: DMG + game_uses_save_ram + 8kb game SRAM (3
;     banks), and CGB (11 banks) — each needs its own pilot; see the ASSERT
;     below.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

IF DEF(is_cgb)
    FAIL "batteryless+savestates: the CGB shape is not implemented yet — see src/features/batteryless/savestates_bridge.asm"
ENDC
IF DEF(game_uses_save_ram) && !DEF(current_sram_bank)
    FAIL "batteryless+savestates: the 8kb-game-SRAM shape is not implemented yet — see src/features/batteryless/savestates_bridge.asm"
ENDC

; a dedicated, fresh 64kb-aligned flash block for the save-state banks (see
; defines.asm), so erasing it never touches the game's own save data in
; flash_data_bank's block. rgblink -O grows the ROM to cover whichever bank
; in this block is referenced highest, so no CHANGE_ROM_SIZE bump is needed
; beyond what the plain shape already required.
DEF SAVESTATE_FLASH_BANK EQU flash_data_bank + 4

; Each save-state SRAM bank's flash mirror: (SRAM bank number, flash bank,
; flash offset). Two 8kb SRAM banks share one 16kb flash bank, at offsets
; $4000 and $6000.
IF DEF(game_uses_save_ram)
    ; 32kb game SRAM shape (SAVE_STATE_RAM_BANK et al. from defines.asm)
    DEF SAVESTATE_BANK_0            EQU SAVE_STATE_RAM_BANK
    DEF SAVESTATE_BANK_0_FLASH_BANK EQU SAVESTATE_FLASH_BANK
    DEF SAVESTATE_BANK_0_FLASH_OFFSET EQU $4000
    DEF SAVESTATE_BANK_1            EQU SAVE_STATE_RAM_BANK_VRAM
    DEF SAVESTATE_BANK_1_FLASH_BANK EQU SAVESTATE_FLASH_BANK
    DEF SAVESTATE_BANK_1_FLASH_OFFSET EQU $6000
    DEF SAVESTATE_BANK_2            EQU SAVE_STATE_SRAM_BANK_0
    DEF SAVESTATE_BANK_2_FLASH_BANK EQU SAVESTATE_FLASH_BANK + 1
    DEF SAVESTATE_BANK_2_FLASH_OFFSET EQU $4000
    DEF SAVESTATE_BANK_3            EQU save_state_sram_bank_1
    DEF SAVESTATE_BANK_3_FLASH_BANK EQU SAVESTATE_FLASH_BANK + 1
    DEF SAVESTATE_BANK_3_FLASH_OFFSET EQU $6000
    DEF SAVESTATE_BANK_4            EQU save_state_sram_bank_2
    DEF SAVESTATE_BANK_4_FLASH_BANK EQU SAVESTATE_FLASH_BANK + 2
    DEF SAVESTATE_BANK_4_FLASH_OFFSET EQU $4000
    DEF SAVESTATE_BANK_5            EQU save_state_sram_bank_3
    DEF SAVESTATE_BANK_5_FLASH_BANK EQU SAVESTATE_FLASH_BANK + 2
    DEF SAVESTATE_BANK_5_FLASH_OFFSET EQU $6000
    DEF SAVESTATE_BANK_COUNT EQU 6
ELSE
    ; plain DMG shape
    DEF SAVESTATE_BANK_0            EQU SAVE_STATE_RAM_BANK_VRAM
    DEF SAVESTATE_BANK_0_FLASH_BANK EQU SAVESTATE_FLASH_BANK
    DEF SAVESTATE_BANK_0_FLASH_OFFSET EQU $4000
    DEF SAVESTATE_BANK_1            EQU SAVE_STATE_RAM_BANK
    DEF SAVESTATE_BANK_1_FLASH_BANK EQU SAVESTATE_FLASH_BANK
    DEF SAVESTATE_BANK_1_FLASH_OFFSET EQU $6000
    DEF SAVESTATE_BANK_COUNT EQU 2
ENDC

; magic_byte_save ($BFE2, defines.asm) lives inside SAVE_STATE_RAM_BANK,
; which is always bank 0 of this list in both shapes — so its flash mirror
; is always at SAVESTATE_BANK_0's location, offset by magic_byte_save's
; position within the SRAM window
DEF SAVESTATE_MAGIC_FLASH_ADDR EQU SAVESTATE_BANK_0_FLASH_OFFSET + (magic_byte_save - $A000)


; Writes one save-state SRAM bank to its flash mirror. wram_write_sram_to_flash_rom
; must already be copied in and its bootleg-cartridge patches applied.
MACRO write_one_savestate_bank ; FLASH_BANK, FLASH_OFFSET, SRAM_BANK
    ld      a, \1
    ld      [wram_write_sram_to_flash_rom.set_destination_bank + 1], a
    ld      a, HIGH(\2)
    ld      [wram_write_sram_to_flash_rom.set_destination_offset + 2], a
    ld      a, \3
    ld      [wram_write_sram_to_flash_rom.set_source_copy_bank + 1], a
    call    wram_write_sram_to_flash_rom
    nop
    jp      c, .failed  ; a byte program timed out
ENDM

; Restores one save-state SRAM bank from its flash mirror.
MACRO restore_one_savestate_bank ; SRAM_BANK, FLASH_BANK, FLASH_OFFSET
    ld      a, \1
    ld      [rRAMB], a
    ld      hl, \3
    ld      de, _SRAM
    ld      bc, $2000
    ld      a, \2
    call    bank_switch_and_copy_from_flash_to_sram
ENDM


; Called from savestates' ABORT_LOAD (load_and_save.asm) after a completed
; save-state save. Runs from the same free_space_romx bank ABORT_LOAD itself
; lives in (both features share one pool), so no bank-switch is needed to
; reach it — only inside it, while talking to the flash chip.
persist_savestate_to_flash:
    di
    push af
    push bc
    push de
    push hl

    call erase_and_write_savestate_banks

    pop hl
    pop de
    pop bc
    pop af
    ; see flash_save_enables_ime in code.asm (same contract as
    ; save_sram_to_flash)
    IF flash_save_enables_ime
    reti
    ELSE
    ret
    ENDC

; Erases SAVESTATE_FLASH_BANK's block and writes all of the shape's
; save-state banks into it. Mirrors erase_and_write_ram_banks's structure
; (detect bootleg type, erase, write) but targets the dedicated save-state
; block instead of flash_data_bank's.
erase_and_write_savestate_banks:
    ; reports the outcome in wBootlegType's FLASH_SAVE_FAILED_BIT, like
    ; erase_and_write_ram_banks
    ld      hl, bootleg_read_identifier
    ld      de, wram_bootleg_read_identifier
    ld      bc, bootleg_read_identifier.end - bootleg_read_identifier
    call    copy_data
    call    wram_bootleg_read_identifier
    ld      [wBootlegType], a
    cp      a, $0
    jp      z, .failed  ; no bootleg cartridge — the state won't survive power-off

    ; erase SAVESTATE_FLASH_BANK's block
    ld      hl, erase_one_flash_erase_block
    ld      de, wram_erase_one_flash_erase_block
    ld      bc, erase_one_flash_erase_block.end - erase_one_flash_erase_block
    call    copy_data
    ld      a, [wBootlegType]
    bit     1, a
    jr      z, .aa_cartridge_1
    ld      a, $3
    ld      [wram_erase_one_flash_erase_block.set_bootleg_cartridge_swapped_datalines + 1], a
.aa_cartridge_1
    ld      a, SAVESTATE_FLASH_BANK
    ld      [wram_erase_one_flash_erase_block.set_erase_bank + 1], a
    ld      a, [wBootlegType]
    bit     2, a
    jr      z, .aaa_cartridge_1
    ld      hl, erase_one_flash_erase_block_555_code
    ld      de, wram_erase_one_flash_erase_block.bootleg_code
    ld      bc, erase_one_flash_erase_block_555_code.end - erase_one_flash_erase_block_555_code
    call    copy_data
.aaa_cartridge_1
    call    wram_erase_one_flash_erase_block
    nop
    jp      c, .failed  ; erase timed out

    ; write every save-state bank to its flash mirror
    ld      hl, write_sram_to_flash_rom
    ld      de, wram_write_sram_to_flash_rom
    ld      bc, write_sram_to_flash_rom.end - write_sram_to_flash_rom
    call    copy_data
    ld      a, [wBootlegType]
    bit     1, a
    jr      z, .aa_cartridge_2
    ld      a, $3
    ld      [wram_write_sram_to_flash_rom.set_bootleg_cartridge_swapped_datalines + 1], a
.aa_cartridge_2
    ld      a, [wBootlegType]
    bit     2, a
    jr      z, .aaa_cartridge_2
    ld      hl, write_sram_to_flash_rom_555_code
    ld      de, wram_write_sram_to_flash_rom.bootleg_code
    ld      bc, write_sram_to_flash_rom_555_code.end - write_sram_to_flash_rom_555_code
    call    copy_data
.aaa_cartridge_2

    write_one_savestate_bank SAVESTATE_BANK_0_FLASH_BANK, SAVESTATE_BANK_0_FLASH_OFFSET, SAVESTATE_BANK_0
    write_one_savestate_bank SAVESTATE_BANK_1_FLASH_BANK, SAVESTATE_BANK_1_FLASH_OFFSET, SAVESTATE_BANK_1
    IF SAVESTATE_BANK_COUNT > 2
    write_one_savestate_bank SAVESTATE_BANK_2_FLASH_BANK, SAVESTATE_BANK_2_FLASH_OFFSET, SAVESTATE_BANK_2
    write_one_savestate_bank SAVESTATE_BANK_3_FLASH_BANK, SAVESTATE_BANK_3_FLASH_OFFSET, SAVESTATE_BANK_3
    write_one_savestate_bank SAVESTATE_BANK_4_FLASH_BANK, SAVESTATE_BANK_4_FLASH_OFFSET, SAVESTATE_BANK_4
    write_one_savestate_bank SAVESTATE_BANK_5_FLASH_BANK, SAVESTATE_BANK_5_FLASH_OFFSET, SAVESTATE_BANK_5
    ENDC

    ret

.failed:
    ld      a, [wBootlegType]
    set     FLASH_SAVE_FAILED_BIT, a
    ld      [wBootlegType], a
    ret


; Reads the flash-resident magic byte. Runs from WRAM (like the flash
; routines in bankx.asm) rather than switching ROMB0 inline here: this
; function lives in ROMX itself, and the instant a `ld [rROMB0],a` here
; took effect, the CPU's next opcode fetch would read from the *new* bank
; at the *same* address instead of continuing this code — self-eviction.
; WRAM isn't addressed through ROMB0, so it's unaffected by the switch.
read_savestate_magic_byte:
    wram_overlay
wram_read_savestate_magic_byte:
    ld      a, SAVESTATE_FLASH_BANK
    ld      [rROMB0], a
    ld      a, [SAVESTATE_MAGIC_FLASH_ADDR]
    push    af
    ld      a, BANK(copy_save_flash_to_sram)
    ld      [rROMB0], a
    pop     af
    ret
    end_wram_overlay
.end


; Called from batteryless_boot (rom0.asm), after the game's own save is
; restored — restores the save-state banks from flash, but only if the
; flash-resident magic byte is present (a fresh cartridge with no save
; state yet must not copy flash garbage into the save-state SRAM banks).
restore_savestate_from_flash:
    ld      hl, read_savestate_magic_byte
    ld      de, wram_read_savestate_magic_byte
    ld      bc, read_savestate_magic_byte.end - read_savestate_magic_byte
    call    copy_data
    call    wram_read_savestate_magic_byte
    cp      magic_byte_value
    jr      nz, .no_save_state

    ld      a, CART_SRAM_ENABLE
    ld      [rRAMG], a

    restore_one_savestate_bank SAVESTATE_BANK_0, SAVESTATE_BANK_0_FLASH_BANK, SAVESTATE_BANK_0_FLASH_OFFSET
    restore_one_savestate_bank SAVESTATE_BANK_1, SAVESTATE_BANK_1_FLASH_BANK, SAVESTATE_BANK_1_FLASH_OFFSET
    IF SAVESTATE_BANK_COUNT > 2
    restore_one_savestate_bank SAVESTATE_BANK_2, SAVESTATE_BANK_2_FLASH_BANK, SAVESTATE_BANK_2_FLASH_OFFSET
    restore_one_savestate_bank SAVESTATE_BANK_3, SAVESTATE_BANK_3_FLASH_BANK, SAVESTATE_BANK_3_FLASH_OFFSET
    restore_one_savestate_bank SAVESTATE_BANK_4, SAVESTATE_BANK_4_FLASH_BANK, SAVESTATE_BANK_4_FLASH_OFFSET
    restore_one_savestate_bank SAVESTATE_BANK_5, SAVESTATE_BANK_5_FLASH_BANK, SAVESTATE_BANK_5_FLASH_OFFSET
    ENDC

    ld      a, CART_SRAM_DISABLE
    ld      [rRAMG], a

.no_save_state
    ; ROMB0 is already BANK(copy_save_flash_to_sram) here — either
    ; wram_read_savestate_magic_byte just restored it (no-save-state case),
    ; or the last restore_one_savestate_bank's
    ; bank_switch_and_copy_from_flash_to_sram did (full-restore case).
    ; batteryless_boot resets it again to the game's bank once we return,
    ; so nothing left to do here.
    ret
