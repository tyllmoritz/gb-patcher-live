; Game Boy battery-less patching for bootleg cartridges
; based on BennVennElectronic's tutorial (https://www.youtube.com/watch?v=l2bx-udTN84)
; ------------------------------------------------------------------------------------
; see README file
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2024 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

bootleg_read_identifier:
	wram_overlay
wram_bootleg_read_identifier:
	ld a,[$0000]
	ld h,a ; the content of $0000 should not be equal to the manufacturer ids

	; detect WRAAAA9_64KB cart
	ld a,$F0
	ld [$0000],a
	nop
	ld a,$A9
	ld [$0AAA],a
	nop
	ld a,$56
	ld [$0555],a
	nop
	ld a,$90
	ld [$0AAA],a
	nop

	ld a,[$0000]
	cp h
	jp z, .not_cartridgetype_WRAAAA9_64KB
	ld a,$F0
	ld [$0000],a
	ld a,WRAAAA9_64KB
	ret

	.not_cartridgetype_WRAAAA9_64KB
	; detect 555/A9 cart
	ld a,$F0
	ld [$0000],a
	nop
	ld a,$A9
	nop
	ld [$0555],a
	nop
	ld a,$56
	nop
	ld [$02AA],a
	nop
	ld a,$90
	ld [$0555],a
	nop

	ld a,[$0000]
	cp h
	jp z, .not_cartridgetype_WR555A9_64KB
	ld a,$F0
	ld [$0000],a
	ld a,WR555A9_64KB
	ret

	.not_cartridgetype_WR555A9_64KB

	; detect AAA/AA cart
	ld a,$F0
	ld [$0000],a
	nop
	ld a,$AA
	ld [$0AAA],a
	nop
	ld a,$55
	ld [$0555],a
	nop
	ld a,$90
	ld [$0AAA],a
	nop

	ld a,[$0000]
	cp h
	jp z, .not_cartridgetype_WRAAAAA_64KB
	ld a,$F0
	ld [$0000],a
	ld a,WRAAAAA_64KB
	ret

	.not_cartridgetype_WRAAAAA_64KB

	; detect 555/AA cart
	ld a,$F0
	ld [$0000],a
	nop
	ld a,$AA
	ld [$0555],a
	nop
	ld a,$55
	ld [$02AA],a
	nop
	ld a,$90
	ld [$0555],a
	nop

	ld a,[$0000]
	cp h
	jp z, .not_cartridgetype_WR555AA_64KB
	ld a,$F0
	ld [$0000],a
	ld a,WR555AA_64KB
	ret

	.not_cartridgetype_WR555AA_64KB
	ld a,$F0
	ld [$0000],a
	ld a,$0 ; no compatible cartridge detected
	ret
	end_wram_overlay
.end
