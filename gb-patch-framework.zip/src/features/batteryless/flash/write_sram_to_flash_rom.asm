; Game Boy battery-less patching for bootleg cartridges
; based on BennVennElectronic's tutorial (https://www.youtube.com/watch?v=l2bx-udTN84)
; ------------------------------------------------------------------------------------
; see README file
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2024 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

write_sram_to_flash_rom:
	wram_overlay
wram_write_sram_to_flash_rom:
.set_destination_bank:
	ld		a, flash_data_bank
	ld		[rROMB0], a
	ld		hl, _SRAM
.set_destination_offset:
	ld		de, $4000
.loop:
	ld		a, CART_SRAM_ENABLE
	ld		[rRAMG], a ;enable SRAM

	;RTC (not needed?)
	;ld		a, 1
	;ld		[$6000], a

.set_source_copy_bank:
	IF SRAM_SIZE == CART_SRAM_32KB
		ld		a, $00 ;so we can replace $00 with following block indexes later
	ELSE
		xor		a
	ENDC
	ld		[rRAMB], a
	ld		a, [hl]
	ld		b, a

	xor		a

.set_bootleg_cartridge_swapped_datalines
	ld		c, $0

	;RTC (not needed?)
	;ld		[$6000], a

	ld		[rRAMG], a ;disable SRAM
	ld		a, $f0
	ld		[rRAMB], a

.bootleg_code
	ld		a, $aa
	xor		a, c
	ld		[$0aaa], a

	ld		a, $55
	xor		a, c
	ld		[$0555], a

	nop
	ld		a, $a0
	ld		[$0aaa], a
	nop

	ld		a, b
	ld		[de], a
	;poll for byte-program completion, but bounded: typical NOR byte
	;program is ~10µs (worst case ~ms); 2048 polls ≈ 20ms on DMG is a
	;generous budget. hl (the SRAM source pointer) doubles as the counter
	;while saved on the stack. On timeout: reset the chip and bail out of
	;the whole bank write with carry set (a half-written bank is already
	;lost; continuing byte-by-byte would just take seconds to fail).
	push	hl
	ld		hl, 2048
.verify_loop:
	ld		a, [de]
	xor		b
	jr		z, .byte_done
	dec		hl
	ld		a, h
	or		a, l
	jr		nz, .verify_loop
	ld		a, $f0
	ld		[de], a
	pop		hl
	scf
	jr		.banks
.byte_done:
	pop		hl
	inc		hl
	inc		de
	ld		a, h
	cp		a, $c0
	jr		nz, .loop
	;bank done: carry is clear here (cp found equality)
.banks:
	ld		a, $f0
	ld		[rRAMB], a
	ld		a, FREE_ROMX_BANK
	ld		[rROMB0], a

	ret
	end_wram_overlay
.end
