; Game Boy battery-less patching for bootleg cartridges
; based on BennVennElectronic's tutorial (https://www.youtube.com/watch?v=l2bx-udTN84)
; ------------------------------------------------------------------------------------
; see README file
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2024 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

erase_and_write_ram_banks:
	;safe to be run from ROM, since it will copy the needed subroutines to RAM and call them there
	;reports the outcome in wBootlegType's FLASH_SAVE_FAILED_BIT (set =
	;unsupported cartridge or a flash operation timed out; the save did not
	;persist) for feedback code to surface to the player

	;ld a, BOOTLEG_CARTRIDGE_TYPE
	ld		hl, bootleg_read_identifier
	ld		de, wram_bootleg_read_identifier
	ld		bc, bootleg_read_identifier.end - bootleg_read_identifier
	call	copy_data
	call	wram_bootleg_read_identifier
	ld [wBootlegType], a
	cp a, $0
	jr nz, .bootleg_detected
	;no compatible flash chip: the save only reached SRAM and will not
	;survive a power cycle
	jp .failed
.bootleg_detected

	;erase 64kb block
	ld		hl, erase_one_flash_erase_block
	ld		de, wram_erase_one_flash_erase_block
	ld		bc, erase_one_flash_erase_block.end - erase_one_flash_erase_block
	call	copy_data
	; patch code for bootleg_cartridge_type
	ld a, [wBootlegType]
	bit 1, a
	jr z, .AA_cartridge_1
	ld a, $3
	ld [wram_erase_one_flash_erase_block.set_bootleg_cartridge_swapped_datalines + 1], a
.AA_cartridge_1
	ld a, [wBootlegType]
	bit 2, a
	jr z, .AAA_cartridge_1
	ld		hl, erase_one_flash_erase_block_555_code
	ld		de, wram_erase_one_flash_erase_block.bootleg_code
	ld		bc, erase_one_flash_erase_block_555_code.end - erase_one_flash_erase_block_555_code
	call	copy_data
.AAA_cartridge_1
	; run code from wram
	call	wram_erase_one_flash_erase_block
	nop
	jp		c, .failed ;erase timed out

	;write
	ld		hl, write_sram_to_flash_rom
	ld		de, wram_write_sram_to_flash_rom
	ld		bc, write_sram_to_flash_rom.end - write_sram_to_flash_rom
	call	copy_data
	; patch code for bootleg_cartridge_type
	ld a, [wBootlegType]
	bit 1, a
	jr z, .AA_cartridge_2
	ld a, $3
	ld [wram_write_sram_to_flash_rom.set_bootleg_cartridge_swapped_datalines + 1], a
.AA_cartridge_2
	ld a, [wBootlegType]
	bit 2, a
	jr z, .AAA_cartridge_2
	ld		hl, write_sram_to_flash_rom_555_code
	ld		de, wram_write_sram_to_flash_rom.bootleg_code
	ld		bc, write_sram_to_flash_rom_555_code.end - write_sram_to_flash_rom_555_code
	call	copy_data
.AAA_cartridge_2
	call	wram_write_sram_to_flash_rom
	nop
	jp		c, .failed ;a byte program timed out

	IF SRAM_SIZE == CART_SRAM_32KB
		REPT 7 - 1
			nop ;some dummy nops to guarantee correct flashing, might not be needed?
		ENDR

		;8kb-16kb
		;edit subroutine directly in RAM, changing some values
		ld		a, HIGH($6000)
		ld		[wram_write_sram_to_flash_rom.set_destination_offset + 2], a ;destination ROM offset=$6000
		ld		a, 1
		ld		[wram_write_sram_to_flash_rom.set_source_copy_bank + 1], a ;source SRAM bank=1
		call	wram_write_sram_to_flash_rom
		nop
		jp		c, .failed ;a byte program timed out
		REPT 7 - 1
			nop ;some dummy nops to guarantee correct flashing, might not be needed?
		ENDR

		;16kb-24kb
		;edit subroutine directly in RAM, changing some values
		ld		a, flash_data_bank + 1
		ld		[wram_write_sram_to_flash_rom.set_destination_bank + 1], a ;destination ROM bank=flash_data_bank + 1
		ld		a, HIGH($4000)
		ld		[wram_write_sram_to_flash_rom.set_destination_offset + 2], a ;destination ROM offset=$4000
		ld		a, 2
		ld		[wram_write_sram_to_flash_rom.set_source_copy_bank + 1], a ;source SRAM bank=2
		call	wram_write_sram_to_flash_rom
		nop
		jp		c, .failed ;a byte program timed out
		REPT 7 - 1
			nop ;some dummy nops to guarantee correct flashing, might not be needed?
		ENDR

		;24kb-32kb
		;edit subroutine directly in RAM, changing some values
		ld		a, HIGH($6000)
		ld		[wram_write_sram_to_flash_rom.set_destination_offset + 2], a ;destination ROM offset=$6000
		ld		a, 3
		ld		[wram_write_sram_to_flash_rom.set_source_copy_bank + 1], a ;source SRAM bank=3
		call	wram_write_sram_to_flash_rom
		nop
		jp		c, .failed ;a byte program timed out
	ENDC

	ret

.failed:
	ld		a, [wBootlegType]
	set		FLASH_SAVE_FAILED_BIT, a
	ld		[wBootlegType], a
	ret
