; Game Boy battery-less patching for bootleg cartridges
; based on BennVennElectronic's tutorial (https://www.youtube.com/watch?v=l2bx-udTN84)
; ------------------------------------------------------------------------------------
; see README file
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2024 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

; Flashes a small, arbitrary-length linear range (I/O regs, OAM, or a small
; WRAM scratch buffer) — the metadata pieces of a flash-based CGB save state
; (magic byte, IO/HRAM, OAM, staged palette/SP bytes; see
; batteryless_savestates.asm). None of these sources are WRAM/VRAM bank
; content, so this runs from the plain wram_overlay (shared with
; write_sram_to_flash_rom.asm and the erase/detect routines), not
; hram_overlay — no self-overlap risk to avoid here, just the ordinary
; "flash is unreadable as ROM while its own unlock sequence runs" reason
; every flash-write routine needs RAM residency at all.
;
; Terminates by comparing the source pointer against an exact patched end
; address (not a page-boundary high-byte check like write_wram_to_flash_rom/
; write_vram_to_flash_rom, since I/O's 256-byte range wraps $ff00+256 to
; $0000, and OAM's 160 bytes don't end on a page boundary at all) — 4 bytes
; of scratch (`a`, reused for both halves of the compare) instead of a
; dedicated counter register, since bc's low byte is already spoken for by
; .set_bootleg_cartridge_swapped_datalines every iteration.

IF GB_COMPATIBILITY == CART_COMPATIBLE_GBC && DEF(_SAVESTATES)
write_metadata_range_to_flash_rom:
	wram_overlay
wram_write_metadata_range_to_flash_rom:
.set_destination_bank:
	ld		a, flash_data_bank
	ld		[rROMB0], a
.set_source_address:
	ld		hl, $ff00
.set_destination_offset:
	ld		de, $4000
.loop:
	; plain [hl], NOT [hl+]: .byte_done below already does the `inc hl`
	; (the loop tail is shared with write_sram_to_flash_rom's shape). The
	; original [hl+] advanced the source pointer by TWO per byte on real
	; hardware, so every metadata chunk longer than one byte (IO, OAM,
	; both palettes, SP) flashed every-other-byte garbage — invisible in
	; the smoke test while FlashEmu skipped this routine instead of
	; letting it run natively (it no longer does; see FlashEmu's
	; verify-loop hook in tests/smoke/run.py)
	ld		a, [hl]
	ld		b, a

	xor		a

.set_bootleg_cartridge_swapped_datalines
	ld		c, $0

	ld		[rRAMG], a ;gate the flash chip into command mode
	ld		a, $f0
	ld		[rRAMB], a

.bootleg_code
	ld		a, $aa
	xor		a, c
	ld		[$0aaa], a

	ld		a, $55
	xor		a, c
	ld		[$0555], a

	nop
	ld		a, $a0
	ld		[$0aaa], a
	nop

	ld		a, b
	ld		[de], a
	push	hl
	ld		hl, 2048
.verify_loop:
	ld		a, [de]
	xor		b
	jr		z, .byte_done
	dec		hl
	ld		a, h
	or		a, l
	jr		nz, .verify_loop
	ld		a, $f0
	ld		[de], a
	pop		hl
	scf
	jr		.banks
.byte_done:
	pop		hl
	inc		hl
	inc		de
	ld		a, l
.set_source_end_low:
	cp		a, $00 ;patched: LOW(source start + length)
	jr		nz, .loop
	ld		a, h
.set_source_end_high:
	cp		a, $00 ;patched: HIGH(source start + length)
	jr		nz, .loop
.banks:
	ld		a, $f0
	ld		[rRAMB], a
	ld		a, FREE_ROMX_BANK
	ld		[rROMB0], a

	ret
	end_wram_overlay
.end
ENDC
