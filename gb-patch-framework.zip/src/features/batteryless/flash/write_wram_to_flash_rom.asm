; Game Boy battery-less patching for bootleg cartridges
; based on BennVennElectronic's tutorial (https://www.youtube.com/watch?v=l2bx-udTN84)
; ------------------------------------------------------------------------------------
; see README file
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2024 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

; Feature 1b: writes a CGB save state's WRAM/VRAM straight to flash instead
; of staging it in dedicated SRAM banks first (see
; src/features/batteryless_savestates/batteryless_savestates.asm). This and
; write_vram_to_flash_rom.asm/write_metadata_range_to_flash_rom.asm are
; copies of write_sram_to_flash_rom.asm above with the source changed to
; hardware WRAM/VRAM instead of _SRAM — same unlock sequence, same polling,
; same .bootleg_code shape (write_sram_to_flash_rom_555_code, already
; generic, is reused unmodified for the 555-style unlock patch here too).
;
; They run from an hram_overlay, not a wram_overlay: this routine's own
; *source* is WRAM (for write_wram_to_flash_rom) or VRAM (for
; write_vram_to_flash_rom), so if its code lived in a WRAM/VRAM bank it
; would risk reading (and flashing) its own instruction bytes instead of
; the game's real data at that address whenever that exact bank is the one
; being captured. HRAM is disjoint from every WRAM bank and both VRAM
; banks, so this hazard doesn't apply there.
;
; SVBK is switched to the source bank only around the single source-byte
; read (.set_source_bank), then immediately switched back to the pinned
; scratch bank (.set_restore_bank — the caller's stack and scratch live
; there, see the bank discipline note in batteryless_savestates.asm):
; the verify loop below pushes hl on the stack, and a push made while
; SVBK still pointed at the *captured* bank would land in that bank at
; the stack address — scribbling on (and capturing garbage into) every
; WRAM bank except the one the stack really lives in.
;
; a: WRAM(SVBK)/VRAM(VBK) bank to read from (patched into .set_source_bank)

IF GB_COMPATIBILITY == CART_COMPATIBLE_GBC && DEF(_SAVESTATES)
write_wram_to_flash_rom:
	hram_overlay
hram_write_wram_to_flash_rom:
.set_destination_bank:
	ld		a, flash_data_bank
	ld		[rROMB0], a
.set_source_address:
	ld		hl, $c000
.set_destination_offset:
	ld		de, $4000
.loop:
.set_source_bank:
	ld		a, $00 ;so we can replace $00 with the SVBK value later
	ldh		[rSVBK], a
	ld		a, [hl]
	ld		b, a
.set_restore_bank:
	ld		a, $00 ;patched with the pinned scratch bank (see comment above)
	ldh		[rSVBK], a

	xor		a

.set_bootleg_cartridge_swapped_datalines
	ld		c, $0

	ld		[rRAMG], a ;gate the flash chip into command mode
	ld		a, $f0
	ld		[rRAMB], a

.bootleg_code
	ld		a, $aa
	xor		a, c
	ld		[$0aaa], a

	ld		a, $55
	xor		a, c
	ld		[$0555], a

	nop
	ld		a, $a0
	ld		[$0aaa], a
	nop

	ld		a, b
	ld		[de], a
	push	hl
	ld		hl, 2048
.verify_loop:
	ld		a, [de]
	xor		b
	jr		z, .byte_done
	dec		hl
	ld		a, h
	or		a, l
	jr		nz, .verify_loop
	ld		a, $f0
	ld		[de], a
	pop		hl
	scf
	jr		.banks
.byte_done:
	pop		hl
	inc		hl
	inc		de
	ld		a, h
	cp		a, $e0 ;$c000 + $2000 = $e000: WRAM banks are 8kb
	jr		nz, .loop
.banks:
	ld		a, $f0
	ld		[rRAMB], a
	ld		a, FREE_ROMX_BANK
	ld		[rROMB0], a

	ret
	end_hram_overlay
.end
ENDC
