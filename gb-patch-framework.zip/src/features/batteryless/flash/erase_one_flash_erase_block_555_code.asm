; Game Boy battery-less patching for bootleg cartridges
; based on BennVennElectronic's tutorial (https://www.youtube.com/watch?v=l2bx-udTN84)
; ------------------------------------------------------------------------------------
; see README file
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2024 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

erase_one_flash_erase_block_555_code:
	ld		a, $aa
	xor		a, b
	ld		[$0555], a

    ld		a, $55
	xor		a, b
    ld		[$02aa], a
	nop

    ld		a, $80
    ld		[$0555], a

    ld		a, $aa
	xor		a, b
    ld		[$0555], a

    ld		a, $55
	xor		a, b
    ld		[$02aa], a
.end
