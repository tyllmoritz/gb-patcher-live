; Game Boy battery-less patching for bootleg cartridges
; based on BennVennElectronic's tutorial (https://www.youtube.com/watch?v=l2bx-udTN84)
; ------------------------------------------------------------------------------------
; see README file
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2024 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

copy_save_flash_to_sram:
	;copy code from Flash ROM to SRAM, this is executed during game's intercepted boot
	ld		a, CART_SRAM_ENABLE
	ld		[rRAMG], a ;enable SRAM

	xor		a
	ld		[rRAMB], a ;set RAM bank 0
	ld		hl, $4000 ;source (Flash ROM)
	ld		de, _SRAM ;target (SRAM)
	ld		bc, $2000 ;size
	ld		a, flash_data_bank ;set source ROM bank
	call	bank_switch_and_copy_from_flash_to_sram

	IF SRAM_SIZE == CART_SRAM_32KB
		;8kb-16kb
		ld		a, 1
		ld		[rRAMB], a ;set RAM bank 1
		;hl is $6000 here
		ld		de, _SRAM ;target (SRAM)
		ld		bc, $2000 ;size
		ld		a, flash_data_bank ;set source ROM bank
		call	bank_switch_and_copy_from_flash_to_sram

		;16kb-24kb
		ld		a, 2
		ld		[rRAMB], a ;set RAM bank 2
		ld		hl, $4000 ;source (Flash ROM)
		ld		de, _SRAM ;target (SRAM)
		ld		bc, $2000 ;size
		ld		a, flash_data_bank + 1 ;set source ROM bank
		call	bank_switch_and_copy_from_flash_to_sram

		;24kb-32kb
		ld		a, 3
		ld		[rRAMB], a ;set RAM bank 3
		;hl is $6000 here
		ld		de, _SRAM ;target (SRAM)
		ld		bc, $2000 ;size
		ld		a, flash_data_bank + 1 ;set source ROM bank
		call	bank_switch_and_copy_from_flash_to_sram
	ENDC

	ld		a, CART_SRAM_DISABLE
	ld		[rRAMG], a ;disable SRAM

	ret
