; Game Boy battery-less patching for bootleg cartridges
; based on BennVennElectronic's tutorial (https://www.youtube.com/watch?v=l2bx-udTN84)
; ------------------------------------------------------------------------------------
; see README file
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2024 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

; Feature 1b: same design as write_wram_to_flash_rom.asm (see its header
; comment) — VRAM instead of WRAM as the source.

IF GB_COMPATIBILITY == CART_COMPATIBLE_GBC && DEF(_SAVESTATES)
write_vram_to_flash_rom:
	hram_overlay
hram_write_vram_to_flash_rom:
.set_destination_bank:
	ld		a, flash_data_bank
	ld		[rROMB0], a
	ld		hl, $8000
.set_destination_offset:
	ld		de, $4000
.loop:
.set_source_bank:
	ld		a, $00 ;so we can replace $00 with the VBK value later
	ldh		[rVBK], a
	ld		a, [hl]
	ld		b, a

	xor		a

.set_bootleg_cartridge_swapped_datalines
	ld		c, $0

	ld		[rRAMG], a ;gate the flash chip into command mode
	ld		a, $f0
	ld		[rRAMB], a

.bootleg_code
	ld		a, $aa
	xor		a, c
	ld		[$0aaa], a

	ld		a, $55
	xor		a, c
	ld		[$0555], a

	nop
	ld		a, $a0
	ld		[$0aaa], a
	nop

	ld		a, b
	ld		[de], a
	push	hl
	ld		hl, 2048
.verify_loop:
	ld		a, [de]
	xor		b
	jr		z, .byte_done
	dec		hl
	ld		a, h
	or		a, l
	jr		nz, .verify_loop
	ld		a, $f0
	ld		[de], a
	pop		hl
	scf
	jr		.banks
.byte_done:
	pop		hl
	inc		hl
	inc		de
	ld		a, h
	; $8000 + $2000 = $a000: VRAM banks are also 8kb, but start $2000
	; lower than WRAM's window, so the terminator differs from
	; write_wram_to_flash_rom's ($a0, not $e0)
	cp		a, $a0
	jr		nz, .loop
.banks:
	ld		a, $f0
	ld		[rRAMB], a
	ld		a, FREE_ROMX_BANK
	ld		[rROMB0], a

	ret
	end_hram_overlay
.end
ENDC
