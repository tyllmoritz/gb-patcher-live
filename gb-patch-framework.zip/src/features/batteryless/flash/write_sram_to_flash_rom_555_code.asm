; Game Boy battery-less patching for bootleg cartridges
; based on BennVennElectronic's tutorial (https://www.youtube.com/watch?v=l2bx-udTN84)
; ------------------------------------------------------------------------------------
; see README file
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2024 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

write_sram_to_flash_rom_555_code:
	ld		a, $aa
	xor		a, c
	ld		[$0555], a

	ld		a, $55
	xor		a, c
	ld		[$02aa], a

	nop
	ld		a, $a0
	ld		[$0555], a
	nop
.end
