; Game Boy battery-less patching for bootleg cartridges
; based on BennVennElectronic's tutorial (https://www.youtube.com/watch?v=l2bx-udTN84)
; ------------------------------------------------------------------------------------
; see README file
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2024 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

erase_one_flash_erase_block:
	wram_overlay
wram_erase_one_flash_erase_block:

.set_bootleg_cartridge_swapped_datalines
	ld		b, $0

.set_erase_bank
	ld		a, flash_data_bank
	ld		[rROMB0], a
	nop

	ld		a, $f0
	ld		[$4000], a

.bootleg_code
	ld		a, $aa
	xor		a, b
	ld		[$0aaa], a

	ld		a, $55
	xor		a, b
	ld		[$0555], a
	nop

	ld		a, $80
	ld		[$0aaa], a

	ld		a, $aa
	xor		a, b
	ld		[$0aaa], a

	ld		a, $55
	xor		a, b
	ld		[$0555], a

	nop

	ld		a, $30
	ld		[$4000], a
	nop

	;poll for erase completion, but bounded: a worn-out or misdetected chip
	;must not hang the game forever with interrupts off. Typical NOR sector
	;erase is 0.5-2s (worst case ~10s); one inner-counter round of 65536
	;polls is ~0.8s on DMG, so 24 outer rounds ≈ 20s — beyond any healthy
	;chip. On timeout: reset the chip ($f0) and return with carry set
	;(the tail below is all `ld`s, which preserve carry).
	ld		de, 0
	ld		c, 24
.loop:
	ld		a, [$4000]
	cp		a, $ff
	jr		z, .end ;erased: carry is clear (cp found equality)
	dec		de
	ld		a, d
	or		a, e
	jr		nz, .loop
	dec		c
	jr		nz, .loop
	ld		a, $f0
	ld		[$4000], a
	scf
.end:
	nop

	ld		a, $f0
	ld		[rRAMB], a
	ld		a, FREE_ROMX_BANK
	ld		[rROMB0], a
	ret
	end_wram_overlay
.end
