; ------------------------------------------------------------------------------
; Battery-less saving for bootleg flash cartridges — code placement
;
; Redirects the game's SRAM saving to the cartridge's Flash ROM, so games run
; on battery-less bootleg cartridges without losing saves. The bootleg type
; (WR/AAA/AA, WR/AAA/A9, WR/555/AA, WR/555/A9; 64kb sectors) is detected at
; runtime.
;
; Required game config declarations:
;   DEF SRAM_SIZE EQU CART_SRAM_8KB|CART_SRAM_32KB  ; game's own SRAM size
;   DEF flash_data_bank EQU $xx       ; first flash bank for save data
;                                     ; (start of an erasable 64kb block)
;   DEF current_rom_bank EQU $xxxx   ; where the game stores its current
;                                     ; ROM bank (RAM or HRAM)
;   entry_point ...                   ; boot hook (restores the save)
;   save_hook ...                     ; after-save hook (writes flash)
;   free_space_rom0 ...               ; ~$60 bytes
;   free_space_romx ...               ; ~$290 bytes for CART_SRAM_32KB,
;                                     ; less for 8kb SRAM (fewer flash writes)
;   free_space_wram ...               ; ~$ab bytes, stack must be outside
;
; Combined with _SAVESTATES (plain DMG, no game SRAM_SIZE, shape only —
; see src/features/batteryless_savestates/batteryless_savestates_dmg_nosram.asm):
; also persists save states to a dedicated flash block at
; flash_data_bank + 4; CHANGE_ROM_SIZE must have room for it.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

INCLUDE "src/features/batteryless/bootleg_types.inc"

; The flash chip erases whole 64kb sectors (4 ROM banks, 64kb-aligned).
; erase_one_flash_erase_block erases the sector *containing*
; flash_data_bank, so an unaligned value silently extends the erase into
; the preceding banks — which may hold real game data or the patch code
; itself (this bit Metroid II DX: flash_data_bank $16 put game data $14
; and the code bank $15 inside the erased $14-$17 sector).
ASSERT (flash_data_bank & 3) == 0, "flash_data_bank must be 64kb-aligned (a multiple of 4 banks) — the flash erase wipes the whole sector containing it"

; SRAM_SIZE also covers MBC2's built-in 512x4-bit RAM (CART_SRAM_2KB — see
; games with cart_type $05/$06), which the savestates feature treats like
; any other 1-bank SRAM window, but this feature's byte-count logic below
; only knows real 8kb/32kb SRAM chips.
IF DEF(SRAM_SIZE)
    ASSERT SRAM_SIZE == CART_SRAM_8KB || SRAM_SIZE == CART_SRAM_32KB, "battery-less flash mirroring only supports SRAM_SIZE EQU CART_SRAM_8KB or CART_SRAM_32KB (real SRAM chips) — MBC2's built-in RAM (CART_SRAM_2KB) has no flash-mirroring support here"
ENDC

; What the game expects after its save routine returns: 1 (default) means
; the flash-write hooks end in `reti`, re-enabling interrupts — correct for
; games that save from normal gameplay with IME on (the Gold/Silver/Crystal
; engine). Games that save with interrupts deliberately disabled and expect
; them to stay disabled must set `DEF flash_save_enables_ime EQU 0` in
; their config, making the hooks end in `ret` (IME stays off, as the `di`
; at hook entry left it).
IF !DEF(flash_save_enables_ime)
    DEF flash_save_enables_ime EQU 1
ENDC

; the detected bootleg type is kept at the start of the WRAM free space,
; where it survives the flash routines being copied in one after another.
; bit 7 doubles as the outcome of the last flash save (set = unsupported
; cartridge or a flash operation timed out, i.e. the save did NOT persist),
; for feedback code to surface to the player instead of failing silently.
; It costs no extra scratch byte (some configs' WRAM windows are sized to
; the byte) and is self-clearing: every save attempt starts by re-running
; the detector, whose result (0-4) rewrites the whole byte.
    wram_scratch wBootlegType
DEF FLASH_SAVE_FAILED_BIT EQU 7

; Feature 1b (batteryless_savestates.asm) needs its own persistent scratch
; bytes too; must be reserved here, before any wram_overlay use below —
; every wram_overlay invocation shares one frozen WRAM_SCRATCH_BYTES value,
; so declaring these any later would put bankx.asm's overlays (assembled
; first) and batteryless_savestates.asm's (assembled after) at different
; addresses for what's supposed to be the same shared region.
IF GB_COMPATIBILITY == CART_COMPATIBLE_GBC && DEF(_SAVESTATES)
    wram_scratch wBatterylessSavestateSPLow
    wram_scratch wBatterylessSavestateSPHigh
    wram_scratch wBatterylessSavestateMagicByte
; the game's live SVBK/VBK: snapshotted at save entry so the capture can
; put them back (write_wram_to_flash_rom/write_vram_to_flash_rom cycle the
; bank registers through every bank and would otherwise leave the game on
; bank 7 / VRAM bank 1); reused on the load side to stage the *saved*
; SVBK/VBK read back from flash until they're applied last
    wram_scratch wBatterylessSavestateSVBK
    wram_scratch wBatterylessSavestateVBK
; a small scratch stack, used by the whole save side (with the scratch
; bank pinned, pushes on the game's own stack would scribble on the
; scratch bank at the stack address — see the bank discipline note in
; batteryless_savestates.asm) and by the load side's first phase
; (OAM/IO/palette restore — the game's stack may live in HRAM, which the
; IO restore overwrites mid-copy). 16 bytes covers the deepest chain
; (call -> flash routine -> its verify-loop push) with margin.
    wram_scratch_block wBatterylessSavestateStack, 16
DEF wBatterylessSavestateStackTop EQU wBatterylessSavestateStack + 16
; backs up the borrowed HRAM window (free_space_hram) before hram_overlay
; code/scratch temporarily occupies it, so the game's own HRAM content
; (whatever it actually is, not assumed free) is intact again once done —
; see backup_hram_to_wram/restore_wram_to_hram in batteryless_savestates.asm
    wram_scratch_block wHramBackup, FREE_HRAM_END - FREE_HRAM_START
ENDC

; the game's own current-ROM-bank byte, reused to restore the bank after
; writing to flash
    PUSHS
IF current_rom_bank >= _HRAM
    SECTION "HRAM - original game's bank switch backup", HRAM[current_rom_bank]
ELIF current_rom_bank >= _RAMBANK
    SECTION "WRAMX - original game's bank switch backup", WRAMX[current_rom_bank], BANK[1]
ELIF current_rom_bank >= _RAM
    SECTION "WRAM0 - original game's bank switch backup", WRAM0[current_rom_bank]
ELSE
    SECTION "SRAM - original game's bank switch backup", SRAM[current_rom_bank], BANK[0]
ENDC
_current_game_bank:
    DB
    POPS

    rom0_code
INCLUDE "src/features/batteryless/save_sram_to_flash.asm"
INCLUDE "src/features/batteryless/bank_switch_and_copy_from_flash_to_sram.asm"
INCLUDE "src/features/batteryless/batteryless_boot.asm"
    end_code

; Games with a non-standard cartridge entry point (no `nop; jp nnnn` at
; $0100, e.g. Prism) can't use entry_point/on_boot: they set
; `DEF custom_boot EQU 1` and instead patch_rom their own boot routine
; over $0100, replicating the displaced instructions and calling
; `batteryless_boot` (a plain label, callable directly) themselves.
IF !DEF(custom_boot)
    on_boot batteryless_boot
ENDC
    on_save save_sram_to_flash

    romx_code
INCLUDE "src/features/batteryless/flash/copy_save_flash_to_sram.asm"
INCLUDE "src/features/batteryless/flash/copy_data.asm"
INCLUDE "src/features/batteryless/flash/erase_and_write_ram_banks.asm"
INCLUDE "src/features/batteryless/flash/erase_one_flash_erase_block.asm"
INCLUDE "src/features/batteryless/flash/write_sram_to_flash_rom.asm"
INCLUDE "src/features/batteryless/flash/write_wram_to_flash_rom.asm"
INCLUDE "src/features/batteryless/flash/write_vram_to_flash_rom.asm"
INCLUDE "src/features/batteryless/flash/write_metadata_range_to_flash_rom.asm"
INCLUDE "src/features/batteryless/flash/erase_one_flash_erase_block_555_code.asm"
INCLUDE "src/features/batteryless/flash/write_sram_to_flash_rom_555_code.asm"
INCLUDE "src/features/batteryless/flash/bootleg_read_identifier.asm"
IF DEF(_SAVESTATES)
IF GB_COMPATIBILITY == CART_COMPATIBLE_GBC
INCLUDE "src/features/batteryless_savestates/batteryless_savestates.asm"
ELSE
INCLUDE "src/features/batteryless_savestates/batteryless_savestates_dmg_nosram.asm"
ENDC
ENDC
    end_code

INCLUDE "src/features/batteryless/embed_savegame.asm"
