; ------------------------------------------------------------------------------
; Pokemon G/S/C RTC changer ("nortc") — code placement
;
; Lets the player change the real-time clock from the Pokegear clock menu
; (up/down to adjust, hold A for faster steps). Original patches by infinest
; (https://infine.st/, https://www.romhacking.net/hacks/4450/).
;
; Required game config declarations (game-version specific offsets):
;   DEF FarCall EQU $x                          ; the game's farcall rst vector
;   DEF hJoypadDown EQU $ffxx
;   DEF wStartDay_ EQU $xxxx                    ; wStartDay..wStartSecond block
;   DEF wScriptFlags EQU $xxxx
;   DEF wSpriteAnimAddrBackup EQU $xxxx
;   DEF wSpriteAnimAddrBackup_Value EQU $xx
;   DEF wJumptableIndex EQU $xxxx
;   DEF UpdateTime_FixTime_ EQU $xxxx           ; `call FixTime` inside UpdateTime
;   DEF FixTime_ EQU $xxxx
;   DEF PokegearClock_Joypad_buttoncheck_ EQU $xxxx
;   DEF PokegearClock_Joypad_BANK EQU $xx
;   free_space_rom0 ...                         ; ~$8 bytes
;   free_space_romx ...                         ; ~$100 bytes
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2019 infinest
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only
; ------------------------------------------------------------------------------

INCLUDE "src/features/rtc/buttons.inc"

; farcall stub reachable from bank 0
    rom0_code
INCLUDE "src/features/rtc/rom0.asm"
    end_code

; the time changer itself
    romx_code
INCLUDE "src/features/rtc/bankx.asm"
    end_code

; hook `call FixTime` inside UpdateTime and keep the Pokegear clock menu open
; on the A button
INCLUDE "src/features/rtc/hook_in_updatetime.asm"
INCLUDE "src/features/rtc/pokegear_dont-quit_on-A-button.asm"

; names for the game's start-time bytes in WRAM
INCLUDE "src/features/rtc/wram.asm"
