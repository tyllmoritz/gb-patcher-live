# rtc

Lets the player change the real-time clock from the Pokegear clock menu in
Pokemon Gold/Silver/Crystal — press Up/Down to adjust, hold A to advance
faster. Useful for bootleg cartridges with no working RTC hardware (the
in-game clock otherwise can't be set). Disassembled with permission from
[infinest](https://infine.st/)'s original patch
([romhacking.net](https://www.romhacking.net/hacks/4450/)).

The button-check in the Pokegear clock menu is also patched so the A button
no longer exits the clock screen (needed so "hold A to fast-forward" doesn't
also close the menu).

## Enabling

Add `_NORTC` to the game's `; builds` line, and declare the game-version
offsets `code.asm` needs (all disassembly-derived — see
[docs/CONFIG-KEYS.md](../../../docs/CONFIG-KEYS.md#rtc-srcfeaturesrtc) for
what each one is):

```asm
DEF FarCall EQU $8
DEF hJoypadDown EQU $ffa4
DEF wStartDay_ EQU $d4b6
DEF wScriptFlags EQU $d434
DEF wSpriteAnimAddrBackup EQU $c3b8
DEF wSpriteAnimAddrBackup_Value EQU $c3
DEF wJumptableIndex EQU $cf63
DEF UpdateTime_FixTime_ EQU $05ad
DEF FixTime_ EQU $061d
DEF PokegearClock_Joypad_buttoncheck_ EQU $4f45
DEF PokegearClock_Joypad_BANK EQU $24
free_space_rom0 ...
free_space_romx ...
```

Only known-complete for Pokemon Crystal (USA/Europe) so far — see
[`games/Pokemon - Crystal Version (USA, Europe).gbc.asm`](../../../games/Pokemon%20-%20Crystal%20Version%20%28USA%2C%20Europe%29.gbc.asm)
for a working example. Gold/Silver support (and normalizing these key names
once their full set is known) is tracked in
[docs/IMPLEMENTATION-PLAN.md](../../../docs/IMPLEMENTATION-PLAN.md) step 4.17.

## Footprint (measured via `rgblink -m`, Pokemon Crystal)

| Region | Size |
| --- | --- |
| ROM0 | $7 bytes (farcall stub) |
| ROMX | $A1 bytes (the time-changer routine) |

## Licence

GPL-3.0-only (infinest, disassembled by Robin Bertram with permission).
