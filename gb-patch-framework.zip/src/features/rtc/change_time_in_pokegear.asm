; ------------------------------------------------------------------------------
;                      Pokemon G/S/C - RTC Changer patches
;       original patches by infinest can be found here: https://infine.st/
;                 disassembled with permission by Robin Bertram
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2019  infinest
; SPDX-FileCopyrightText: 2024  Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only
; ------------------------------------------------------------------------------

; Entered from the Pokegear clock menu (via the bank-0 ChangeTimeInPokegear
; stub). Only actually adjusts the clock if the menu's own state machine is
; in exactly the right place (wScriptFlags/wSpriteAnimAddrBackup/
; wJumptableIndex all at their "waiting on the clock screen" values) —
; otherwise falls straight through to FixAndUpdateTime, leaving UpdateTime's
; normal behavior untouched.
_ChangeTimeInPokegear::

ld hl,FixAndUpdateTime
ld a,[wScriptFlags]
cp a,4
jr z,.continue1          ; continue or
jp hl               ; jump to FixAndUpdateTime

.continue1:
ld a,[wSpriteAnimAddrBackup + 1]
cp a,wSpriteAnimAddrBackup_Value
jr z,.continue2          ; continue or
jp hl               ; jump to FixAndUpdateTime

.continue2:
ld a,[wJumptableIndex]
cp a,1
jr z,.checkAButton  ; continue or
jp hl               ; jump to FixAndUpdateTime

.checkAButton:
ld b,1
ldh a,[hJoypadDown]
and a,PAD_A
jr z,.checkUpButton
ld b,8
.checkUpButton:
ldh a,[hJoypadDown]
and a,PAD_UP
jr z,.checkDownButton
call increaseTime
.checkDownButton
ldh a,[hJoypadDown]
and a,PAD_DOWN
jr z,.noChange
call decreaseTime
.noChange:
jp hl               ; jump to FixAndUpdateTime
