; ------------------------------------------------------------------------------
;                      Pokemon G/S/C - RTC Changer patches
;       original patches by infinest can be found here: https://infine.st/
;                 disassembled with permission by Robin Bertram
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2019  infinest
; SPDX-FileCopyrightText: 2024  Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only
; ------------------------------------------------------------------------------



MACRO farcall ; bank, address
	ld a, BANK(\1)
	ld hl, \1
	rst FarCall
ENDM

; Bank-0 stub reachable from anywhere in the ROM (rst FarCall requires the
; target to be callable without a bank switch first): jumps into the real
; routine (_ChangeTimeInPokegear, romx) via a farcall.
ChangeTimeInPokegear::
	farcall _ChangeTimeInPokegear
	ret
