; ------------------------------------------------------------------------------
;                      Pokemon G/S/C - RTC Changer patches
;       original patches by infinest can be found here: https://infine.st/
;                 disassembled with permission by Robin Bertram
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2019  infinest
; SPDX-FileCopyrightText: 2024  Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only
; ------------------------------------------------------------------------------

; Runs the original, unmodified FixTime and then rejoins UpdateTime right
; after the hook (see code.asm's hook_jp) — the normal continuation for any
; call into _ChangeTimeInPokegear that didn't actually adjust the clock.
FixAndUpdateTime:
call FixTime                 ; orig unmodified function
jp UpdateTime_afterFixTime   ; in UpdateTime (after our modified call to FixTime - run farcall GetTimeOfDay, then ret)
