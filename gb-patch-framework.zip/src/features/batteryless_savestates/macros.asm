; ------------------------------------------------------------------------------
; Config-time API for _SAVESTATES + _BATTERYLESS combination code
;
; Included early (src/main.asm step 2, whenever _SAVESTATES or _BATTERYLESS
; is set) because these macros are called from whichever of
; savestates/code.asm or batteryless/code.asm assembles first — the macro
; bodies aren't evaluated until invoked at step 4, well after the game
; config has resolved GB_COMPATIBILITY, so defining them this early is
; safe. Every call site exists in the savestates-only and batteryless-only
; builds too, so each macro is a no-op unless the combination (and, where
; relevant, the matching GB_COMPATIBILITY shape) is actually active.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

; Called from load_and_save.asm's SAVE_GAME, before anything else runs.
; Feature 1b: nothing is staged in dedicated SRAM banks at all —
; persist_batteryless_savestate_to_flash (batteryless_savestates.asm)
; captures everything directly from live hardware and flashes it. It runs
; here, NOT from ABORT_LOAD like the DMG-shape bridge below: ABORT_LOAD
; turns the screen back on first, and OAM/VRAM/palette RAM don't read
; reliably while the PPU is running — the capture needs the screen still
; off from PREPARE_FOR_SAVE_OR_LOAD.
MACRO batteryless_savestates_save_hook
IF GB_COMPATIBILITY == CART_COMPATIBLE_GBC && DEF(_BATTERYLESS)
    call persist_batteryless_savestate_to_flash
    jp ABORT_LOAD
ENDC
ENDM

; Called from load_and_save.asm's LOAD_GAME, before anything else runs.
MACRO batteryless_savestates_load_hook
IF GB_COMPATIBILITY == CART_COMPATIBLE_GBC && DEF(_BATTERYLESS)
    call check_batteryless_savestate_present   ; z iff a state is present
IF DEF(batteryless_savestate_debug)
    jp z, .batteryless_savestate_present
    call batteryless_savestate_debug_fail_buzz   ; no state in flash — the load is a no-op
    jp ABORT_LOAD
.batteryless_savestate_present:
ELSE
    jp nz, ABORT_LOAD
ENDC
    ; jp, not call: the restore overwrites every WRAM bank — including
    ; wherever the current stack (and any return address) lives. It ends
    ; on the restored save-time stack and jumps into ABORT_LOAD itself.
    jp restore_batteryless_savestate
ENDC
ENDM

; Called from load_and_save.asm's shared ABORT_LOAD tail (the DMG shape
; only — Feature 1b hooks SAVE_GAME/LOAD_GAME directly instead, above).
; On a completed save (not a load, and not an aborted load), persists the
; save-state banks to flash so they survive a power cycle. See
; FEATURES.md Feature 1 for why this reads a flag instead of having a
; save-only exit point (there isn't one; all three cases share this tail).
MACRO batteryless_savestates_persist_hook
IF DEF(_BATTERYLESS) && GB_COMPATIBILITY != CART_COMPATIBLE_GBC
    ld a,[save_or_load_flag]
    and a
    call z,persist_savestate_to_flash
ENDC
ENDM

; Called from batteryless_boot (batteryless/batteryless_boot.asm), after
; the game's own save is restored from flash. Restores a save state too,
; but only for the DMG shape (dedicated SRAM banks,
; batteryless_savestates_dmg_nosram.asm) — Feature 1b's flash-direct CGB
; shape restores from LOAD_GAME instead (batteryless_savestates_load_hook
; above), triggered by the joypad combo like any other load, not at boot.
MACRO batteryless_savestates_boot_hook
IF DEF(_SAVESTATES) && GB_COMPATIBILITY != CART_COMPATIBLE_GBC
    call restore_savestate_from_flash
ENDC
ENDM
