; ------------------------------------------------------------------------------
; Features — config-time API aggregate
;
; Pulls in every feature's config-time macro API. Included once from
; src/main.asm, before the game config — so a game config can call any
; feature's macros regardless of which features are actually enabled for
; this build.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

IF DEF(_SAVESTATES)
INCLUDE "src/features/savestates/macros.asm"
ENDC
; unconditional, unlike the savestates macros above: legacy game configs
; (src/features/savestates/legacy_includes.asm) place load_and_save.asm's
; code themselves via a SECTION, without ever passing -D_SAVESTATES, so a
; DEF(_SAVESTATES) guard here would leave its batteryless_savestates_*_hook
; calls undefined for them
INCLUDE "src/features/batteryless_savestates/macros.asm"
