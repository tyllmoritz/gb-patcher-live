; ------------------------------------------------------------------------------
; Save-states menu — minimal trigger and dispatch
;
; Included by code.asm when SAVESTATES_MENU_TRIGGERED is declared.
; Opt-in: zero footprint for games that don't declare the menu trigger.
;
; This is a minimal implementation that handles:
;   - Menu trigger (keypress combo or boot address)
;   - Entry dispatch (save, load, slot select, exit)
;
; Full text rendering is not implemented yet — it will be added in a future
; iteration when the build system can generate PackBits-compressed font data.
;
; Current behavior:
;   - COMBO trigger: checks button combination in joypad hook
;   - BOOT trigger: patches game code at specified address
;   - Entry dispatch: calls the appropriate routine (SAVE_GAME, LOAD_GAME, etc.)
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

; WRAM state variables
DEF MENU_STATE_ADDR       EQU $BFA0     ; current menu state (0=idle, 1=open)
DEF MENU_SELECTED_ADDR    EQU $BFA1     ; currently highlighted entry index
DEF MENU_LAST_KEYS_ADDR   EQU $BFA2     ; last frame's joypad keys (debounce)
DEF MENU_FRAME_COUNT_ADDR EQU $BFA3     ; frame counter for key repeat delay

DEF MENU_STATE_IDLE       EQU 0
DEF MENU_STATE_OPEN       EQU 1


; ==============================================================================
; MENU CHECK — called from joypad hook to check trigger and handle input
; ==============================================================================

MENU_CHECK_TRIGGER:
    ld a, [MENU_STATE_ADDR]
    cp MENU_STATE_OPEN
    jr z, MENU_HANDLE_INPUT
    ; Idle state: check if trigger combo is pressed
    IF DEF(SAVESTATES_MENU_TRIGGER_TYPE) && SAVESTATES_MENU_TRIGGER_TYPE == 0
        bit SAVESTATES_MENU_COMBO_BIT1, c
        jr z, .skip
        bit SAVESTATES_MENU_COMBO_BIT2, c
        jr z, .skip
        ld a, [MENU_FRAME_COUNT_ADDR]
        and $07
        jr nz, .skip
        ld a, [MENU_LAST_KEYS_ADDR]
        and $03
        jr z, .skip
        ld a, MENU_STATE_OPEN
        ld [MENU_STATE_ADDR], a
        xor a
        ld [MENU_SELECTED_ADDR], a
        ; Flash screen briefly to indicate menu open
        ld hl, $ff40
        res 7, [hl]
        ld a, [MENU_FRAME_COUNT_ADDR]
        and $03
        add 4
        add a
        add a
        ldh [$ff00+$44], a
        ld a, [MENU_FRAME_COUNT_ADDR]
        and $03
        add 4
        add a
        add a
        ldh [$ff00+$44], a
        ld hl, $ff40
        set 7, [hl]
.skip:
    ENDIF
    ret


; ==============================================================================
; MENU INPUT — handle D-pad navigation and button presses
; ==============================================================================

MENU_HANDLE_INPUT:
    ld b, c                ; b = current joypad keys

    ; B button: close menu (return to game)
    bit 1, b
    jr nz, MENU_CLOSE

    ; A button: select current entry
    bit 0, b
    jr nz, MENU_SELECT

    ; UP/DOWN: navigate entries (with repeat delay)
    bit 6, b               ; UP
    jr z, .chk_down
    ld a, [MENU_FRAME_COUNT_ADDR]
    and $07
    jr z, .chk_down
    ld a, [MENU_LAST_KEYS_ADDR]
    bit 6, a
    jr nz, .chk_down
    ld a, [MENU_SELECTED_ADDR]
    cp SAVESTATES_MENU_ENTRY_IDX
    jr z, .chk_down
    dec a
    ld [MENU_SELECTED_ADDR], a
    ld a, [MENU_LAST_KEYS_ADDR]
    set 6, a
    ld [MENU_LAST_KEYS_ADDR], a
    jp .skip_input

.chk_down:
    bit 7, b               ; DOWN
    jr z, .no_nav
    ld a, [MENU_FRAME_COUNT_ADDR]
    and $07
    jr z, .no_nav
    ld a, [MENU_LAST_KEYS_ADDR]
    bit 7, a
    jr nz, .no_nav
    ld a, [MENU_SELECTED_ADDR]
    inc a
    cp SAVESTATES_MENU_ENTRY_IDX
    jr z, .no_nav
    ld [MENU_SELECTED_ADDR], a
    ld a, [MENU_LAST_KEYS_ADDR]
    set 7, a
    ld [MENU_LAST_KEYS_ADDR], a
    jp .skip_input

.no_nav:
    ld a, b
    ld [MENU_LAST_KEYS_ADDR], a

.skip_input:
    ret


; ==============================================================================
; MENU SELECT — execute the selected entry routine
; ==============================================================================

MENU_SELECT:
    ld a, [MENU_SELECTED_ADDR]
    ld b, a                ; save entry index
    xor a
    ld [joypad], a
    ; Call entry routine via jump table (indirect jp)
    ld hl, MENU_ENTRY_JUMPTABLE
    ld c, a
    add l
    ld l, a
    ld a, 0
    adc h
    ld h, a
    ld a, [hl]
    inc hl
    ld h, [hl]
    ld l, a
    jp [hl]


; ==============================================================================
; MENU CLOSE — return to game
; ==============================================================================

MENU_CLOSE:
    ld a, MENU_STATE_IDLE
    ld [MENU_STATE_ADDR], a
    xor a
    ld [joypad], a
    ret


; ==============================================================================
; ENTRY JUMP TABLE — one DW per declared menu entry
; ==============================================================================

MENU_ENTRY_JUMPTABLE:
IF DEF(SAVESTATES_MENU_ENTRY_IDX)
IF DEF(MENU_ENTRY_0_ROUTINE)
    DW MENU_ENTRY_0_ROUTINE
ENDC
IF DEF(MENU_ENTRY_1_ROUTINE)
    DW MENU_ENTRY_1_ROUTINE
ENDC
IF DEF(MENU_ENTRY_2_ROUTINE)
    DW MENU_ENTRY_2_ROUTINE
ENDC
IF DEF(MENU_ENTRY_3_ROUTINE)
    DW MENU_ENTRY_3_ROUTINE
ENDC
IF DEF(MENU_ENTRY_4_ROUTINE)
    DW MENU_ENTRY_4_ROUTINE
ENDC
IF DEF(MENU_ENTRY_5_ROUTINE)
    DW MENU_ENTRY_5_ROUTINE
ENDC
IF DEF(MENU_ENTRY_6_ROUTINE)
    DW MENU_ENTRY_6_ROUTINE
ENDC
IF DEF(MENU_ENTRY_7_ROUTINE)
    DW MENU_ENTRY_7_ROUTINE
ENDC
ENDC


; ==============================================================================
; ENTRY ROUTINES
; ==============================================================================

savestates_menu_slot_select:
    ld a, [SAVESTATES_MENU_SLOT_ADDRESS]
    inc a
    cp SAVESTATES_MENU_SLOT_COUNT
    jr nz, .save_slot
    xor a
.save_slot:
    ld [SAVESTATES_MENU_SLOT_ADDRESS], a
    ret

savestates_menu_exit:
    ret

; Boot-time menu open stub — called from ROM0 boot address
MENU_OPEN_BOOT:
    xor a
    ld [MENU_STATE_ADDR], a
    ld [MENU_SELECTED_ADDR], a
    ld [MENU_LAST_KEYS_ADDR], a
    ld [MENU_FRAME_COUNT_ADDR], a
    ld a, MENU_STATE_OPEN
    ld [MENU_STATE_ADDR], a
    ret
