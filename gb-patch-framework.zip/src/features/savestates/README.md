# savestates

Adds save states — suspend and resume play at any point — to Game Boy /
Game Boy Color games on real hardware, from
[mattcurrie/gb-save-states](https://github.com/mattcurrie/gb-save-states).
The player triggers a save or load with a joypad combo; the game's screen,
VRAM, WRAM, and SRAM (if any) are copied to/from a save-state slot in the
cartridge's extended SRAM, PackBits-compressed on DMG games (CGB games skip
compression — they need the SRAM bandwidth for VRAM banks instead).

## Enabling

Add `_SAVESTATES` to the game's `; builds` line. See
[docs/HOW-TO.md](../../../docs/HOW-TO.md) for a full walkthrough of adding a
new game, and [`macros.asm`](macros.asm) for the joypad-hook macro
reference (`savestates_joypad_hook`, `_banked`, `_banked_split`,
`_vblank_hook`) plus `savestates_marker`/`savestates_payload_in_rom0*`.

## Config keys

See [docs/CONFIG-KEYS.md](../../../docs/CONFIG-KEYS.md#savestates-srcfeaturessavestates)
for the full table (`joypad`, `current_rom_bank`, `is_cgb`,
`game_uses_save_ram`, `uses_mbc5`, `current_nr34_value`, …).

## Footprint (measured via `rgblink -m`, actual figures vary by game)

| Region | Alleyway (DMG) | Notes |
| --- | --- | --- |
| ROM0 (relocated joypad read) | $37 bytes | only for the standard (non-banked) joypad hook |
| ROM0 (boot trampoline, if reset_ram is used) | $F bytes | shared with any other `on_boot_inline` user |
| ROMX (save/load payload) | $1FB bytes | CGB games need more (extra VRAM bank, palettes — budget ~$315) |

## Cartridge requirements (real hardware)

A flash cart with MBC1/5 and 32KB save RAM for plain GB games, 128KB save
RAM for GBC games or GB games that already use their own SRAM save
([SRAM capacity test ROM](https://github.com/eievui5/sram128/releases/tag/v1.0.1)).

## Controls

After pressing a combo, the screen flashes while the save/load process runs.

- Save: hold Down + press Start, or hold Select + press A
- Load: hold Up + press Start, or hold Select + press B

## Known limitations

- Sound/music cannot always be restored 100% due to some sound registers
  being read-only; pausing and resuming can sometimes fix it. Wave-RAM
  audibility after a load may need `current_nr34_value` (or the less
  reliable `restore_wave_ram` fallback) — see step 14 in
  [docs/HOW-TO.md](../../../docs/HOW-TO.md).
- Kirby's Dream Land's hidden title-screen combos
  (Select+Down+B / Select+Up+A) are remapped to Down+B / Up+A to avoid
  conflicting with the save/load combos.

## Licence

MIT (Matt Currie) — see individual file headers.
