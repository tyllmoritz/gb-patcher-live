; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2017-2024 Matt Currie
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

;***************************************************************************
;
; Resets the internal RAM ($c000-$dfff) at startup, so the PackBits RLE can
; compress unused internal RAM efficiently. For games that do not clear
; their RAM themselves.
;
; Boot-hook macro: including this file only defines the macro; register it
; from the game config with
;
;     INCLUDE "src/features/savestates/reset_ram.asm"
;     on_boot_inline reset_ram
;
; 12 bytes in the boot trampoline. Preserves a (the hardware revision the
; game may check at its entry point); clobbers b, hl and the flags — safe at
; boot, before the game runs.
;
;***************************************************************************

MACRO reset_ram
    ld b,a          ; preserve the value of the a register

    ld hl,$c000
    ld a,$ff
.reset_ram_loop\@
    ld [hl+],a
    bit 5,h         ; bit 5 will be set when the h register reaches $e0
    jr z,.reset_ram_loop\@

    ld a,b          ; restore the value of the a register
ENDM
