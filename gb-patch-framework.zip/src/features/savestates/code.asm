; ------------------------------------------------------------------------------
; Save-states feature — code placement
;
; Included by src/main.asm after the game config. Places the save/load state
; machinery from https://github.com/mattcurrie/gb-save-states into the free
; space declared by the game config.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2017-2024 Matt Currie
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

INCLUDE "src/features/savestates/defines.asm"

; save states are stored in (enlarged) SRAM — adjust the cartridge header if
; needed. CARTRIDGE_TYPE (a CART_ROM_* constant, third_party/hardware.inc/
; hardware_compat.inc) documents the game's actual, original cartridge
; type — except when a game config pre-declares CHANGE_CARTRIDGE_TYPE
; itself to force a conversion CARTRIDGE_TYPE's own true value wouldn't
; otherwise indicate (e.g. Pokemon Red is genuinely MBC3 but is
; deliberately converted to MBC5 — see its own config comment), in which
; case resolve_cartridge_type (src/core/header.asm, called from
; src/main.asm right after the game config) has already redefined
; CARTRIDGE_TYPE to match, so everything below only ever needs to look at
; CARTRIDGE_TYPE itself.
;
; The whole MBC5 range (CART_ROM_MBC5 through CART_ROM_MBC5_RAM_BAT_RUMBLE)
; needs the wider $2000/$3000 bank-select protocol, not just the exact
; CART_ROM_MBC5 value. Games that don't declare CARTRIDGE_TYPE default to
; the plain-MBC1 target, same as always.
DEF _CARTRIDGE_TYPE_IS_MBC5 EQU 0
IF DEF(CARTRIDGE_TYPE)
    IF CARTRIDGE_TYPE >= CART_ROM_MBC5 && CARTRIDGE_TYPE <= CART_ROM_MBC5_RAM_BAT_RUMBLE
        REDEF _CARTRIDGE_TYPE_IS_MBC5 EQU 1
    ENDC
ENDC
IF _CARTRIDGE_TYPE_IS_MBC5
    DEF _TARGET_CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT
ELSE
    DEF _TARGET_CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT
ENDC
; only patch the header if the game's declared type isn't already the
; target (e.g. Balloon Fight GB is already CART_ROM_MBC5_RAM_BAT, and any
; game whose CHANGE_CARTRIDGE_TYPE was pre-declared now has a matching
; CARTRIDGE_TYPE too, so this is also correctly a no-op for them) — games
; with no CARTRIDGE_TYPE at all have nothing to compare against, so always
; patch (matches every build before this distinction existed). The outer
; !DEF guard is just a safety net against redefining a pre-declared
; CHANGE_CARTRIDGE_TYPE that (hypothetically) doesn't exactly match the
; range-check target.
IF !DEF(CHANGE_CARTRIDGE_TYPE)
    IF DEF(CARTRIDGE_TYPE)
        IF CARTRIDGE_TYPE != _TARGET_CARTRIDGE_TYPE
            DEF CHANGE_CARTRIDGE_TYPE EQU _TARGET_CARTRIDGE_TYPE
        ENDC
    ELSE
        DEF CHANGE_CARTRIDGE_TYPE EQU _TARGET_CARTRIDGE_TYPE
    ENDC
ENDC
DEF CHANGE_RAM_SIZE EQU RAMSIZE

IF !DEF(JOYPAD_HOOK_VARIANT)
    FAIL "savestates: the game config must use one of the joypad_hook* macros or joypad_vblank_hook (src/core/hooks/joypad/macros.asm)"
ENDC
IF !DEF(SAVESTATES_MARKER)
    DEF SAVESTATES_MARKER EQUS "--- Save Patch ---"
ENDC

IF JOYPAD_HOOK_VARIANT == 0 && !DEF(JOYPAD_CUSTOM_RELOCATED_READ)
    ; standard variant: the relocated joypad read runs from ROM0 free space
    ; (or the second ROM0 region, if free_space_rom0 is already spoken for —
    ; see joypad_relocated_read_in_rom0_b)
    IF !DEF(JOYPAD_RELOCATED_READ_REGION)
        DEF JOYPAD_RELOCATED_READ_REGION EQU 1
    ENDC
    IF JOYPAD_RELOCATED_READ_REGION == 2
        rom0_code_b
    ELIF JOYPAD_RELOCATED_READ_REGION == 3
        rom0_code_c
    ELSE
        rom0_code
    ENDC
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    end_code
ENDC

IF JOYPAD_HOOK_VARIANT == 2
    ; vblank variant: the vector at $0040 and the handler body (fixed address,
    ; taken from the game config via `vblank_handler`) are placed directly —
    ; not through the free-space region API, since the vector location is
    ; hardware-mandated and the handler body needs one exact address anyway
    INCLUDE "src/core/hooks/joypad/vblank_handler.asm"
ENDC

IF !DEF(SAVESTATES_PAYLOAD_REGION)
    DEF SAVESTATES_PAYLOAD_REGION EQU 0
ENDC
IF SAVESTATES_PAYLOAD_REGION == 1
    rom0_code
ELIF SAVESTATES_PAYLOAD_REGION == 2
    rom0_code_b
ELSE
    romx_code
ENDC
    DB "{SAVESTATES_MARKER}"
IF (JOYPAD_HOOK_VARIANT == 1 || JOYPAD_HOOK_VARIANT == 2) && !DEF(JOYPAD_CUSTOM_RELOCATED_READ)
    ; banked & vblank variants: joypad read and check live next to the state
    ; machinery (relocated_read_from_joypad is bank-switched to from ROM0)
    INCLUDE "src/core/hooks/joypad/read_and_check.asm"
ENDC
    INCLUDE "src/features/savestates/save_state_includes.asm"

    end_code
