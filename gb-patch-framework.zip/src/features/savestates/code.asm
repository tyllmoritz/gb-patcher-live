; ------------------------------------------------------------------------------
; Save-states feature — code placement
;
; Included by src/main.asm after the game config. Places the save/load state
; machinery from https://github.com/mattcurrie/gb-save-states into the free
; space declared by the game config.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2017-2024 Matt Currie
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

INCLUDE "src/features/savestates/defines.asm"

; save states are stored in (enlarged) SRAM — adjust the cartridge header
IF DEF(uses_mbc5)
    DEF CHANGE_CART_TYPE EQU CART_ROM_MBC5_RAM_BAT
ELSE
    DEF CHANGE_CART_TYPE EQU CART_ROM_MBC1_RAM_BAT
ENDC
DEF CHANGE_RAM_SIZE EQU RAMSIZE

IF !DEF(SAVESTATES_JOYPAD_VARIANT)
    FAIL "savestates: the game config must use one of the savestates_joypad_hook* macros or savestates_vblank_hook"
ENDC
IF !DEF(SAVESTATES_MARKER)
    DEF SAVESTATES_MARKER EQUS "--- Save Patch ---"
ENDC

IF SAVESTATES_JOYPAD_VARIANT == 0
    ; standard variant: the relocated joypad read runs from ROM0 free space
    ; (or the second ROM0 region, if free_space_rom0 is already spoken for —
    ; see savestates_relocated_read_in_rom0_b)
    IF !DEF(SAVESTATES_RELOCATED_READ_REGION)
        DEF SAVESTATES_RELOCATED_READ_REGION EQU 1
    ENDC
    IF SAVESTATES_RELOCATED_READ_REGION == 2
        rom0_code_b
    ELIF SAVESTATES_RELOCATED_READ_REGION == 3
        rom0_code_c
    ELSE
        rom0_code
    ENDC
    INCLUDE "src/features/savestates/relocated_read_from_joypad.asm"
    end_code
ENDC

IF SAVESTATES_JOYPAD_VARIANT == 2
    ; vblank variant: the vector at $0040 and the handler body (fixed address,
    ; taken from the game config via `vblank_handler`) are placed directly —
    ; not through the free-space region API, since the vector location is
    ; hardware-mandated and the handler body needs one exact address anyway
    INCLUDE "src/features/savestates/vblank_handler.asm"
ENDC

IF !DEF(SAVESTATES_PAYLOAD_REGION)
    DEF SAVESTATES_PAYLOAD_REGION EQU 0
ENDC
IF SAVESTATES_PAYLOAD_REGION == 1
    rom0_code
ELIF SAVESTATES_PAYLOAD_REGION == 2
    rom0_code_b
ELSE
    romx_code
ENDC
    DB "{SAVESTATES_MARKER}"
IF SAVESTATES_JOYPAD_VARIANT == 1 || SAVESTATES_JOYPAD_VARIANT == 2
    ; banked & vblank variants: joypad read and check live next to the state
    ; machinery (relocated_read_from_joypad is bank-switched to from ROM0)
    INCLUDE "src/features/savestates/joypad_read_and_check.asm"
ENDC
    INCLUDE "src/features/savestates/save_state_includes.asm"

    ; Menu system — opt-in, only included when SAVESTATES_MENU_TRIGGERED is set
    IF DEF(SAVESTATES_MENU_TRIGGERED)
        ; Boot trigger stub: if using BOOT trigger, patch the game's code
        ; at SAVESTATES_MENU_BOOT_ADDR with a call to MENU_OPEN_BOOT.
        ; The stub is 3 bytes (call nnnn) and replaces 3 bytes of game code.
        IF DEF(SAVESTATES_MENU_TRIGGER_TYPE) && SAVESTATES_MENU_TRIGGER_TYPE == 1
            patch_rom 0, SAVESTATES_MENU_BOOT_ADDR
            call MENU_OPEN_BOOT
            end_patch
        ENDC
        INCLUDE "src/features/savestates/menu.asm"
        INCLUDE "src/features/savestates/menu_entries.asm"
    ENDC

    end_code
