; ------------------------------------------------------------------------------
; Check for save combo — split joypad hook
;
; Evaluates all savestates_save_combo fragments. Returns a=1 if any match,
; a=0 otherwise.
;
; Only used when SAVESTATES_SPLITS is defined (i.e., when at least one
; savestates_save_combo or savestates_load_combo was declared).
; When not used, joypad_check.asm calls CHECK_FOR_SAVE_OR_LOAD_GAME directly.
;
; Supports up to 8 save combos (SAVE_COMBO_0 through SAVE_COMBO_7).
; Only active combos emit code.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

CHECK_FOR_SAVE_COMBO:
IF DEF(SAVESTATES_SAVE_DECLARED)
    ; Evaluate save combos in order; first match returns a=1
    ; Each combo is: bit BIT1, a / jr nz, .match / bit BIT2, a / jr z, .next
    ; Only active combos emit code
IF DEF(SAVE_COMBO_0_ACTIVE)
    bit SAVE_COMBO_0_BIT1, a
    jr nz, .sc0_bit2
    bit SAVE_COMBO_0_BIT2, a
    jr z, .sc1
.sc0_bit2:
    ld a, 1
    ret
.sc1:
ENDC
IF DEF(SAVE_COMBO_1_ACTIVE)
    bit SAVE_COMBO_1_BIT1, a
    jr nz, .sc2_bit2
    bit SAVE_COMBO_1_BIT2, a
    jr z, .sc3
.sc2_bit2:
    ld a, 1
    ret
.sc3:
ENDC
IF DEF(SAVE_COMBO_2_ACTIVE)
    bit SAVE_COMBO_2_BIT1, a
    jr nz, .sc4_bit2
    bit SAVE_COMBO_2_BIT2, a
    jr z, .sc5
.sc4_bit2:
    ld a, 1
    ret
.sc5:
ENDC
IF DEF(SAVE_COMBO_3_ACTIVE)
    bit SAVE_COMBO_3_BIT1, a
    jr nz, .sc6_bit2
    bit SAVE_COMBO_3_BIT2, a
    jr z, .sc7
.sc6_bit2:
    ld a, 1
    ret
.sc7:
ENDC
IF DEF(SAVE_COMBO_4_ACTIVE)
    bit SAVE_COMBO_4_BIT1, a
    jr nz, .sc8_bit2
    bit SAVE_COMBO_4_BIT2, a
    jr z, .sc9
.sc8_bit2:
    ld a, 1
    ret
.sc9:
ENDC
IF DEF(SAVE_COMBO_5_ACTIVE)
    bit SAVE_COMBO_5_BIT1, a
    jr nz, .scA_bit2
    bit SAVE_COMBO_5_BIT2, a
    jr z, .scB
.scA_bit2:
    ld a, 1
    ret
.scB:
ENDC
IF DEF(SAVE_COMBO_6_ACTIVE)
    bit SAVE_COMBO_6_BIT1, a
    jr nz, .scC_bit2
    bit SAVE_COMBO_6_BIT2, a
    jr z, .scD
.scC_bit2:
    ld a, 1
    ret
.scD:
ENDC
IF DEF(SAVE_COMBO_7_ACTIVE)
    bit SAVE_COMBO_7_BIT1, a
    jr nz, .scE_bit2
    bit SAVE_COMBO_7_BIT2, a
    jr z, .scF
.scE_bit2:
    ld a, 1
    ret
.scF:
ENDC
    xor a
    ret
ELSE
    ; Legacy: no splits declared — caller uses CHECK_FOR_SAVE_OR_LOAD_GAME
    xor a
    ret
ENDC
