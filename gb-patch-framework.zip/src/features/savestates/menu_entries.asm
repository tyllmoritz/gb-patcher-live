; ------------------------------------------------------------------------------
; Save-states menu — built-in menu entries
;
; Included by code.asm when SAVESTATES_MENU_TRIGGERED is declared.
; Defines the built-in menu entry labels and types.
;
; Entries:
;   SAVE — calls SAVE_GAME (saves current game state)
;   LOAD — calls LOAD_GAME (loads saved game state)
;   SLOT — calls savestates_menu_slot_select (cycles save slot)
;   EXIT — returns to game without save/load
;
; Game configs can add custom entries using savestates_menu_entry.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

; Built-in entry labels — each is a null-terminated string ($FF = end)
; These are referenced by MENU_ENTRY_LABELS in menu.asm

; Entry 0: Save
IF !DEF(MENU_ENTRY_0_LABEL)
    DEF SAVESTATES_MENU_ENTRY_IDX EQU 0
ENDIF

; Declare built-in entries if not already declared by game config
IF !DEF(MENU_ENTRY_0_LABEL)
    ; Entry 0: Save
    savestates_menu_entry SAVE, "Save", SAVE_GAME
ENDIF

IF !DEF(MENU_ENTRY_1_LABEL)
    ; Entry 1: Load
    savestates_menu_entry LOAD, "Load", LOAD_GAME
ENDIF

IF !DEF(MENU_ENTRY_2_LABEL) && DEF(SAVESTATES_MENU_SLOT_SELECT)
    ; Entry 2: Slot select (only if slot select is declared)
    savestates_menu_entry SLOT, "Slot", savestates_menu_slot_select
ENDIF

IF !DEF(MENU_ENTRY_2_LABEL) && !DEF(SAVESTATES_MENU_SLOT_SELECT)
    ; Entry 2: Exit (when no slot select)
    savestates_menu_entry EXIT, "Exit", savestates_menu_exit
ELIF !DEF(MENU_ENTRY_3_LABEL)
    ; Entry 3: Exit (when slot select is present)
    savestates_menu_entry EXIT, "Exit", savestates_menu_exit
ENDIF

; If no entries were declared at all, declare defaults
IF !DEF(SAVESTATES_MENU_ENTRY_IDX) || SAVESTATES_MENU_ENTRY_IDX == 0
    savestates_menu_entry SAVE, "Save", SAVE_GAME
    savestates_menu_entry LOAD, "Load", LOAD_GAME
    IF DEF(SAVESTATES_MENU_SLOT_SELECT)
        savestates_menu_entry SLOT, "Slot", savestates_menu_slot_select
    ENDC
    savestates_menu_entry EXIT, "Exit", savestates_menu_exit
ENDIF
