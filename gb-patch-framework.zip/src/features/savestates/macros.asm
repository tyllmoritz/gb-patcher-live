; ------------------------------------------------------------------------------
; Save-states feature — config-time API
;
; Required game config declarations:
;   DEF joypad EQU $xxxx          ; where the game stores the joypad value
;                                 ; (optional: joypad_2/joypad_3/joypad_4)
;   free_space_romx ...           ; ~$220 bytes ($315 for CGB) for the
;                                 ; save/load machinery (or free_space_rom0/
;                                 ; free_space_rom0_b if the payload lives in
;                                 ; ROM0 instead — see savestates_payload_at)
; plus exactly one joypad hook:
;
;   savestates_joypad_hook ADDR
;     Standard variant. Overwrites the tail of the game's joypad read routine
;     (the `ld a,$30 / ldh [$00],a` sequence at ADDR, 4 bytes) with a call to
;     relocated_read_from_joypad, which is placed in the declared ROM0 free
;     space (~$40 bytes needed). If that free_space_rom0 region is already
;     used for something else (e.g. an on_boot_inline reset_ram trampoline
;     at a different address), redirect the routine with:
;       savestates_relocated_read_in_rom0_b
;     which places it in the declared free_space_rom0_b region instead
;     (or ..._in_rom0_c / free_space_rom0_c, for the rare game that needs
;     three independent ROM0 windows at once: reset_ram, relocated read,
;     and a ROM0 payload, all at unrelated addresses).
;
;   savestates_joypad_hook_banked BANK, ADDR [, CONTINUE_ADDR]
;     For games without ROM0 free space. Overwrites the game's entire joypad
;     read routine at BANK:ADDR with a bank-switching call into the payload's
;     free space (requires DEF current_rom_bank). Returns with `ret` unless
;     CONTINUE_ADDR is given, in which case it jumps there instead (some
;     games' joypad routines are entered from more than one place and must
;     rejoin shared code afterwards rather than returning to the caller).
;
;   savestates_joypad_hook_banked_split BANK, ADDR1, ADDR2
;     Like _banked, but the original joypad routine is patched over two
;     non-contiguous instructions (some games interleave other code between
;     the routine's setup and its tail).
;
;   savestates_vblank_hook ORIGINAL_HANDLER [, options...]
;     For games whose joypad read only makes sense to call from inside their
;     own vblank interrupt handler. Installs a small vblank stub in ROM0 free
;     space that reads the joypad (bank-switching through
;     relocated_read_from_joypad, itself placed in the payload's free space)
;     and then falls into ORIGINAL_HANDLER. Recognized options (pass as
;     DEF-style words, e.g. `savestates_vblank_hook Handler, use_call`):
;       use_call   - call (not jp) into ORIGINAL_HANDLER (handler returns)
;
; By default the save/load payload goes into the declared ROMX free space.
; If the payload must live in ROM0 instead (either the same free_space_rom0
; region used above, or a second disjoint one), say so once:
;
;   savestates_payload_in_rom0            ; payload shares free_space_rom0
;   savestates_payload_in_rom0_b          ; payload uses free_space_rom0_b
;
; Games whose original code embeds a save-patch banner give it a name
; (default: "--- Save Patch ---"); purely cosmetic, no functional effect:
;
;   savestates_marker --- My Game Save Patch ---   (bare text, no quotes)
;
; Split joypad hook — custom save/load combos (optional):
;
;   savestates_save_combo SELECT, A        ; select + A triggers save
;   savestates_save_combo START, DOWN      ; start + down also triggers save
;   savestates_load_combo SELECT, B        ; select + B triggers load
;   savestates_load_combo START, UP        ; start + up also triggers load
;
; Each macro declares one combination (two buttons). Multiple combos of each
; type can be declared; they are evaluated in order. If no combos are declared
; the legacy combined detection (Select+A/B, Start+Down/Up) is used.
;
; Button names: SELECT, START, A, B, UP, DOWN, LEFT, RIGHT
;
; Optional feature knobs understood by the machinery (see HOW-TO.md):
;   swap_joypad, cpl_joypad, uses_mbc5, is_cgb, game_uses_save_ram,
;   current_sram_bank, current_rom_bank, current_nr34_value, restore_wave_ram
;
; Boot / keypress menu (optional, opt-in):
;
;   savestates_menu_trigger COMBO, START, SELECT
;     Trigger the menu when START+SELECT are held together (checked in the
;     joypad hook). Requires the vblank hook variant is NOT used (menu
;     cannot safely run from an interrupt handler).
;
;   savestates_menu_trigger BOOT, $016e
;     Trigger the menu when the game's boot vector at $016e is reached.
;     The config must also declare free_space_rom0 or free_space_rom0_b
;     large enough for the boot-trampoline stub (~$10 bytes).
;
;   savestates_menu_entry SAVE, "Save", SAVE_GAME
;   savestates_menu_entry LOAD, "Load", LOAD_GAME
;   savestates_menu_entry SLOT, "Slot: $", savestates_menu_slot_select
;   savestates_menu_entry EXIT, "Exit", savestates_menu_exit
;
; Each entry has a label (displayed in the menu) and a routine to call when
; selected. Built-in types SAVE and LOAD call the existing SAVE_GAME /
; LOAD_GAME routines. SLOT calls the slot-select routine (declared below).
; EXIT returns to the game without saving or loading.
;
;   savestates_menu_slot_select SLOT_COUNT, SLOT_ADDRESS
;     Declare a slot-select entry that cycles through SLOT_COUNT save slots
;     (default 1). SLOT_ADDRESS is where the slot number is stored.
;
;   savestates_menu_entries SAVE, LOAD, EXIT
;     Convenience macro: declares the four built-in entries at once.
;     Equivalent to:
;       savestates_menu_entry SAVE, "Save", SAVE_GAME
;       savestates_menu_entry LOAD, "Load", LOAD_GAME
;       savestates_menu_entry EXIT, "Exit", savestates_menu_exit
;     (SLOT entry omitted unless savestates_menu_slot_select is also declared)
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------


MACRO savestates_joypad_hook
    ASSERT !DEF(SAVESTATES_JOYPAD_VARIANT), "savestates joypad hook declared twice"
    DEF SAVESTATES_JOYPAD_VARIANT EQU 0
    PUSHS
    SECTION "savestates: joypad hook", ROM0[(\1)]
    call relocated_read_from_joypad
    nop
    POPS
ENDM

MACRO savestates_joypad_hook_banked
    ASSERT !DEF(SAVESTATES_JOYPAD_VARIANT), "savestates joypad hook declared twice"
    DEF SAVESTATES_JOYPAD_VARIANT EQU 1
    patch_rom \1, \2
    INCLUDE "src/features/savestates/call_relocated_read_from_joypad_in_other_bank.asm"
    IF _NARG >= 3
        jp \3
    ELSE
        ret
    ENDC
    end_patch
ENDM

MACRO savestates_joypad_hook_banked_split
    ASSERT !DEF(SAVESTATES_JOYPAD_VARIANT), "savestates joypad hook declared twice"
    DEF SAVESTATES_JOYPAD_VARIANT EQU 1
    patch_rom \1, \2
    INCLUDE "src/features/savestates/call_relocated_read_from_joypad_in_other_bank_part_1.asm"
    end_patch
    patch_rom \1, \3
    INCLUDE "src/features/savestates/call_relocated_read_from_joypad_in_other_bank_part_2.asm"
    end_patch
ENDM

MACRO savestates_vblank_hook
    ASSERT !DEF(SAVESTATES_JOYPAD_VARIANT), "savestates joypad hook declared twice"
    DEF SAVESTATES_JOYPAD_VARIANT EQU 2
    DEF vblank_handler EQU (\1)
    DEF original_vblank_handler EQU (\2)
    SHIFT
    SHIFT
    REPT _NARG
        DEF \1 EQU 1
        SHIFT
    ENDR
ENDM

MACRO savestates_relocated_read_in_rom0_b
    ASSERT !DEF(SAVESTATES_RELOCATED_READ_REGION), "savestates relocated-read region declared twice"
    DEF SAVESTATES_RELOCATED_READ_REGION EQU 2
ENDM

MACRO savestates_relocated_read_in_rom0_c
    ASSERT !DEF(SAVESTATES_RELOCATED_READ_REGION), "savestates relocated-read region declared twice"
    DEF SAVESTATES_RELOCATED_READ_REGION EQU 3
ENDM

MACRO savestates_payload_in_rom0
    ASSERT !DEF(SAVESTATES_PAYLOAD_REGION), "savestates payload region declared twice"
    DEF SAVESTATES_PAYLOAD_REGION EQU 1
ENDM

MACRO savestates_payload_in_rom0_b
    ASSERT !DEF(SAVESTATES_PAYLOAD_REGION), "savestates payload region declared twice"
    DEF SAVESTATES_PAYLOAD_REGION EQU 2
ENDM

; usage: savestates_marker --- My Game Save Patch ---   (bare, no quotes)
MACRO savestates_marker
    DEF SAVESTATES_MARKER EQUS "\1"
ENDM


; ------------------------------------------------------------------------------
; Split joypad hook — save/load key-combination declarations
;
; By default CHECK_FOR_SAVE_OR_LOAD_GAME (included by joypad_check.asm) uses
; the legacy combined detection: Select+A / Select+B / Start+Down / Start+Up.
;
; To declare custom save and load combos independently, use:
;
;   savestates_save_combo SELECT, A        ; select + A
;   savestates_save_combo START, DOWN      ; start + down
;   savestates_load_combo SELECT, B        ; select + B
;   savestates_load_combo START, UP        ; start + up
;
; Each macro sets a flag (SAVE_COMBO_N / LOAD_COMBO_N) that the check
; routines read to emit the corresponding bit tests. Multiple combos of
; each type can be declared; they are evaluated in order. If no combos
; are declared the legacy combined routine is used (backward-compatible,
; zero footprint for configs that don't declare any savestates_save_combo
; / savestates_load_combo).
;
; Button names recognised by the macros:
;   SELECT, START, A, B, UP, DOWN, LEFT, RIGHT
; ------------------------------------------------------------------------------

; Internal: expand a button name to its bit position (0=A, 1=B, 2=SELECT,
; 3=START, 4=RIGHT, 5=LEFT, 6=UP, 7=DOWN in the joypad register).
MACRO _BUTTON_BIT
    IF \1 == A
        DEF _BTN_BIT EQU 0
    ELIF \1 == B
        DEF _BTN_BIT EQU 1
    ELIF \1 == SELECT
        DEF _BTN_BIT EQU 2
    ELIF \1 == START
        DEF _BTN_BIT EQU 3
    ELIF \1 == RIGHT
        DEF _BTN_BIT EQU 4
    ELIF \1 == LEFT
        DEF _BTN_BIT EQU 5
    ELIF \1 == UP
        DEF _BTN_BIT EQU 6
    ELIF \1 == DOWN
        DEF _BTN_BIT EQU 7
    ELSE
        ASSERT 0, "unknown button: \1"
    ENDC
ENDM

; Declare a save key combination. Sets SAVE_COMBO_N flags that the check
; routine reads to emit bit tests. Multiple save combos can be declared.
MACRO savestates_save_combo
    DEF SAVESTATES_SPLITS EQU 1
    DEF SAVESTATES_SAVE_DECLARED EQU 1
    _BUTTON_BIT \1
    DEF _BIT1 EQU _BTN_BIT
    _BUTTON_BIT \2
    DEF _BIT2 EQU _BTN_BIT
    DEF "SAVE_COMBO_{d:SAVESTATES_SAVE_IDX}_BIT1" EQU _BIT1
    DEF "SAVE_COMBO_{d:SAVESTATES_SAVE_IDX}_BIT2" EQU _BIT2
    DEF "SAVE_COMBO_{d:SAVESTATES_SAVE_IDX}_ACTIVE" EQU 1
    REDEF SAVESTATES_SAVE_IDX = SAVESTATES_SAVE_IDX + 1
ENDM

; Declare a load key combination. Sets LOAD_COMBO_N flags that the check
; routine reads to emit bit tests. Multiple load combos can be declared.
MACRO savestates_load_combo
    DEF SAVESTATES_SPLITS EQU 1
    DEF SAVESTATES_LOAD_DECLARED EQU 1
    _BUTTON_BIT \1
    DEF _BIT1 EQU _BTN_BIT
    _BUTTON_BIT \2
    DEF _BIT2 EQU _BTN_BIT
    DEF "LOAD_COMBO_{d:SAVESTATES_LOAD_IDX}_BIT1" EQU _BIT1
    DEF "LOAD_COMBO_{d:SAVESTATES_LOAD_IDX}_BIT2" EQU _BIT2
    DEF "LOAD_COMBO_{d:SAVESTATES_LOAD_IDX}_ACTIVE" EQU 1
    REDEF SAVESTATES_LOAD_IDX = SAVESTATES_LOAD_IDX + 1
ENDM

; Initialize combo index counters (must be after all macro definitions)
IF !DEF(SAVESTATES_SAVE_IDX)
    DEF SAVESTATES_SAVE_IDX EQU 0
ENDC
IF !DEF(SAVESTATES_LOAD_IDX)
    DEF SAVESTATES_LOAD_IDX EQU 0
ENDC


; ------------------------------------------------------------------------------
; Boot / keypress menu — config-time macros
;
; The menu is opt-in: only games that declare savestates_menu_trigger will have
; the menu code included. This keeps the default footprint at zero for games
; that don't need it.
;
; Trigger types:
;   COMBO, START, SELECT   — trigger on a button combination (in joypad hook)
;   BOOT, $016e            — trigger at a boot-time address (ROM0 stub)
;
; Menu entry types:
;   SAVE — calls SAVE_GAME
;   LOAD — calls LOAD_GAME
;   SLOT — calls savestates_menu_slot_select (slot selector)
;   EXIT — returns to game without save/load
;   CUSTOM — calls a user-defined routine
; ------------------------------------------------------------------------------

; Declare how the menu is triggered. Only one trigger may be declared.
; COMBO, BTN1, BTN2 — trigger when both buttons are held (joypad hook check)
; BOOT, ADDR — trigger when the game reaches this boot address
MACRO savestates_menu_trigger
    ASSERT !DEF(SAVESTATES_MENU_TRIGGERED), "savestates_menu_trigger declared twice"
    DEF SAVESTATES_MENU_TRIGGERED EQU 1
    IF \1 == COMBO
        DEF SAVESTATES_MENU_TRIGGER_TYPE EQU 0
        _BUTTON_BIT \2
        DEF SAVESTATES_MENU_COMBO_BIT1 EQU _BTN_BIT
        _BUTTON_BIT \3
        DEF SAVESTATES_MENU_COMBO_BIT2 EQU _BTN_BIT
    ELIF \1 == BOOT
        DEF SAVESTATES_MENU_TRIGGER_TYPE EQU 1
        DEF SAVESTATES_MENU_BOOT_ADDR EQU (\2)
    ELSE
        ASSERT 0, "savestates_menu_trigger: unknown trigger type: \1"
    ENDC
    ; Menu is incompatible with vblank hook (cannot safely run from ISR)
    IF DEF(SAVESTATES_JOYPAD_VARIANT) && SAVESTATES_JOYPAD_VARIANT == 2
        ASSERT 0, "savestates_menu_trigger: vblank hook variant does not support menu"
    ENDC
ENDM

; Declare a menu entry. LABEL is the text displayed, ROUTINE is the code to
; call when this entry is selected.
; Usage: savestates_menu_entry SAVE, "Save", SAVE_GAME
MACRO savestates_menu_entry
    DEF SAVESTATES_MENU_ENTRIES_DECLARED EQU 1
    DEF "MENU_ENTRY_{d:SAVESTATES_MENU_ENTRY_IDX}_LABEL" EQUS "\2"
    DEF "MENU_ENTRY_{d:SAVESTATES_MENU_ENTRY_IDX}_ROUTINE" EQU (\3)
    DEF "MENU_ENTRY_{d:SAVESTATES_MENU_ENTRY_IDX}_TYPE" EQU (\1)
    REDEF SAVESTATES_MENU_ENTRY_IDX = SAVESTATES_MENU_ENTRY_IDX + 1
ENDM

; Slot select entry: declares that the menu should have a slot selector.
; SLOT_COUNT is the number of save slots (default 1), SLOT_ADDRESS is where
; the current slot number is stored in WRAM.
MACRO savestates_menu_slot_select
    DEF SAVESTATES_MENU_SLOT_SELECT EQU 1
    IF _NARG >= 1
        DEF SAVESTATES_MENU_SLOT_COUNT EQU (\1)
    ELSE
        DEF SAVESTATES_MENU_SLOT_COUNT EQU 1
    ENDC
    IF _NARG >= 2
        DEF SAVESTATES_MENU_SLOT_ADDRESS EQU (\2)
    ELSE
        DEF SAVESTATES_MENU_SLOT_ADDRESS EQU $C000
    ENDC
ENDM

; Convenience macro: declares SAVE, LOAD, and EXIT entries at once.
MACRO savestates_menu_entries
    savestates_menu_entry SAVE, "Save", SAVE_GAME
    savestates_menu_entry LOAD, "Load", LOAD_GAME
    IF DEF(SAVESTATES_MENU_SLOT_SELECT)
        savestates_menu_entry SLOT, "Slot", savestates_menu_slot_select
    ENDC
    savestates_menu_entry EXIT, "Exit", savestates_menu_exit
ENDM

; Initialize menu entry counter (must be after all macro definitions)
IF !DEF(SAVESTATES_MENU_ENTRY_IDX)
    DEF SAVESTATES_MENU_ENTRY_IDX EQU 0
ENDC
