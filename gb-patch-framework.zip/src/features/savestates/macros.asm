; ------------------------------------------------------------------------------
; Save-states feature — config-time API
;
; Required game config declarations:
;   DEF joypad EQU $xxxx          ; where the game stores the joypad value
;                                 ; (optional: joypad_2/joypad_3/joypad_4)
;   free_space_romx ...           ; ~$220 bytes ($315 for CGB) for the
;                                 ; save/load machinery (or free_space_rom0/
;                                 ; free_space_rom0_b if the payload lives in
;                                 ; ROM0 instead — see savestates_payload_at)
; plus exactly one joypad hook (src/core/hooks/joypad/macros.asm — the joypad-hook
; mechanism is generic core infrastructure, not savestates-specific):
;
;   joypad_hook ADDR
;   joypad_hook_banked BANK, ADDR [, CONTINUE_ADDR]
;   joypad_hook_banked_split BANK, ADDR1, ADDR2
;   joypad_vblank_hook ORIGINAL_HANDLER [, options...]
;   joypad_relocated_read_in_rom0_b / _c
;
; See src/core/hooks/joypad/macros.asm for what each one does.
;
; By default the save/load payload goes into the declared ROMX free space.
; If the payload must live in ROM0 instead (either the same free_space_rom0
; region used above, or a second disjoint one), say so once:
;
;   savestates_payload_in_rom0            ; payload shares free_space_rom0
;   savestates_payload_in_rom0_b          ; payload uses free_space_rom0_b
;
; Games whose original code embeds a save-patch banner give it a name
; (default: "--- Save Patch ---"); purely cosmetic, no functional effect:
;
;   savestates_marker --- My Game Save Patch ---   (bare text, no quotes)
;
; Split joypad hook — custom save/load combos (optional; also core, see
; src/core/hooks/joypad/macros.asm):
;
;   joypad_save_combo SELECT, A        ; select + A triggers save
;   joypad_save_combo START, DOWN      ; start + down also triggers save
;   joypad_load_combo SELECT, B        ; select + B triggers load
;   joypad_load_combo START, UP        ; start + up also triggers load
;
; Each macro declares one combination (two buttons). Multiple combos of each
; type can be declared; they are evaluated in order. If no combos are declared
; the legacy combined detection (Select+A/B, Start+Down/Up) is used.
;
; Button names: SELECT, START, A, B, UP, DOWN, LEFT, RIGHT
;
; Optional feature knobs understood by the machinery (see HOW-TO.md):
;   swap_joypad, cpl_joypad, CARTRIDGE_TYPE, GB_COMPATIBILITY, SRAM_SIZE,
;   current_sram_bank, current_rom_bank, current_nr34_value, restore_wave_ram
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------


; Resets the internal RAM ($c000-$dfff) at startup, so the PackBits RLE can
; compress unused internal RAM efficiently. For games that do not clear
; their RAM themselves.
;
; Boot-hook macro, register it from the game config with:
;
;     on_boot_inline reset_ram
;
; 12 bytes in the boot trampoline. Preserves a (the hardware revision the
; game may check at its entry point); clobbers b, hl and the flags — safe at
; boot, before the game runs.
; SPDX-FileCopyrightText: 2017-2024 Matt Currie
MACRO reset_ram
    ld b,a          ; preserve the value of the a register

    ld hl,$c000
    ld a,$ff
.reset_ram_loop\@
    ld [hl+],a
    bit 5,h         ; bit 5 will be set when the h register reaches $e0
    jr z,.reset_ram_loop\@

    ld a,b          ; restore the value of the a register
ENDM

MACRO savestates_payload_in_rom0
    ASSERT !DEF(SAVESTATES_PAYLOAD_REGION), "savestates payload region declared twice"
    DEF SAVESTATES_PAYLOAD_REGION EQU 1
ENDM

MACRO savestates_payload_in_rom0_b
    ASSERT !DEF(SAVESTATES_PAYLOAD_REGION), "savestates payload region declared twice"
    DEF SAVESTATES_PAYLOAD_REGION EQU 2
ENDM

; usage: savestates_marker --- My Game Save Patch ---   (bare, no quotes)
MACRO savestates_marker
    DEF SAVESTATES_MARKER EQUS "\1"
ENDM
