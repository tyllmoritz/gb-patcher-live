; ------------------------------------------------------------------------------
; Aggregate include for game configs written in the original gb-save-states
; style: the config places all sections itself and includes this file inside
; its "save/load state" section instead of using the feature's macro API.
;
; hardware.inc is already included by the core; the cartridge header changes
; are requested via CHANGE_* and emitted by the core's finalize step.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2017-2024 Matt Currie
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

; resolved here (not just once from src/main.asm, after this whole game
; config file finishes) because legacy configs place this INCLUDE inside
; their own file, ahead of src/main.asm regaining control — see
; resolve_gb_compatibility's comment (src/core/header.asm)
    resolve_gb_compatibility
    resolve_sram_size
    resolve_cartridge_type

; legacy configs never pass -D_SAVESTATES, so src/main.asm's own
; DEF(_SAVESTATES)-gated INCLUDE of this file never runs for them — pull it
; in here instead, for macros like reset_ram
INCLUDE "src/features/savestates/macros.asm"

INCLUDE "src/features/savestates/defines.asm"

; CARTRIDGE_TYPE (a CART_ROM_* constant, hardware_compat.inc) — see
; code.asm's comment on the identical check there. resolve_cartridge_type
; already ran above, so CARTRIDGE_TYPE alone is authoritative here.
DEF _CARTRIDGE_TYPE_IS_MBC5 EQU 0
IF DEF(CARTRIDGE_TYPE)
    IF CARTRIDGE_TYPE >= CART_ROM_MBC5 && CARTRIDGE_TYPE <= CART_ROM_MBC5_RAM_BAT_RUMBLE
        REDEF _CARTRIDGE_TYPE_IS_MBC5 EQU 1
    ENDC
ENDC
IF _CARTRIDGE_TYPE_IS_MBC5
    DEF _TARGET_CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT
ELSE
    DEF _TARGET_CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT
ENDC
IF !DEF(CHANGE_CARTRIDGE_TYPE)
    IF DEF(CARTRIDGE_TYPE)
        IF CARTRIDGE_TYPE != _TARGET_CARTRIDGE_TYPE
            DEF CHANGE_CARTRIDGE_TYPE EQU _TARGET_CARTRIDGE_TYPE
        ENDC
    ELSE
        DEF CHANGE_CARTRIDGE_TYPE EQU _TARGET_CARTRIDGE_TYPE
    ENDC
ENDC
DEF CHANGE_RAM_SIZE EQU RAMSIZE

INCLUDE "src/features/savestates/save_state_includes.asm"
