; ------------------------------------------------------------------------------
; Aggregate include for game configs written in the original gb-save-states
; style: the config places all sections itself and includes this file inside
; its "save/load state" section instead of using the feature's macro API.
;
; hardware.inc is already included by the core; the cartridge header changes
; are requested via CHANGE_* and emitted by the core's finalize step.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2017-2024 Matt Currie
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

INCLUDE "src/features/savestates/defines.asm"

IF DEF(uses_mbc5)
    DEF CHANGE_CART_TYPE EQU CART_ROM_MBC5_RAM_BAT
ELSE
    DEF CHANGE_CART_TYPE EQU CART_ROM_MBC1_RAM_BAT
ENDC
DEF CHANGE_RAM_SIZE EQU RAMSIZE

INCLUDE "src/features/savestates/save_state_includes.asm"
