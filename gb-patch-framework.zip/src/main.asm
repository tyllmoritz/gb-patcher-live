; ------------------------------------------------------------------------------
; Assembly entry point
;
; Assembled once per build target:
;   rgbasm -DGAME_CONFIG=<games/....asm> -D<FEATURE FLAGS> src/main.asm
;
; Order matters:
;   1. core            — macro APIs, empty hook registries
;   2. feature macros  — config-time APIs of enabled features
;   3. game config     — declarative: constants, regions, hook attachments
;   4. feature code    — allocates itself into the declared regions
;   5. finalize        — emit hook trampolines, apply header changes,
;                        verify region overflow
;
; Adding a new feature = adding one `macros` and one `code` include below.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

; --- 1. core ---
INCLUDE "src/core/hardware.inc"
INCLUDE "src/core/regions.asm"
INCLUDE "src/core/hooks.asm"
INCLUDE "src/core/header.asm"

MACRO finalize
    finalize_hooks
    finalize_header
    finalize_regions
ENDM

; --- 2. feature config APIs ---
IF DEF(_SAVESTATES)
INCLUDE "src/features/savestates/macros.asm"
ENDC

; --- 3. game config ---
INCLUDE "{GAME_CONFIG}"

; --- 4. feature code ---
IF DEF(_SAVESTATES)
INCLUDE "src/features/savestates/code.asm"
ENDC
IF DEF(_BATTERYLESS)
INCLUDE "src/features/batteryless/code.asm"
ENDC
IF DEF(_NORTC)
INCLUDE "src/features/rtc/code.asm"
ENDC

; --- 5. finalize ---
    finalize
