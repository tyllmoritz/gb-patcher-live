; ------------------------------------------------------------------------------
; Assembly entry point
;
; Assembled once per build target:
;   rgbasm -DGAME_CONFIG=<games/....asm> -D<FEATURE FLAGS> src/main.asm
;
; Order matters:
;   1. core            — macro APIs, empty hook registries
;   2. feature macros  — config-time APIs of enabled features
;   3. game config     — declarative: constants, regions, hook attachments
;   4. feature code    — allocates itself into the declared regions
;   5. finalize        — emit hook trampolines, apply header changes,
;                        verify region overflow
;
; Adding a new feature = adding one `macros` and one `code` include below.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

; --- 1. hardware ---
INCLUDE "third_party/hardware.inc/hardware.inc"
INCLUDE "third_party/hardware.inc/hardware_compat.inc"

; --- 2. core ---
INCLUDE "src/core/header.asm"
INCLUDE "src/core/regions.asm"
INCLUDE "src/core/hooks.asm"

; --- 3. feature Makros / APIs ---
INCLUDE "src/features/macros.asm"

; --- 5. game config ---
INCLUDE "{GAME_CONFIG}"

; --- 6. run default makros ---
    resolve_header_parameter
    resolve_debug_flags

; --- 6. code ---
INCLUDE "src/features/code.asm"

; --- 5. finalize ---
    finalize_hooks
    finalize_header
    finalize_regions
