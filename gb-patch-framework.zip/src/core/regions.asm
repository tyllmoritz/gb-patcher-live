; ------------------------------------------------------------------------------
; Free-space region API
;
; A game config *declares* where free space exists in the original ROM/RAM;
; features *allocate* from it with the paired *_code macros. Every region is
; a SECTION FRAGMENT, so any number of features can contribute code to it and
; the assembler concatenates their contributions. `finalize_regions` asserts
; that nothing overflowed the declared end address.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------


; Declare free space in ROM bank 0.
; usage: free_space_rom0 START, END   (END is exclusive)
MACRO free_space_rom0
    ASSERT !DEF(FREE_ROM0_START), "free_space_rom0 declared twice"
    DEF FREE_ROM0_START EQU (\1)
    DEF FREE_ROM0_END EQU (\2)
    PUSHS
    SECTION FRAGMENT "free space ROM0", ROM0[FREE_ROM0_START]
    POPS
ENDM

; Declare a second, disjoint region of free space in ROM bank 0. For games
; whose free ROM0 space comes in two separate windows (e.g. the relocated
; joypad read lives near the entry point while the save/load payload lives
; much further into the bank). Most games need only free_space_rom0.
; usage: free_space_rom0_b START, END   (END is exclusive)
MACRO free_space_rom0_b
    ASSERT !DEF(FREE_ROM0_B_START), "free_space_rom0_b declared twice"
    DEF FREE_ROM0_B_START EQU (\1)
    DEF FREE_ROM0_B_END EQU (\2)
    PUSHS
    SECTION FRAGMENT "free space ROM0 B", ROM0[FREE_ROM0_B_START]
    POPS
ENDM

; Declare a third, disjoint region of free space in ROM bank 0. Rare — only
; for games that need three independent ROM0 windows at once (e.g. a
; reset_ram trampoline, a relocated joypad read, and a payload, all at
; unrelated addresses).
; usage: free_space_rom0_c START, END   (END is exclusive)
MACRO free_space_rom0_c
    ASSERT !DEF(FREE_ROM0_C_START), "free_space_rom0_c declared twice"
    DEF FREE_ROM0_C_START EQU (\1)
    DEF FREE_ROM0_C_END EQU (\2)
    PUSHS
    SECTION FRAGMENT "free space ROM0 C", ROM0[FREE_ROM0_C_START]
    POPS
ENDM

; Declare free space in a switchable ROM bank.
; usage: free_space_romx BANK, START, END   (END is exclusive)
MACRO free_space_romx
    ASSERT !DEF(FREE_ROMX_START), "free_space_romx declared twice"
    DEF FREE_ROMX_BANK EQU (\1)
    DEF FREE_ROMX_START EQU (\2)
    DEF FREE_ROMX_END EQU (\3)
    PUSHS
    SECTION FRAGMENT "free space ROMX", ROMX[FREE_ROMX_START], BANK[FREE_ROMX_BANK]
    POPS
ENDM

; Declare free/scratch space in WRAM (RAM that is safe to clobber while the
; game is interrupted). Needed by code that must run from RAM, e.g. flash
; writes. The stack must not live inside this region.
; usage: free_space_wram START, END [, WRAM_BANK]
MACRO free_space_wram
    ASSERT !DEF(FREE_WRAM_START), "free_space_wram declared twice"
    DEF FREE_WRAM_START EQU (\1)
    DEF FREE_WRAM_END EQU (\2)
    IF _NARG > 2
        DEF FREE_WRAM_BANK EQU (\3)
    ENDC
    DEF WRAM_SCRATCH_BYTES = 0
ENDM

; Reserve one byte of WRAM scratch at the start of the region and name it.
; Scratch bytes survive wram_overlay copies, so they can pass state between
; overlaid routines. Must be used before the first wram_overlay.
; usage: wram_scratch wSomeName
MACRO wram_scratch
    ASSERT DEF(FREE_WRAM_START), "no WRAM free space declared; use free_space_wram in the game config"
    DEF \1 EQU FREE_WRAM_START + WRAM_SCRATCH_BYTES
    EXPORT REDEF WRAM_SCRATCH_BYTES = WRAM_SCRATCH_BYTES + 1
ENDM

; Like wram_scratch, but reserves SIZE bytes at once instead of one byte —
; e.g. for backing up a borrowed HRAM window (see free_space_hram) before
; overwriting it with hram_overlay code.
; usage: wram_scratch_block wSomeName, SIZE
MACRO wram_scratch_block
    ASSERT DEF(FREE_WRAM_START), "no WRAM free space declared; use free_space_wram in the game config"
    DEF \1 EQU FREE_WRAM_START + WRAM_SCRATCH_BYTES
    REDEF WRAM_SCRATCH_BYTES = WRAM_SCRATCH_BYTES + (\2)
ENDM


; Declare free/scratch space in HRAM ($FF80-$FFFE, always mapped, never
; bank-switched). Needed by code that must run somewhere disjoint from every
; WRAM bank and both VRAM banks — e.g. a flash-write routine that sources
; its data from WRAM/VRAM itself, which would otherwise capture its own
; instruction bytes if it ran from within the bank it's reading.
;
; Unlike free_space_wram/free_space_rom0, this window does NOT need to be
; genuinely unused by the game: HRAM is only 127 bytes total, and a real
; game plausibly uses all of it, so requiring a truly free window (found
; via debugger, like every other free-space declaration in this project)
; would rule out most games outright. Instead, the caller is expected to
; back the window up to WRAM before borrowing it and restore it
; afterward — see the hram_overlay comment below for the exact sequence.
; Capped at 0x80 (128) bytes: an hram_overlay block bigger than that
; wouldn't fit in HRAM at all even on a game using none of it.
; usage: free_space_hram START, END   (END is exclusive)
MACRO free_space_hram
    ASSERT !DEF(FREE_HRAM_START), "free_space_hram declared twice"
    DEF FREE_HRAM_START EQU (\1)
    DEF FREE_HRAM_END EQU (\2)
    ASSERT FREE_HRAM_END - FREE_HRAM_START <= $80, "free_space_hram window must be at most 0x80 bytes"
ENDM


; Place the following code/data in the declared ROM0 free space.
MACRO rom0_code
    ASSERT DEF(FREE_ROM0_START), "no ROM0 free space declared; use free_space_rom0 in the game config"
    PUSHS
    SECTION FRAGMENT "free space ROM0", ROM0
ENDM

; Place the following code/data in the declared second ROM0 free space.
MACRO rom0_code_b
    ASSERT DEF(FREE_ROM0_B_START), "no ROM0 B free space declared; use free_space_rom0_b in the game config"
    PUSHS
    SECTION FRAGMENT "free space ROM0 B", ROM0
ENDM

; Place the following code/data in the declared third ROM0 free space.
MACRO rom0_code_c
    ASSERT DEF(FREE_ROM0_C_START), "no ROM0 C free space declared; use free_space_rom0_c in the game config"
    PUSHS
    SECTION FRAGMENT "free space ROM0 C", ROM0
ENDM

; Place the following code/data in the declared ROMX free space.
MACRO romx_code
    ASSERT DEF(FREE_ROMX_START), "no ROMX free space declared; use free_space_romx in the game config"
    PUSHS
    SECTION FRAGMENT "free space ROMX", ROMX
ENDM

; Close a rom0_code/romx_code block.
MACRO end_code
    POPS
ENDM


; Begin a routine that is stored in the current ROM section but linked to run
; from the declared WRAM free space (labels resolve to WRAM addresses).
; All wram_overlay routines share the same WRAM region (UNION) because they
; are copied there one at a time before being called.
MACRO wram_overlay
    ASSERT DEF(FREE_WRAM_START), "no WRAM free space declared; use free_space_wram in the game config"
    IF DEF(FREE_WRAM_BANK)
        LOAD UNION "Wram Code", WRAMX[FREE_WRAM_START + WRAM_SCRATCH_BYTES], BANK[FREE_WRAM_BANK]
    ELSE
        LOAD UNION "Wram Code", WRAM0[FREE_WRAM_START + WRAM_SCRATCH_BYTES]
    ENDC
ENDM

; Close a wram_overlay block, checking that it fits the declared region.
; New wram_overlay routines should stay under 0x80 (128) bytes where
; practical (keeps a block small enough to also fit HRAM, in case it's
; ever needed there instead) — not a hard ASSERT here, since
; bootleg_read_identifier (bankx.asm, four near-duplicate cartridge-type
; detection sequences, pre-existing and shipped in every _BATTERYLESS
; game) is already 170 bytes; enforcing it retroactively would break
; every existing battery-less build's golden bytes to reshape code that
; already works, not just gate new code.
MACRO end_wram_overlay
    ASSERT @ <= FREE_WRAM_END, "WRAM free space overflow"
    ENDL
ENDM


; Begin a routine that is stored in the current ROM section but linked to run
; from the declared HRAM free space (labels resolve to HRAM addresses).
; All hram_overlay routines share the same HRAM region (UNION) because they
; are copied there one at a time before being called — mirrors wram_overlay
; exactly, just in HRAM instead of WRAM. The window isn't assumed free (see
; free_space_hram): back it up to WRAM before the first hram_overlay use in
; a sequence and restore it after the last, so the game's own HRAM content
; is intact again before it resumes.
MACRO hram_overlay
    ASSERT DEF(FREE_HRAM_START), "no HRAM free space declared; use free_space_hram in the game config"
    LOAD UNION "Hram Code", HRAM[FREE_HRAM_START]
ENDM

; Close an hram_overlay block, checking that it fits the declared region
; (already capped at 0x80 bytes by free_space_hram itself).
MACRO end_hram_overlay
    ASSERT @ <= FREE_HRAM_END, "HRAM free space overflow"
    ENDL
ENDM


; Called by `finalize`: turn region overflow into a build error.
MACRO finalize_regions
    IF DEF(FREE_ROM0_START)
        PUSHS
        SECTION FRAGMENT "free space ROM0", ROM0
        ASSERT @ <= FREE_ROM0_END, "ROM0 free space overflow"
        POPS
    ENDC
    IF DEF(FREE_ROM0_B_START)
        PUSHS
        SECTION FRAGMENT "free space ROM0 B", ROM0
        ASSERT @ <= FREE_ROM0_B_END, "ROM0 B free space overflow"
        POPS
    ENDC
    IF DEF(FREE_ROM0_C_START)
        PUSHS
        SECTION FRAGMENT "free space ROM0 C", ROM0
        ASSERT @ <= FREE_ROM0_C_END, "ROM0 C free space overflow"
        POPS
    ENDC
    IF DEF(FREE_ROMX_START)
        PUSHS
        SECTION FRAGMENT "free space ROMX", ROMX
        ASSERT @ <= FREE_ROMX_END, "ROMX free space overflow"
        POPS
    ENDC
ENDM
