; ------------------------------------------------------------------------------
; Check for load combo — split joypad hook
;
; Evaluates all joypad_load_combo fragments. Returns a=1 if any match,
; a=0 otherwise.
;
; Only used when SAVESTATES_SPLITS is defined (i.e., when at least one
; joypad_save_combo or joypad_load_combo was declared).
; When not used, check.asm calls CHECK_FOR_SAVE_OR_LOAD_GAME directly.
;
; Supports up to 8 load combos (LOAD_COMBO_0 through LOAD_COMBO_7).
; Only active combos emit code.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

CHECK_FOR_LOAD_COMBO:
IF DEF(SAVESTATES_LOAD_DECLARED)
    ; Evaluate load combos in order; first match returns a=1
    ; Each combo is: bit BIT1, a / jr nz, .match / bit BIT2, a / jr z, .next
    ; Only active combos emit code
IF DEF(LOAD_COMBO_0_ACTIVE)
    bit LOAD_COMBO_0_BIT1, a
    jr nz, .lc0_bit2
    bit LOAD_COMBO_0_BIT2, a
    jr z, .lc1
.lc0_bit2:
    ld a, 1
    ret
.lc1:
ENDC
IF DEF(LOAD_COMBO_1_ACTIVE)
    bit LOAD_COMBO_1_BIT1, a
    jr nz, .lc2_bit2
    bit LOAD_COMBO_1_BIT2, a
    jr z, .lc3
.lc2_bit2:
    ld a, 1
    ret
.lc3:
ENDC
IF DEF(LOAD_COMBO_2_ACTIVE)
    bit LOAD_COMBO_2_BIT1, a
    jr nz, .lc4_bit2
    bit LOAD_COMBO_2_BIT2, a
    jr z, .lc5
.lc4_bit2:
    ld a, 1
    ret
.lc5:
ENDC
IF DEF(LOAD_COMBO_3_ACTIVE)
    bit LOAD_COMBO_3_BIT1, a
    jr nz, .lc6_bit2
    bit LOAD_COMBO_3_BIT2, a
    jr z, .lc7
.lc6_bit2:
    ld a, 1
    ret
.lc7:
ENDC
IF DEF(LOAD_COMBO_4_ACTIVE)
    bit LOAD_COMBO_4_BIT1, a
    jr nz, .lc8_bit2
    bit LOAD_COMBO_4_BIT2, a
    jr z, .lc9
.lc8_bit2:
    ld a, 1
    ret
.lc9:
ENDC
IF DEF(LOAD_COMBO_5_ACTIVE)
    bit LOAD_COMBO_5_BIT1, a
    jr nz, .lcA_bit2
    bit LOAD_COMBO_5_BIT2, a
    jr z, .lcB
.lcA_bit2:
    ld a, 1
    ret
.lcB:
ENDC
IF DEF(LOAD_COMBO_6_ACTIVE)
    bit LOAD_COMBO_6_BIT1, a
    jr nz, .lcC_bit2
    bit LOAD_COMBO_6_BIT2, a
    jr z, .lcD
.lcC_bit2:
    ld a, 1
    ret
.lcD:
ENDC
IF DEF(LOAD_COMBO_7_ACTIVE)
    bit LOAD_COMBO_7_BIT1, a
    jr nz, .lcE_bit2
    bit LOAD_COMBO_7_BIT2, a
    jr z, .lcF
.lcE_bit2:
    ld a, 1
    ret
.lcF:
ENDC
    xor a
    ret
ELSE
    ; Legacy: no splits declared — caller uses CHECK_FOR_SAVE_OR_LOAD_GAME
    xor a
    ret
ENDC
