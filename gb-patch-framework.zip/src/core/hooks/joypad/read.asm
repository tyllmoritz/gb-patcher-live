; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2017-2024 Matt Currie
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

;***************************************************************************
;
; Reads the current joypad state
;
; OUTPUT:
; C = current state of the joypad
;
;***************************************************************************

    ld a,JOYP_GET_CTRL_PAD
    ldh [rP1],a
    ldh a,[rP1]
    ldh a,[rP1]
    cpl
    and JOYP_INPUTS
    swap a
    ld b,a
    ld a,JOYP_GET_BUTTONS
    ldh [rP1],a
    ldh a,[rP1]
    ldh a,[rP1]
    ldh a,[rP1]
    ldh a,[rP1]
    ldh a,[rP1]
    ldh a,[rP1]
    cpl
    and JOYP_INPUTS
    or b

IF DEF(swap_joypad)
    swap a
ENDC
IF DEF(cpl_joypad)
    cpl
ENDC


    ld c,a
    
