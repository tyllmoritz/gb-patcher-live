; ------------------------------------------------------------------------------
; Joypad hook — config-time API
;
; Generic "get called back on every joypad read, and detect a button
; combination" mechanism. Originally part of the savestates feature (which
; is still its only consumer), split out so any future feature can attach to
; joypad input without depending on savestates.
;
; Required game config declarations:
;   DEF joypad EQU $xxxx          ; where the game stores the joypad value
;                                 ; (optional: joypad_2/joypad_3/joypad_4)
; plus exactly one joypad hook:
;
;   joypad_hook ADDR
;     Standard variant. Overwrites the tail of the game's joypad read routine
;     (the `ld a,$30 / ldh [$00],a` sequence at ADDR, 4 bytes) with a call to
;     relocated_read_from_joypad, which is placed in the declared ROM0 free
;     space (~$40 bytes needed). If that free_space_rom0 region is already
;     used for something else (e.g. an on_boot_inline reset_ram trampoline
;     at a different address), redirect the routine with:
;       joypad_relocated_read_in_rom0_b
;     which places it in the declared free_space_rom0_b region instead
;     (or ..._in_rom0_c / free_space_rom0_c, for the rare game that needs
;     three independent ROM0 windows at once: reset_ram, relocated read,
;     and a ROM0 payload, all at unrelated addresses).
;
;   joypad_hook_banked BANK, ADDR [, CONTINUE_ADDR]
;     For games without ROM0 free space. Overwrites the game's entire joypad
;     read routine at BANK:ADDR with a bank-switching call into the payload's
;     free space (requires DEF current_rom_bank). Returns with `ret` unless
;     CONTINUE_ADDR is given, in which case it jumps there instead (some
;     games' joypad routines are entered from more than one place and must
;     rejoin shared code afterwards rather than returning to the caller).
;
;   joypad_hook_banked_split BANK, ADDR1, ADDR2
;     Like _banked, but the original joypad routine is patched over two
;     non-contiguous instructions (some games interleave other code between
;     the routine's setup and its tail).
;
;   joypad_vblank_hook ORIGINAL_HANDLER [, options...]
;     For games whose joypad read only makes sense to call from inside their
;     own vblank interrupt handler. Installs a small vblank stub in ROM0 free
;     space that reads the joypad (bank-switching through
;     relocated_read_from_joypad, itself placed in the payload's free space)
;     and then falls into ORIGINAL_HANDLER. Recognized options (pass as
;     DEF-style words, e.g. `joypad_vblank_hook Handler, use_call`):
;       use_call   - call (not jp) into ORIGINAL_HANDLER (handler returns)
;
; For the rare game whose original joypad-read routine can't be replaced by
; the generic relocated_read_from_joypad body (e.g. it must preserve specific
; register state its caller relies on, or the game's own bank-switching stub
; needs to run first) — set `DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1` after
; the joypad_hook*/joypad_vblank_hook call. This skips the framework's
; automatic INCLUDE of relocated_read.asm / read_and_check.asm entirely; the
; game config must then define its own `relocated_read_from_joypad:` label
; (and, for the banked/vblank variants, its own joypad_check dispatch too —
; see src/core/hooks/joypad/check.asm) in the same free-space region.
;
; Key-combination declarations (joypad_save_combo/joypad_load_combo below;
; the savestates feature is currently their only consumer — see its own
; macros.asm for the save/load dispatch built on top of these):
;
; Button names: SELECT, START, A, B, UP, DOWN, LEFT, RIGHT
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------


MACRO joypad_hook
    ASSERT !DEF(JOYPAD_HOOK_VARIANT), "joypad hook declared twice"
    DEF JOYPAD_HOOK_VARIANT EQU 0
    PUSHS
    SECTION "joypad hook", ROM0[(\1)]
    call relocated_read_from_joypad
    nop
    POPS
ENDM

MACRO joypad_hook_banked
    ASSERT !DEF(JOYPAD_HOOK_VARIANT), "joypad hook declared twice"
    DEF JOYPAD_HOOK_VARIANT EQU 1
    patch_rom \1, \2
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    IF _NARG >= 3
        jp \3
    ELSE
        ret
    ENDC
    end_patch
ENDM

MACRO joypad_hook_banked_split
    ASSERT !DEF(JOYPAD_HOOK_VARIANT), "joypad hook declared twice"
    DEF JOYPAD_HOOK_VARIANT EQU 1
    patch_rom \1, \2
    INCLUDE "src/core/hooks/joypad/call_in_other_bank_part_1.asm"
    end_patch
    patch_rom \1, \3
    INCLUDE "src/core/hooks/joypad/call_in_other_bank_part_2.asm"
    end_patch
ENDM

MACRO joypad_vblank_hook
    ASSERT !DEF(JOYPAD_HOOK_VARIANT), "joypad hook declared twice"
    DEF JOYPAD_HOOK_VARIANT EQU 2
    DEF vblank_handler EQU (\1)
    DEF original_vblank_handler EQU (\2)
    SHIFT
    SHIFT
    REPT _NARG
        DEF \1 EQU 1
        SHIFT
    ENDR
ENDM

MACRO joypad_relocated_read_in_rom0_b
    ASSERT !DEF(JOYPAD_RELOCATED_READ_REGION), "joypad relocated-read region declared twice"
    DEF JOYPAD_RELOCATED_READ_REGION EQU 2
ENDM

MACRO joypad_relocated_read_in_rom0_c
    ASSERT !DEF(JOYPAD_RELOCATED_READ_REGION), "joypad relocated-read region declared twice"
    DEF JOYPAD_RELOCATED_READ_REGION EQU 3
ENDM


; ------------------------------------------------------------------------------
; Key-combination helper
;
; Internal: expand a button name to its bit position in the joypad register,
; via hardware.inc's B_PAD_* constants (A=0, B=1, SELECT=2, START=3,
; RIGHT=4, LEFT=5, UP=6, DOWN=7).
; ------------------------------------------------------------------------------
MACRO _BUTTON_BIT
    IF \1 == A
        DEF _BTN_BIT EQU B_PAD_A
    ELIF \1 == B
        DEF _BTN_BIT EQU B_PAD_B
    ELIF \1 == SELECT
        DEF _BTN_BIT EQU B_PAD_SELECT
    ELIF \1 == START
        DEF _BTN_BIT EQU B_PAD_START
    ELIF \1 == RIGHT
        DEF _BTN_BIT EQU B_PAD_RIGHT
    ELIF \1 == LEFT
        DEF _BTN_BIT EQU B_PAD_LEFT
    ELIF \1 == UP
        DEF _BTN_BIT EQU B_PAD_UP
    ELIF \1 == DOWN
        DEF _BTN_BIT EQU B_PAD_DOWN
    ELSE
        ASSERT 0, "unknown button: \1"
    ENDC
ENDM


; ------------------------------------------------------------------------------
; Key-combination declarations — used by the savestates feature (see its
; macros.asm) to declare independent save/load key combos. By default
; CHECK_FOR_SAVE_OR_LOAD_GAME (savestates) uses the legacy combined detection
; (Select+A/B, Start+Down/Up); declaring at least one joypad_save_combo /
; joypad_load_combo switches to evaluating these instead.
;
;   joypad_save_combo SELECT, A        ; select + A
;   joypad_save_combo START, DOWN      ; start + down
;   joypad_load_combo SELECT, B        ; select + B
;   joypad_load_combo START, UP        ; start + up
;
; Each macro sets a flag (SAVE_COMBO_N / LOAD_COMBO_N) that
; src/core/hooks/joypad/check_save_combo.asm / check_load_combo.asm read to emit
; the corresponding bit tests. Multiple combos of each type can be declared;
; they are evaluated in order. If no combos are declared the legacy combined
; routine is used (backward-compatible, zero footprint for configs that
; don't declare any).
; ------------------------------------------------------------------------------

; Declare a save key combination. Sets SAVE_COMBO_N flags that the check
; routine reads to emit bit tests. Multiple save combos can be declared.
MACRO joypad_save_combo
    DEF SAVESTATES_SPLITS EQU 1
    DEF SAVESTATES_SAVE_DECLARED EQU 1
    _BUTTON_BIT \1
    DEF _BIT1 EQU _BTN_BIT
    _BUTTON_BIT \2
    DEF _BIT2 EQU _BTN_BIT
    DEF "SAVE_COMBO_{d:SAVESTATES_SAVE_IDX}_BIT1" EQU _BIT1
    DEF "SAVE_COMBO_{d:SAVESTATES_SAVE_IDX}_BIT2" EQU _BIT2
    DEF "SAVE_COMBO_{d:SAVESTATES_SAVE_IDX}_ACTIVE" EQU 1
    REDEF SAVESTATES_SAVE_IDX = SAVESTATES_SAVE_IDX + 1
ENDM

; Declare a load key combination. Sets LOAD_COMBO_N flags that the check
; routine reads to emit bit tests. Multiple load combos can be declared.
MACRO joypad_load_combo
    DEF SAVESTATES_SPLITS EQU 1
    DEF SAVESTATES_LOAD_DECLARED EQU 1
    _BUTTON_BIT \1
    DEF _BIT1 EQU _BTN_BIT
    _BUTTON_BIT \2
    DEF _BIT2 EQU _BTN_BIT
    DEF "LOAD_COMBO_{d:SAVESTATES_LOAD_IDX}_BIT1" EQU _BIT1
    DEF "LOAD_COMBO_{d:SAVESTATES_LOAD_IDX}_BIT2" EQU _BIT2
    DEF "LOAD_COMBO_{d:SAVESTATES_LOAD_IDX}_ACTIVE" EQU 1
    REDEF SAVESTATES_LOAD_IDX = SAVESTATES_LOAD_IDX + 1
ENDM

; Initialize combo index counters (must be after all macro definitions)
IF !DEF(SAVESTATES_SAVE_IDX)
    DEF SAVESTATES_SAVE_IDX EQU 0
ENDC
IF !DEF(SAVESTATES_LOAD_IDX)
    DEF SAVESTATES_LOAD_IDX EQU 0
ENDC
