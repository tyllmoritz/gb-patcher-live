; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2017-2024 Matt Currie
; SPDX-FileCopyrightText: 2024 Robin Bertram
; SPDX-License-Identifier: GPL-3.0-only OR MIT
; ------------------------------------------------------------------------------

;***************************************************************************
;
; Reads the current joypad state into joypad (and joypad_2/joypad_3 if
; defined) and then checks if the button combos are pressed
;
;***************************************************************************

relocated_read_from_joypad:

IF DEF(calling_from_vblank)

    push bc
    push de
    push hl

    ld a,$0a  ; enable access to ram bank
    ld [rRAMG],a

    ; select the ram bank we need for writing the joypad value
    ld a,SAVE_STATE_RAM_BANK
    ld [rRAMB],a

ENDC



INCLUDE "src/core/hooks/joypad/read.asm"      


IF DEF(joypad_2)

    ld a,[joypad]
    xor c            
    and c            
    ld [joypad_2],a     
IF DEF(joypad_4)
    ld [joypad_4],a     
ENDC

    ld a,c           
ENDC    

IF DEF(joypad_3)
    ld [joypad_3],a     
ENDC

    ld [joypad],a
    ld a,JOYP_GET_NONE
    ld [rP1],a

INCLUDE "src/core/hooks/joypad/check.asm"


IF DEF(calling_from_vblank)

    IF DEF(SRAM_SIZE)
        ; restore sram bank
        IF DEF(current_sram_bank)
            ld a, [current_sram_bank]
        ELSE
            xor a
        ENDC
        ld [rRAMB],a
    ELSE
        ; lock access to ram bank
        xor a  
        ld [rRAMG],a
    ENDC

    pop hl
    pop de
    pop bc

ENDC

    ret
