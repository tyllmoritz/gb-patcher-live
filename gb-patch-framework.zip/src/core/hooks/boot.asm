; ------------------------------------------------------------------------------
; Boot hook
;
;  * game side  — the game config states *where* the game is intercepted:
;        entry_point $016e             ; target of the game's `jp` at $0101
;  * feature side — features register *what* runs there:
;        on_boot my_boot_routine       ; runs once before the game entry point
;        on_boot_inline my_macro       ; ditto, but expanded inline into the
;                                      ; trampoline (no call/ret overhead)
;
; `finalize_boot_hook` (called by src/core/hooks.asm's finalize_hooks) emits
; one trampoline into the ROM0 free space (falls back to ROMX free space in
; bank 1 — the bank mapped at boot — when no ROM0 region is declared),
; running all registered routines in registration order. Boot routines must
; preserve every register the game reads at its entry point — per Pan Docs
; that is a (DMG/CGB hardware revision) and b (bit 0: set on Game Boy
; Advance, read by CGB games doing AGB palette correction); clobbering the
; rest is only safe if the game is known not to read it. on_boot call
; targets must live in ROM0 or do their own bank switching.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------


DEF HOOKS_BOOT EQUS ""
DEF HOOKS_BOOT_COUNT = 0

; Register a routine to run during boot, before the game's entry point.
MACRO on_boot
    REDEF HOOKS_BOOT EQUS "{HOOKS_BOOT}    call \1\n"
    REDEF HOOKS_BOOT_COUNT = HOOKS_BOOT_COUNT + 1
ENDM

; Register a macro whose body runs during boot, expanded directly into the
; boot trampoline. Cheaper than on_boot (no call/ret, no ROM0 stub needed).
MACRO on_boot_inline
    REDEF HOOKS_BOOT EQUS "{HOOKS_BOOT}    \1\n"
    REDEF HOOKS_BOOT_COUNT = HOOKS_BOOT_COUNT + 1
ENDM

; Declare the original boot target: the address the game's header entry point
; (`jp nnnn` at $0101) jumps to.
MACRO entry_point
    ASSERT !DEF(GAME_ENTRY_POINT), "entry_point declared twice"
    DEF GAME_ENTRY_POINT EQU (\1)
ENDM

; Called by src/core/hooks.asm's finalize_hooks: emit the boot trampoline if
; any on_boot/on_boot_inline routine is registered.
MACRO finalize_boot_hook
    IF HOOKS_BOOT_COUNT > 0
        ASSERT DEF(GAME_ENTRY_POINT), "on_boot is used but the game config declares no entry_point"
        PUSHS
        ; overwrite the 3 bytes at $0100 with `jp boot_trampoline`, replacing
        ; the game's usual `nop` + `jp` opcode + operand low byte; the old
        ; operand high byte at $0103 remains as a dead byte. Games whose
        ; $0100 is not the standard `nop; jp nnnn` (e.g. Prism) must use
        ; patch_rom + a hand-rolled boot routine instead of entry_point.
        SECTION "entry point hook", ROM0[$0100]
        jp boot_trampoline
        POPS

        IF DEF(FREE_ROM0_START)
        rom0_code
        ELSE
        ASSERT FREE_ROMX_BANK == 1, "boot trampoline outside ROM0 requires ROMX free space in bank 1 (the bank mapped at boot)"
        romx_code
        ENDC
boot_trampoline:
        HOOKS_BOOT
        jp GAME_ENTRY_POINT
        end_code
    ENDC
ENDM
