; ------------------------------------------------------------------------------
; Save hook
;
;  * game side  — the game config states *where* the game is intercepted:
;        save_hook $05, $4b85, $4c10   ; bank, addr of a `call SaveGame`, and
;                                      ; the original call target
;        save_hook_jp $05, $4b85, $4c10      ; ditto for a `jp SaveGame` site
;        save_hook_inline $05, $4b85 ... end_save_hook_inline
;                                      ; for sites that are neither: replay
;                                      ; the replaced bytes, then
;                                      ; `call save_trampoline_bare`
;  * feature side — features register *what* runs there:
;        on_save my_save_routine       ; runs after the game's own save routine
;
; `finalize_save_hook` (called by src/core/hooks.asm's finalize_hooks) emits
; one trampoline into the ROM0 free space, running all registered routines in
; registration order.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------


DEF HOOKS_SAVE EQUS ""
DEF HOOKS_SAVE_COUNT = 0

; Register a routine to run after the game's own save routine.
MACRO on_save
    REDEF HOOKS_SAVE EQUS "{HOOKS_SAVE}    call \1\n"
    REDEF HOOKS_SAVE_COUNT = HOOKS_SAVE_COUNT + 1
ENDM

; Declare one call site of the game's save routine. If any feature registers
; an on_save routine, the `call` instruction at BANK:ADDR is redirected
; through a trampoline that first performs the original call, then runs all
; on_save routines. With no on_save consumers the declaration is a no-op.
; usage: save_hook BANK, ADDR, ORIGINAL_TARGET
DEF SAVE_HOOK_SITES EQUS ""
DEF SAVE_HOOK_SITE_COUNT = 0
MACRO save_hook
    IF !DEF(GAME_SAVE_ROUTINE)
        DEF GAME_SAVE_ROUTINE EQU (\3)
    ELSE
        ASSERT GAME_SAVE_ROUTINE == (\3), "all save_hook call sites must target the same original save routine"
    ENDC
    REDEF SAVE_HOOK_SITES EQUS "{SAVE_HOOK_SITES}    hook_call \1, \2, save_trampoline\n"
    REDEF SAVE_HOOK_SITE_COUNT = SAVE_HOOK_SITE_COUNT + 1
ENDM

; Declare a *tail-call* site of the game's save routine: the instruction at
; BANK:ADDR is `jp SaveRoutine` (not `call`). The site is redirected with
; `jp save_trampoline`; the trampoline's closing `ret` then returns to the
; tail call's original caller, preserving the tail-call semantics. The only
; observable difference is 2 bytes more stack depth while the save routine
; runs — verify the game doesn't inspect or switch SP inside it.
; usage: save_hook_jp BANK, ADDR, ORIGINAL_TARGET
MACRO save_hook_jp
    IF !DEF(GAME_SAVE_ROUTINE)
        DEF GAME_SAVE_ROUTINE EQU (\3)
    ELSE
        ASSERT GAME_SAVE_ROUTINE == (\3), "all save_hook call sites must target the same original save routine"
    ENDC
    REDEF SAVE_HOOK_SITES EQUS "{SAVE_HOOK_SITES}    hook_jp \1, \2, save_trampoline\n"
    REDEF SAVE_HOOK_SITE_COUNT = SAVE_HOOK_SITE_COUNT + 1
ENDM

; Declare a save hook at a site that is neither a `call` nor a `jp` to the
; save routine — e.g. an ordinary 3-byte instruction that happens to run
; right after the game's save completes. The 3 bytes at BANK:ADDR are
; overwritten with a `call` to a generated ROM0 stub; the block body is
; the stub's start and must replay the replaced instruction(s). The stub
; then runs the registered on_save routines via the bare trampoline (no
; `call` to the game's save routine — the save has already happened) and
; returns to ADDR+3:
;
;     save_hook_inline $1c, $6945
;         ld [$c0fe], a               ; the original bytes being replaced
;     end_save_hook_inline
;
; Exactly 3 bytes at ADDR are replaced (the size of the `call`), so the
; replaced original instruction must be 3 bytes; execution resumes at
; ADDR+3 as before. For sites that don't fit this shape (shorter/longer
; instructions, `ret`-terminated tails), declare `save_hook_manual` and
; patch the site by hand (patch_rom + rom0_code +
; `jp save_trampoline_bare`).
DEF SAVE_HOOK_INLINE_COUNT = 0
MACRO save_hook_inline
    REDEF SAVE_HOOK_INLINE_COUNT = SAVE_HOOK_INLINE_COUNT + 1
    hook_call \1, \2, save_hook_inline_stub_{d:SAVE_HOOK_INLINE_COUNT}
    rom0_code
save_hook_inline_stub_{d:SAVE_HOOK_INLINE_COUNT}:
ENDM

MACRO end_save_hook_inline
    jp save_trampoline_bare
    end_code
ENDM

; Declare that the config hooks the game's save itself with hand-written
; patch_rom/rom0_code blocks ending in `jp save_trampoline_bare` (or
; `call` + own flow). Only effect: save_trampoline_bare is emitted and the
; "no save_hook declared" assertion is satisfied.
MACRO save_hook_manual
    REDEF SAVE_HOOK_INLINE_COUNT = SAVE_HOOK_INLINE_COUNT + 1
ENDM

; Called by src/core/hooks.asm's finalize_hooks: emit the save trampoline(s)
; if any on_save routine is registered.
MACRO finalize_save_hook
    IF HOOKS_SAVE_COUNT > 0
        ASSERT SAVE_HOOK_SITE_COUNT > 0 || SAVE_HOOK_INLINE_COUNT > 0, "on_save is used but the game config declares no save_hook/save_hook_jp/save_hook_inline/save_hook_manual"
        IF SAVE_HOOK_SITE_COUNT > 0
        SAVE_HOOK_SITES
        rom0_code
save_trampoline:
        call GAME_SAVE_ROUTINE
        HOOKS_SAVE
        ret
        end_code
        ENDC
        IF SAVE_HOOK_INLINE_COUNT > 0
        rom0_code
save_trampoline_bare:
        HOOKS_SAVE
        ret
        end_code
        ENDC
    ENDC
ENDM
