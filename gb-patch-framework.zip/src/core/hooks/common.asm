; ------------------------------------------------------------------------------
; Hook API — low-level primitives
;
; Shared by every hook implementation (src/core/hooks/boot.asm, src/core/hooks/save.asm,
; src/core/hooks/joypad/) and available directly to game configs too, for anything
; not covered by a named hook:
;        hook_call BANK, ADDR, Target  ; overwrite a `call nnnn` in place
;        hook_jp   BANK, ADDR, Target  ; overwrite a `jp nnnn` in place
;        patch_rom BANK, ADDR          ; overwrite arbitrary bytes ...
;            db $c9
;        end_patch
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------


; Overwrite the `call nnnn` instruction at BANK:ADDR with `call Target`.
MACRO hook_call
    PUSHS
    IF (\1) == 0
        SECTION "hook call \1 \2", ROM0[(\2)]
    ELSE
        SECTION "hook call \1 \2", ROMX[(\2)], BANK[(\1)]
    ENDC
    call \3
    POPS
ENDM

; Overwrite the `jp nnnn` instruction at BANK:ADDR with `jp Target`.
MACRO hook_jp
    PUSHS
    IF (\1) == 0
        SECTION "hook jp \1 \2", ROM0[(\2)]
    ELSE
        SECTION "hook jp \1 \2", ROMX[(\2)], BANK[(\1)]
    ENDC
    jp \3
    POPS
ENDM

; Overwrite arbitrary bytes at BANK:ADDR; close with end_patch.
MACRO patch_rom
    PUSHS
    IF (\1) == 0
        SECTION "patch \1 \2", ROM0[(\2)]
    ELSE
        SECTION "patch \1 \2", ROMX[(\2)], BANK[(\1)]
    ENDC
ENDM

MACRO end_patch
    POPS
ENDM
