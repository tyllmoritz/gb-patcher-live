; ------------------------------------------------------------------------------
; Cartridge header overrides
;
; Game configs or features may request header changes by defining:
;   CHANGE_CART_TYPE — new cartridge type byte for $0147 (CART_* constants)
;   CHANGE_ROM_SIZE  — new ROM size byte for $0148
;   CHANGE_RAM_SIZE  — new RAM size byte for $0149 (CART_SRAM_* constants)
; The checksums are always zeroed so rgbfix recalculates them silently.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------


; Called by `finalize`: apply the requested header changes.
MACRO finalize_header
    PUSHS
    IF DEF(CHANGE_CART_TYPE)
        SECTION "header: cart type", ROM0[$0147]
        DB CHANGE_CART_TYPE
    ENDC
    IF DEF(CHANGE_ROM_SIZE)
        SECTION "header: rom size", ROM0[$0148]
        DB CHANGE_ROM_SIZE
    ENDC
    IF DEF(CHANGE_RAM_SIZE)
        SECTION "header: ram size", ROM0[$0149]
        DB CHANGE_RAM_SIZE
    ENDC
    SECTION "header: checksums", ROM0[$014d]
        DB $00, $00, $00 ; zeroed to stop warnings from rgbfix
    POPS
ENDM
