; ------------------------------------------------------------------------------
; Cartridge header overrides
;
; Game configs or features may request header changes by defining:
;   CHANGE_CARTRIDGE_TYPE  — new cartridge type byte for $0147 (CART_* constants)
;   CHANGE_ROM_SIZE        — new ROM size byte for $0148
;   CHANGE_RAM_SIZE        — new RAM size byte for $0149 (CART_SRAM_* constants)
;   CHANGE_GB_COMPATIBILITY — new CGB-compatibility byte for $0143
;                            (CART_COMPATIBLE_* constants)
; The checksums are always zeroed so rgbfix recalculates them silently.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------


; GB_COMPATIBILITY doubles as "does the save/load code need CGB-exclusive
; hardware" (checked by feature code as GB_COMPATIBILITY ==
; CART_COMPATIBLE_GBC) and, via CHANGE_GB_COMPATIBILITY, the new header
; byte finalize_header writes below. Called once right after the game
; config is included (src/main.asm) so both modern and legacy configs
; (which INCLUDE feature code inline, inside their own file, before
; src/main.asm regains control) see a resolved GB_COMPATIBILITY before any
; feature code's IF checks run. Idempotent — safe to call again with no
; effect once already resolved.
MACRO resolve_gb_compatibility
    IF DEF(CHANGE_GB_COMPATIBILITY)
        REDEF GB_COMPATIBILITY EQU CHANGE_GB_COMPATIBILITY
    ELIF !DEF(GB_COMPATIBILITY)
        DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
    ENDC
ENDM

; CARTRIDGE_TYPE is meant to be declared for every game config, set to the
; original ROM's actual $0147 cartridge-type byte (CART_ROM_* constants).
; A game config may also pre-declare CHANGE_CARTRIDGE_TYPE itself to force
; a conversion CARTRIDGE_TYPE's own true value wouldn't otherwise indicate
; (e.g. Pokemon Red is genuinely MBC3 but is deliberately converted to
; MBC5 — see its own config comment). When it does, CARTRIDGE_TYPE is
; redefined to match here, once, early — so every feature check downstream
; (the MBC5-vs-MBC1 bank-select-protocol range check in
; src/features/savestates/code.asm and legacy_includes.asm) can just look
; at CARTRIDGE_TYPE directly, without also needing to check whether
; CHANGE_CARTRIDGE_TYPE overrides it. Called the same way as
; resolve_gb_compatibility (see its comment) — idempotent.
MACRO resolve_cartridge_type
    IF DEF(CHANGE_CARTRIDGE_TYPE)
        REDEF CARTRIDGE_TYPE EQU CHANGE_CARTRIDGE_TYPE
    ENDC
ENDM

; SRAM_SIZE is meant to be declared for every game config, set to the
; original ROM's actual $0149 RAM-size byte (CART_SRAM_* constants) —
; transparent, and lets feature code rely on it instead of re-deriving it.
; But every existing `IF DEF(SRAM_SIZE)` check throughout the codebase
; means "the game has a real, usable SRAM chip", which CART_SRAM_NONE
; (games with no RAM at all) is not — so a declared-but-zero SRAM_SIZE is
; purged back to undefined here, instead of every one of those call sites
; needing to additionally check `SRAM_SIZE != CART_SRAM_NONE` (and worse,
; RGBASM's && doesn't short-circuit, so `DEF(SRAM_SIZE) && SRAM_SIZE !=
; CART_SRAM_NONE` would error on any game that omits SRAM_SIZE entirely).
; Called once right after the game config runs (src/main.asm and
; src/features/savestates/legacy_includes.asm, same as
; resolve_gb_compatibility — see its comment there) — and additionally, by
; the handful of legacy configs that INCLUDE a raw joypad file consuming
; SRAM_SIZE (src/core/hooks/joypad/read_and_check.asm) before that point, right
; after their own SRAM_SIZE declaration. Idempotent.
MACRO resolve_sram_size
    IF DEF(SRAM_SIZE)
        IF SRAM_SIZE == CART_SRAM_NONE
            PURGE SRAM_SIZE
        ENDC
    ENDC
ENDM

MACRO resolve_header_parameter
    resolve_gb_compatibility
    resolve_cartridge_type
    resolve_sram_size
ENDM

; _DEBUG is a general opt-in build flag (passed alongside a game's other
; feature flags, e.g. "with _SAVESTATES _BATTERYLESS _DEBUG"); individual
; features derive their own debug-mode defines from it as needed —
; batteryless_savestate_debug (src/features/batteryless_savestates) is the
; only consumer so far.
MACRO resolve_debug_flags
    IF DEF(_DEBUG)
        DEF batteryless_savestate_debug EQU 1
    ENDC
ENDM

; Called by `finalize`: apply the requested header changes.
MACRO finalize_header
    PUSHS
    IF DEF(CHANGE_CARTRIDGE_TYPE)
        SECTION "header: cart type", ROM0[$0147]
        DB CHANGE_CARTRIDGE_TYPE
    ENDC
    IF DEF(CHANGE_ROM_SIZE)
        SECTION "header: rom size", ROM0[$0148]
        DB CHANGE_ROM_SIZE
    ENDC
    IF DEF(CHANGE_RAM_SIZE)
        SECTION "header: ram size", ROM0[$0149]
        DB CHANGE_RAM_SIZE
    ENDC
    IF DEF(CHANGE_GB_COMPATIBILITY)
        SECTION "header: gb compatibility", ROM0[$0143]
        DB CHANGE_GB_COMPATIBILITY
    ENDC
    SECTION "header: checksums", ROM0[$014d]
        DB $00, $00, $00 ; zeroed to stop warnings from rgbfix
    POPS
ENDM


