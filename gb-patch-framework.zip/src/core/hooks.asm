; ------------------------------------------------------------------------------
; Hooks — config-time API aggregate
;
; Pulls in every hook implementation's macro API: the low-level primitives
; (src/core/hooks/common.asm) and named hooks (src/core/hooks/boot.asm,
; src/core/hooks/save.asm — see src/core/hooks.asm for an overview), plus joypad
; hooking (src/core/hooks/joypad/macros.asm). Included once from src/main.asm.
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------

INCLUDE "src/core/hooks/common.asm"
INCLUDE "src/core/hooks/boot.asm"
INCLUDE "src/core/hooks/save.asm"
INCLUDE "src/core/hooks/joypad/macros.asm"

; Called by `finalize`: emit the trampolines for all used hooks.
MACRO finalize_hooks
    finalize_boot_hook
    finalize_save_hook
ENDM
