; ------------------------------------------------------------------------------
; Hook API
;
; Two halves:
;  * game side  — the game config states *where* the game is intercepted:
;        entry_point $016e             ; target of the game's `jp` at $0101
;        save_hook $05, $4b85, $4c10   ; bank, addr of a `call SaveGame`, and
;                                      ; the original call target
;        save_hook_jp $05, $4b85, $4c10      ; ditto for a `jp SaveGame` site
;        save_hook_inline $05, $4b85 ... end_save_hook_inline
;                                      ; for sites that are neither: replay
;                                      ; the replaced bytes, then
;                                      ; `call save_trampoline_bare`
;  * feature side — features register *what* runs there:
;        on_boot my_boot_routine       ; runs once before the game entry point
;        on_boot_inline my_macro       ; ditto, but expanded inline into the
;                                      ; trampoline (no call/ret overhead)
;        on_save my_save_routine       ; runs after the game's own save routine
;
; `finalize_hooks` emits one trampoline per used hook into the ROM0 free
; space (boot: falls back to ROMX free space in bank 1 — the bank mapped at
; boot — when no ROM0 region is declared), running all registered routines in
; registration order. Boot routines must preserve every register the game
; reads at its entry point — per Pan Docs that is a (DMG/CGB hardware
; revision) and b (bit 0: set on Game Boy Advance, read by CGB games doing
; AGB palette correction); clobbering the rest is only safe if the game is
; known not to read it. on_boot call targets must live in ROM0 or do their
; own bank switching.
;
; For anything not covered by a named hook there are low-level primitives:
;        hook_call BANK, ADDR, Target  ; overwrite a `call nnnn` in place
;        hook_jp   BANK, ADDR, Target  ; overwrite a `jp nnnn` in place
;        patch_rom BANK, ADDR          ; overwrite arbitrary bytes ...
;            db $c9
;        end_patch
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------


; ------------------------------- registries ----------------------------------

DEF HOOKS_BOOT EQUS ""
DEF HOOKS_BOOT_COUNT = 0
DEF HOOKS_SAVE EQUS ""
DEF HOOKS_SAVE_COUNT = 0

; Register a routine to run during boot, before the game's entry point.
MACRO on_boot
    REDEF HOOKS_BOOT EQUS "{HOOKS_BOOT}    call \1\n"
    REDEF HOOKS_BOOT_COUNT = HOOKS_BOOT_COUNT + 1
ENDM

; Register a macro whose body runs during boot, expanded directly into the
; boot trampoline. Cheaper than on_boot (no call/ret, no ROM0 stub needed).
MACRO on_boot_inline
    REDEF HOOKS_BOOT EQUS "{HOOKS_BOOT}    \1\n"
    REDEF HOOKS_BOOT_COUNT = HOOKS_BOOT_COUNT + 1
ENDM

; Register a routine to run after the game's own save routine.
MACRO on_save
    REDEF HOOKS_SAVE EQUS "{HOOKS_SAVE}    call \1\n"
    REDEF HOOKS_SAVE_COUNT = HOOKS_SAVE_COUNT + 1
ENDM


; --------------------------- game-side declarations --------------------------

; Declare the original boot target: the address the game's header entry point
; (`jp nnnn` at $0101) jumps to.
MACRO entry_point
    ASSERT !DEF(GAME_ENTRY_POINT), "entry_point declared twice"
    DEF GAME_ENTRY_POINT EQU (\1)
ENDM

; Declare one call site of the game's save routine. If any feature registers
; an on_save routine, the `call` instruction at BANK:ADDR is redirected
; through a trampoline that first performs the original call, then runs all
; on_save routines. With no on_save consumers the declaration is a no-op.
; usage: save_hook BANK, ADDR, ORIGINAL_TARGET
DEF SAVE_HOOK_SITES EQUS ""
DEF SAVE_HOOK_SITE_COUNT = 0
MACRO save_hook
    IF !DEF(GAME_SAVE_ROUTINE)
        DEF GAME_SAVE_ROUTINE EQU (\3)
    ELSE
        ASSERT GAME_SAVE_ROUTINE == (\3), "all save_hook call sites must target the same original save routine"
    ENDC
    REDEF SAVE_HOOK_SITES EQUS "{SAVE_HOOK_SITES}    hook_call \1, \2, save_trampoline\n"
    REDEF SAVE_HOOK_SITE_COUNT = SAVE_HOOK_SITE_COUNT + 1
ENDM

; Declare a *tail-call* site of the game's save routine: the instruction at
; BANK:ADDR is `jp SaveRoutine` (not `call`). The site is redirected with
; `jp save_trampoline`; the trampoline's closing `ret` then returns to the
; tail call's original caller, preserving the tail-call semantics. The only
; observable difference is 2 bytes more stack depth while the save routine
; runs — verify the game doesn't inspect or switch SP inside it.
; usage: save_hook_jp BANK, ADDR, ORIGINAL_TARGET
MACRO save_hook_jp
    IF !DEF(GAME_SAVE_ROUTINE)
        DEF GAME_SAVE_ROUTINE EQU (\3)
    ELSE
        ASSERT GAME_SAVE_ROUTINE == (\3), "all save_hook call sites must target the same original save routine"
    ENDC
    REDEF SAVE_HOOK_SITES EQUS "{SAVE_HOOK_SITES}    hook_jp \1, \2, save_trampoline\n"
    REDEF SAVE_HOOK_SITE_COUNT = SAVE_HOOK_SITE_COUNT + 1
ENDM

; Declare a save hook at a site that is neither a `call` nor a `jp` to the
; save routine — e.g. an ordinary 3-byte instruction that happens to run
; right after the game's save completes. The 3 bytes at BANK:ADDR are
; overwritten with a `call` to a generated ROM0 stub; the block body is
; the stub's start and must replay the replaced instruction(s). The stub
; then runs the registered on_save routines via the bare trampoline (no
; `call` to the game's save routine — the save has already happened) and
; returns to ADDR+3:
;
;     save_hook_inline $1c, $6945
;         ld [$c0fe], a               ; the original bytes being replaced
;     end_save_hook_inline
;
; Exactly 3 bytes at ADDR are replaced (the size of the `call`), so the
; replaced original instruction must be 3 bytes; execution resumes at
; ADDR+3 as before. For sites that don't fit this shape (shorter/longer
; instructions, `ret`-terminated tails), declare `save_hook_manual` and
; patch the site by hand (patch_rom + rom0_code +
; `jp save_trampoline_bare`).
DEF SAVE_HOOK_INLINE_COUNT = 0
MACRO save_hook_inline
    REDEF SAVE_HOOK_INLINE_COUNT = SAVE_HOOK_INLINE_COUNT + 1
    hook_call \1, \2, save_hook_inline_stub_{d:SAVE_HOOK_INLINE_COUNT}
    rom0_code
save_hook_inline_stub_{d:SAVE_HOOK_INLINE_COUNT}:
ENDM

MACRO end_save_hook_inline
    jp save_trampoline_bare
    end_code
ENDM

; Declare that the config hooks the game's save itself with hand-written
; patch_rom/rom0_code blocks ending in `jp save_trampoline_bare` (or
; `call` + own flow). Only effect: save_trampoline_bare is emitted and the
; "no save_hook declared" assertion is satisfied.
MACRO save_hook_manual
    REDEF SAVE_HOOK_INLINE_COUNT = SAVE_HOOK_INLINE_COUNT + 1
ENDM


; ---------------------------- low-level primitives ----------------------------

; Overwrite the `call nnnn` instruction at BANK:ADDR with `call Target`.
MACRO hook_call
    PUSHS
    IF (\1) == 0
        SECTION "hook call \1 \2", ROM0[(\2)]
    ELSE
        SECTION "hook call \1 \2", ROMX[(\2)], BANK[(\1)]
    ENDC
    call \3
    POPS
ENDM

; Overwrite the `jp nnnn` instruction at BANK:ADDR with `jp Target`.
MACRO hook_jp
    PUSHS
    IF (\1) == 0
        SECTION "hook jp \1 \2", ROM0[(\2)]
    ELSE
        SECTION "hook jp \1 \2", ROMX[(\2)], BANK[(\1)]
    ENDC
    jp \3
    POPS
ENDM

; Overwrite arbitrary bytes at BANK:ADDR; close with end_patch.
MACRO patch_rom
    PUSHS
    IF (\1) == 0
        SECTION "patch \1 \2", ROM0[(\2)]
    ELSE
        SECTION "patch \1 \2", ROMX[(\2)], BANK[(\1)]
    ENDC
ENDM

MACRO end_patch
    POPS
ENDM


; ------------------------------- trampolines ---------------------------------

; Called by `finalize`: emit the trampolines for all used hooks.
MACRO finalize_hooks
    IF HOOKS_BOOT_COUNT > 0
        ASSERT DEF(GAME_ENTRY_POINT), "on_boot is used but the game config declares no entry_point"
        PUSHS
        ; overwrite the 3 bytes at $0100 with `jp boot_trampoline`, replacing
        ; the game's usual `nop` + `jp` opcode + operand low byte; the old
        ; operand high byte at $0103 remains as a dead byte. Games whose
        ; $0100 is not the standard `nop; jp nnnn` (e.g. Prism) must use
        ; patch_rom + a hand-rolled boot routine instead of entry_point.
        SECTION "entry point hook", ROM0[$0100]
        jp boot_trampoline
        POPS

        IF DEF(FREE_ROM0_START)
        rom0_code
        ELSE
        ASSERT FREE_ROMX_BANK == 1, "boot trampoline outside ROM0 requires ROMX free space in bank 1 (the bank mapped at boot)"
        romx_code
        ENDC
boot_trampoline:
        HOOKS_BOOT
        jp GAME_ENTRY_POINT
        end_code
    ENDC

    IF HOOKS_SAVE_COUNT > 0
        ASSERT SAVE_HOOK_SITE_COUNT > 0 || SAVE_HOOK_INLINE_COUNT > 0, "on_save is used but the game config declares no save_hook/save_hook_jp/save_hook_inline/save_hook_manual"
        IF SAVE_HOOK_SITE_COUNT > 0
        SAVE_HOOK_SITES
        rom0_code
save_trampoline:
        call GAME_SAVE_ROUTINE
        HOOKS_SAVE
        ret
        end_code
        ENDC
        IF SAVE_HOOK_INLINE_COUNT > 0
        rom0_code
save_trampoline_bare:
        HOOKS_SAVE
        ret
        end_code
        ENDC
    ENDC
ENDM
