# How to add a new save-states game

Moved to [docs/HOW-TO.md](../docs/HOW-TO.md).
