; md5 e12c5c2897ed095f8d26c7578afddfda

; ROM "Ninja Gaiden Shadow (U).gb"
; builds "Ninja Gaiden Shadow (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ffe3
DEF joypad_2 EQU $ffe4

    free_space_rom0_c $0062, $0062 + $40
    joypad_relocated_read_in_rom0_c

    joypad_hook $0a1d


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $2ad0, $2ad0 + $0220
    savestates_payload_in_rom0_b
