; md5 e12c5c2897ed095f8d26c7578afddfda

; ROM "Ninja Gaiden Shadow (U).gb"
; builds "savestates/Ninja Gaiden Shadow (U) (savestates).gb" with _SAVESTATES


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $ffe3
DEF joypad_2 EQU $ffe4

    free_space_rom0_c $0062, $0062 + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $0a1d


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $2ad0, $2ad0 + $0220
    savestates_payload_in_rom0_b
