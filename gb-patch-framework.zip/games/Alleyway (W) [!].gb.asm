; md5 91128778a332495f77699eaf3a37fe30

; ROM "Alleyway (W) [!].gb"
; builds "Alleyway (W) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $01a7


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $ff8c
DEF cpl_joypad EQU 1

    free_space_rom0_b $0062, $0062 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $03fb


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $4DE5, $4DE5 + $0220
