; md5 1e9baf36b209fd06854b8e5e064b00a8

; ROM "Pokemon - Green Patch v2.3 (UE) [S][!].gb"
; builds "Pokemon - Green Patch v2.3 (UE) [S][!] (savestates).gb" with _MBC5 _SAVESTATES


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ffb8
DEF SRAM_SIZE EQU CART_SRAM_32KB
DEF current_sram_bank EQU $fffd
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC3_RAM_BAT
; deliberately targets MBC5 (not the ROM's real original header type)
; — the save-state payload's bank placement, or a bootleg-flash-cart
; requirement, needs MBC5's addressing; CHANGE_CARTRIDGE_TYPE forces
; the header patch since the real original isn't already MBC5
IF DEF(_MBC5)
    DEF CHANGE_CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT
ENDC
SECTION "patch rom bank 0 req", ROMX[$6763], BANK[$0001] ; length: $1
    DB $01
ENDSECTION


; track current sram bank
SECTION "set sram bank", ROM0[$0001] ; length: $0007
set_sram_bank:
    ld [current_sram_bank], a
    ld [$4000], a
    ret
ENDSECTION

SECTION "call set sram bank 1", ROM0[$250d] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 2", ROM0[$169d] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 3", ROM0[$16eb] ; length: $3
    call set_sram_bank
ENDSECTION

SECTION "call set sram bank 4", ROMX[$60A8], BANK[$0001] ; length: $3
    call set_sram_bank
ENDSECTION

SECTION "call set sram bank 5", ROMX[$762D], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 6", ROMX[$769A], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 7", ROMX[$76C7], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 8", ROMX[$7ADB], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 9", ROMX[$7796], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 10", ROMX[$77EC], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 11", ROMX[$7819], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 12", ROMX[$791A], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 13", ROMX[$7A35], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 14", ROMX[$7A3D], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 15", ROMX[$7A94], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 16", ROMX[$7A9C], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 17", ROMX[$7B5C], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 18", ROMX[$7B8F], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION

SECTION "call set sram bank 19", ROMX[$6CE1], BANK[$000f] ; length: $3
    call set_sram_bank
ENDSECTION


; joypad
DEF joypad EQU $fff8

    free_space_rom0 $00bf, $00bf + $0040

    joypad_hook $0195


; save/load state
    free_space_romx $0001, $7D00, $7D00 + $0260

