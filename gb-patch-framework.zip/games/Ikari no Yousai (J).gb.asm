; md5 ac04d143de6734e181a223d05178bde8

; ROM "Ikari no Yousai (J).gb"
; builds "savestates/Ikari no Yousai (J) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $ffcc


;**********
;* joypad *
;**********

DEF joypad EQU $ffd7
DEF joypad_2 EQU $ffd8

    savestates_joypad_hook_banked $00, $015b, $019b


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7C2A, $7C2A + $02a0
