; md5 ac04d143de6734e181a223d05178bde8

; ROM "Ikari no Yousai (J).gb"
; builds "Ikari no Yousai (J) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ffcc


;**********
;* joypad *
;**********

DEF joypad EQU $ffd7
DEF joypad_2 EQU $ffd8

    joypad_hook_banked $00, $015b, $019b


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7C2A, $7C2A + $02a0
