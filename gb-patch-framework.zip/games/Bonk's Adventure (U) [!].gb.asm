; md5 79d6e6515905ec3fbcbd9e50ff469000

; ROM "Bonk's Adventure (U) [!].gb"
; builds "savestates/Bonk's Adventure (U) [!] (savestates).gb" with _SAVESTATES


; config
DEF current_rom_bank EQU $c148


; reset ram
    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0024, $0024 + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $ff8d
DEF joypad_2 EQU $ff8e

    free_space_rom0_b $0071, $0071 + $0038
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $0592


; save/load state
    free_space_romx $0001, $7B91, $7B91 + $0220
