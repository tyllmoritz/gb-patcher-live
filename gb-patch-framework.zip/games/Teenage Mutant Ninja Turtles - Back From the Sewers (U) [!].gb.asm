; md5 0221de99d11f50f79430c8ff9b430994

; ROM "Teenage Mutant Ninja Turtles - Back From the Sewers (U) [!].gb"
; builds "savestates/Teenage Mutant Ninja Turtles - Back From the Sewers (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $c7a7


;**********
;* joypad *
;**********

DEF joypad EQU $c78e
DEF joypad_2 EQU $c78f
DEF swap_joypad EQU 1

    free_space_rom0 $00be, $00be + $40

    savestates_joypad_hook $083b


;*******************
;* save/load state *
;*******************

    free_space_romx $0010, $4000, $4000 + $0220
