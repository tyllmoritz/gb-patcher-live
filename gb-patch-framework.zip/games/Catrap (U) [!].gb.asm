; md5 5a75fe8de54e4cbd09cae23f050f6965

; ROM "Catrap (U) [!].gb"
; builds "Catrap (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b
DEF current_rom_bank EQU $0005


;*************************
;* relocated joypad read *
;*************************

    free_space_rom0 $00c1, $00c1 + $3f


;***************
;* joypad read *
;***************

    joypad_hook $021f
    savestates_marker --- Catrap Save Patch ---


;*******************
;* save/load state *
;*******************

    free_space_romx $2, $4000, $4000 + $4000
