; md5 5a75fe8de54e4cbd09cae23f050f6965

; ROM "Catrap (U) [!].gb"
; builds "savestates/Catrap (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b
DEF current_rom_bank EQU $0005


;*************************
;* relocated joypad read *
;*************************

    free_space_rom0 $00c1, $00c1 + $3f


;***************
;* joypad read *
;***************

    savestates_joypad_hook $021f
    savestates_marker --- Catrap Save Patch ---


;*******************
;* save/load state *
;*******************

    free_space_romx $2, $4000, $4000 + $4000
