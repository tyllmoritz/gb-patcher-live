; md5 b5c541c765fd3a5767b3fa1cfc821587

; ROM "After Burst (J).gb"
; builds "savestates/After Burst (J) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c0f1
DEF joypad_2 EQU $c0ef
DEF joypad_3 EQU $c0f0
DEF current_rom_bank EQU $c925


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0063, $0063 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $0387


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $220
