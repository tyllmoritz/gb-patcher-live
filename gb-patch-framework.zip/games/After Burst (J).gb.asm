; md5 b5c541c765fd3a5767b3fa1cfc821587

; ROM "After Burst (J).gb"
; builds "After Burst (J) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c0f1
DEF joypad_2 EQU $c0ef
DEF joypad_3 EQU $c0f0
DEF current_rom_bank EQU $c925


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0063, $0063 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $0387


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $220
