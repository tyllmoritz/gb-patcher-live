; md5 05ba7f165dab1ffd49b63b4f5c704c02

; ROM "Faceball 2000 (U) [!].gb"
; builds "Faceball 2000 (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF joypad EQU $c901
DEF current_rom_bank EQU $ff80


;*************
;* reset ram *
;*************

    entry_point $09b1
    free_space_rom0 $0065, $0065 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $14bb


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $5DB5, $5DB5 + $02a0
