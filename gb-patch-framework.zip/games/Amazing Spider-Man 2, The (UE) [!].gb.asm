; md5 506ccd75db221acbf26f1681f3c97efd

; ROM "Amazing Spider-Man 2, The (UE) [!].gb"
; builds "savestates/Amazing Spider-Man 2, The (UE) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffb2
DEF joypad_2 EQU $d096
DEF current_rom_bank EQU $d0e4


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $02b4


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
