; md5 506ccd75db221acbf26f1681f3c97efd

; ROM "Amazing Spider-Man 2, The (UE) [!].gb"
; builds "Amazing Spider-Man 2, The (UE) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ffb2
DEF joypad_2 EQU $d096
DEF current_rom_bank EQU $d0e4


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $02b4


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
