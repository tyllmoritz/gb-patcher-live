; md5 7e4c9c3620bea7b633394beb67e9680b

; ROM "Bomberman GB (U) [S][!].gb"
; builds "savestates/Bomberman GB (U) [S][!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $ff92


;*************
;* reset ram *
;*************

    entry_point $0159
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0080, $0080 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    savestates_vblank_hook $0062, $01af


;*******************
;* save/load state *
;*******************

    free_space_romx $0010, $4000, $4000 + $02a0
