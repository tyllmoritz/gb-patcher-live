; md5 916d740fc366ecbf9e5626218e56562d

; ROM "Wetrix GB (E) [C][!].gbc"
; builds "Wetrix GB (E) [C][!] (savestates).gbc" with _SAVESTATES
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $ffb1
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5


; joypad
DEF joypad EQU $ff8c
DEF joypad_2 EQU $ff8d

    free_space_rom0 $007e, $007e + $40

    joypad_hook $08ca


; save/load state
    free_space_rom0_b $119e, $119e + $0270
    savestates_payload_in_rom0_b
