; md5 916d740fc366ecbf9e5626218e56562d

; ROM "Wetrix GB (E) [C][!].gbc"
; builds "savestates/Wetrix GB (E) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF is_cgb EQU 1
DEF current_rom_bank EQU $ffb1
DEF uses_mbc5 EQU 1


; joypad
DEF joypad EQU $ff8c
DEF joypad_2 EQU $ff8d

    free_space_rom0 $007e, $007e + $40

    savestates_joypad_hook $08ca


; save/load state
    free_space_rom0_b $119e, $119e + $0270
    savestates_payload_in_rom0_b
