; md5 298c80fe568bb2ff8bb7e4dfe5862a9d

; ROM "Probotector (E) [!].gb"
; builds "savestates/Probotector (E) [!] (savestates).gb" with _SAVESTATES


; config
DEF current_rom_bank EQU $7fff


; reset ram
    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00e6, $00e6 + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $dee6
DEF joypad_2 EQU $dee7
DEF swap_joypad EQU 1

    savestates_joypad_hook_banked $00, $16be


; save/load state
    free_space_romx $0008, $4000, $4000 + $02a0

SECTION "new bank", ROMX[$7FFF], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
