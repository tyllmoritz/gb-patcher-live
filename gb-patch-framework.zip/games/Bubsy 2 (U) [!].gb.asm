; md5 c80413993cb4a5b79c9cdd04235010dd

; ROM "Bubsy 2 (U) [!].gb"
; builds "savestates/Bubsy 2 (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff96
DEF joypad_2 EQU $ff97
DEF current_rom_bank EQU $c0f0


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $008c, $008c + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $004b, $004b + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $076c


;*******************
;* save/load state *
;*******************

    free_space_romx $0010, $4000, $4000 + $0220
