; md5 c80413993cb4a5b79c9cdd04235010dd

; ROM "Bubsy 2 (U) [!].gb"
; builds "Bubsy 2 (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff96
DEF joypad_2 EQU $ff97
DEF current_rom_bank EQU $c0f0


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $008c, $008c + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $004b, $004b + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $076c


;*******************
;* save/load state *
;*******************

    free_space_romx $0010, $4000, $4000 + $0220
