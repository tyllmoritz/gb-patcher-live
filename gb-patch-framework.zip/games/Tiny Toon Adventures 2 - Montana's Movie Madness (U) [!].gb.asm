; md5 7aa389f71808dc989a38b41009a32851

; ROM "Tiny Toon Adventures 2 - Montana's Movie Madness (U) [!].gb"
; builds "Tiny Toon Adventures 2 - Montana's Movie Madness (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $7fff


; reset ram
    entry_point $0150
    free_space_rom0 $00eb, $00eb + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $ff88
DEF joypad_2 EQU $ff89
DEF swap_joypad EQU 1

    joypad_hook_banked $00, $0212


; save/load state
    free_space_romx $0008, $4000, $4000 + $02a0

SECTION "new bank", ROMX[$7FFF], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
