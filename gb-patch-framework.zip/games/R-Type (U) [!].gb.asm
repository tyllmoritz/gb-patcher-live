; md5 972dc35b3b2bd0762999b1ae48da94f6

; ROM "R-Type (U) [!].gb"
; builds "R-Type (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $d0a0
DEF joypad_2 EQU $d0a1
DEF current_rom_bank EQU $d11a


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $39e4


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $78B2, $78B2 + $0220
