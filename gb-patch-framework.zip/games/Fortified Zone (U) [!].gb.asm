; md5 a981378da19c08597db03f3ee02cd6d7

; ROM "Fortified Zone (U) [!].gb"
; builds "savestates/Fortified Zone (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffd7
DEF joypad_2 EQU $ffd8
DEF current_rom_bank EQU $ffcc


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00c1, $00c1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0071, $0071 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $0197


;*******************
;* save/load state *
;*******************

    free_space_romx $0005, $72B1, $72B1 + $0220
