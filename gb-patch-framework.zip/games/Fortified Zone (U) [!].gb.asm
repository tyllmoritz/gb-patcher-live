; md5 a981378da19c08597db03f3ee02cd6d7

; ROM "Fortified Zone (U) [!].gb"
; builds "Fortified Zone (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ffd7
DEF joypad_2 EQU $ffd8
DEF current_rom_bank EQU $ffcc


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00c1, $00c1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0071, $0071 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $0197


;*******************
;* save/load state *
;*******************

    free_space_romx $0005, $72B1, $72B1 + $0220
