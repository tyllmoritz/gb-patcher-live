; md5 02a6e150efc50f481042fd542023a550

; ROM "Rodland (U).gb"
; builds "savestates/Rodland (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c101
DEF joypad_2 EQU $c102
DEF current_rom_bank EQU $c1ce


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $00c8


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $02a0
