; md5 02a6e150efc50f481042fd542023a550

; ROM "Rodland (U).gb"
; builds "Rodland (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c101
DEF joypad_2 EQU $c102
DEF current_rom_bank EQU $c1ce


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $00c8


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $02a0
