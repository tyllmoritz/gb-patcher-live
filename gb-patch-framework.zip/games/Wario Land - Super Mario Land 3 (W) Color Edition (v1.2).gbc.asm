; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; ROM "Wario Land - Super Mario Land 3 (W) Color Edition (v1.2).gbc"
; md5 ee6bcaa3ff5b992bac378591a02b2e6f
;
; builds "Wario Land - Super Mario Land 3 (W) Color Edition (v1.2) (savestates).gbc" with _SAVESTATES
;
; ------------------------------------------------------------------------------

; game properties
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF current_rom_bank EQU $a8c5

; where the game keeps the joypad state
DEF joypad EQU $ff80
DEF joypad_2 EQU $ff81

; free space in the original ROM
    free_space_romx $11, $5c01, $5c01 + $0315

; the game's joypad read routine at $11f0 (length $20) is replaced with a
; bank-switching call into the save-state machinery
    joypad_hook_banked $00, $11f0
