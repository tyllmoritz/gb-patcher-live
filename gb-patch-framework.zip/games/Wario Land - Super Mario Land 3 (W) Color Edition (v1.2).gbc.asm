; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; ROM "Wario Land - Super Mario Land 3 (W) Color Edition (v1.2).gbc"
; SHA1 239f0129d21250e3c6976229435161e6862dc334
;
; builds "savestates/Wario Land - Super Mario Land 3 (W) Color Edition (v1.2) (savestates).gbc" with _SAVESTATES
;
; ------------------------------------------------------------------------------

; game properties
DEF is_cgb EQU 1
DEF uses_mbc5 EQU 1
DEF game_uses_save_ram EQU 1
DEF current_rom_bank EQU $a8c5

; where the game keeps the joypad state
DEF joypad EQU $ff80
DEF joypad_2 EQU $ff81

; free space in the original ROM
    free_space_romx $11, $5c01, $5c01 + $0315

; the game's joypad read routine at $11f0 (length $20) is replaced with a
; bank-switching call into the save-state machinery
    savestates_joypad_hook_banked $00, $11f0
