; md5 b340bad71c781bd1394d95241ed1adce

; ROM "Cosmo Tank (U) [!].gb"
; builds "savestates/Cosmo Tank (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $c628


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0003, $0003 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $0560, $0594


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
