; md5 b340bad71c781bd1394d95241ed1adce

; ROM "Cosmo Tank (U) [!].gb"
; builds "Cosmo Tank (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $c628


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $0003, $0003 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $0560, $0594


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
