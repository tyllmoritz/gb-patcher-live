; md5 cd6ca2a01e2310193c46afcbfa382ab5

; ROM "Hero Shuugou!! Pinball Party (J) [!].gb"
; builds "savestates/Hero Shuugou!! Pinball Party (J) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $ff9d


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0062, $0062 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $01be


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $0220
