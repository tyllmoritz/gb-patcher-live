; md5 e83411adccf5266f2deb263e67b68bc1

; ROM "Godzilla (U) [!].gb"
; builds "savestates/Godzilla (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $ff91

;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $0062, $0062 + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $0297


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $2f68, $2f68 + $0220
    savestates_payload_in_rom0_b
