; md5 57032a17c7e6aa00eb8e064a87279898

; ROM "Metroid II DX - Return of Samus (W) [!].gbc"
; builds "savestates/Metroid II DX - Return of Samus (W) [!] (savestates).gbc" with _SAVESTATES
; builds "savestates/Metroid II DX - Return of Samus (W) [!] (batteryless).gbc" with _BATTERYLESS
; builds "savestates/Metroid II DX - Return of Samus (W) [!] (streaming_savestates).gbc" with _SAVESTATES _BATTERYLESS _CGB_STREAMING
; builds "savestates/Metroid II DX - Return of Samus (W) [!] (streaming_savestates_debug).gbc" with _SAVESTATES _BATTERYLESS _CGB_STREAMING _CGB_STREAMING_DEBUG


; config
DEF is_cgb EQU 1
DEF game_uses_save_ram EQU 1
DEF sram_size_32kb EQU 0                ; 8kb SRAM
DEF uses_mbc5 EQU 1
DEF current_rom_bank EQU $d04e         ; WRAMX bank 1
; joypad hook locations
DEF joypad EQU $ff80
DEF joypad_2 EQU $ff81
; batteryless free flash space
DEF flash_data_bank EQU $18             ; 4 banks sram save + 4 banks savestate

; boot hook
    entry_point $3fa7

; regions
    free_space_rom0 $0060, $0100
    free_space_rom0_b $3f60, $4000
    free_space_romx $15, $4000, $8000
    free_space_wram $de60, $de60 + $12c, $1 ; automatic pyboy detection: $de60-$dfdf
    free_space_hram $ff80, $ff80 + $5c      ; not actually free - is saved to wram when needed and restored afterwards

IF DEF(_BATTERYLESS)
    save_hook_manual

    patch_rom $01, $7b82
        call metroid_save_stub
        ret
        nop
    end_patch

    rom0_code
metroid_save_stub:
    ld a, $4
    ldh [$ff9b], a
    jp save_trampoline_bare
    end_code
ENDC

IF DEF(_SAVESTATES)
    savestates_joypad_hook $22b7
ENDC


IF DEF(_CGB_STREAMING)
    DEF cgb_streaming_savestates EQU 1
ENDC

IF DEF(_CGB_STREAMING_DEBUG)
    DEF stream_debug EQU 1
ENDC
