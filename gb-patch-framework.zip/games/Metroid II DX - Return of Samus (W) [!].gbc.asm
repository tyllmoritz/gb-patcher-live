; md5 57032a17c7e6aa00eb8e064a87279898

; ROM "Metroid II DX - Return of Samus (W) [!].gbc"
; builds "Metroid II DX - Return of Samus (W) [!] (savestates).gbc" with _MBC5 _SAVESTATES
; builds "Metroid II DX - Return of Samus (W) [!] (batteryless).gbc" with _MBC5 _BATTERYLESS
; builds "Metroid II DX - Return of Samus (W) [!] (batteryless_savestates).gbc" with _MBC5 _SAVESTATES _BATTERYLESS
; builds "Metroid II DX - Return of Samus (W) [!] (batteryless_savestates_debug).gbc" with _MBC5 _SAVESTATES _BATTERYLESS _DEBUG


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT
; deliberately targets MBC5 (not the ROM's real original header type)
; — the save-state payload's bank placement, or a bootleg-flash-cart
; requirement, needs MBC5's addressing; CHANGE_CARTRIDGE_TYPE forces
; the header patch since the real original isn't already MBC5
IF DEF(_MBC5)
    DEF CHANGE_CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT
ENDC
DEF current_rom_bank EQU $d04e         ; WRAMX bank 1
; joypad hook locations
DEF joypad EQU $ff80
DEF joypad_2 EQU $ff81
; batteryless free flash space
DEF flash_data_bank EQU $18             ; 4 banks sram save + 4 banks savestate

; boot hook
    entry_point $3fa7

; regions
    free_space_rom0 $009d, $0100   ; $63
    free_space_rom0_b $3f60, $3f98 ; $38
    free_space_rom0_c $3fd9, $4000 ; $27
    free_space_romx $15, $4000, $8000
    free_space_wram $de60, $de60 + $12c, $1 ; automatic pyboy detection: $de60-$dfdf
    free_space_hram $ff80, $ff80 + $5c      ; not actually free - is saved to wram when needed and restored afterwards

IF DEF(_BATTERYLESS)
    save_hook_manual

    patch_rom $01, $7b82
        call metroid_save_stub
        ret
        nop
    end_patch

    rom0_code
metroid_save_stub:
    ld a, $4
    ldh [$ff9b], a
    jp save_trampoline_bare
    end_code
ENDC

IF DEF(_SAVESTATES)
    joypad_hook $22b7
    joypad_relocated_read_in_rom0_b
ENDC
