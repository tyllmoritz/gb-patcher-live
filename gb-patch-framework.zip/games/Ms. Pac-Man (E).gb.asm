; md5 5cfa323ad8d8e4a6d50022d5c64b46fd

; ROM "Ms. Pac-Man (E).gb"
; builds "Ms. Pac-Man (E) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $4000


; reset ram
    entry_point $0150
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c

; hook site is 5 bytes (2 trailing nops), which doesn't match joypad_hook's
; fixed 4-byte emission, so it's patched manually; JOYPAD_HOOK_VARIANT is
; declared manually to match what joypad_hook would have set.
; relocated_read.asm goes in the second ROM0 region since the first is
; already reset_ram's.
DEF JOYPAD_HOOK_VARIANT EQU 0
    joypad_relocated_read_in_rom0_b
    free_space_rom0_b $0062, $0062 + $40

    patch_rom $00, $03ea
    call relocated_read_from_joypad
    nop
    nop
    end_patch


; save/load state
    free_space_romx $0001, $7070, $7070 + $0220
