; md5 b3e011cde1fa6b5bebcac15ac970c4a9

; ROM "Hook (E) [!].gb"
; builds "savestates/Hook (E) [!] (savestates).gb"


; config
DEF current_rom_bank EQU $c08d


; reset ram
    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0070, $0070 + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $ffb0
DEF swap_joypad EQU 1

SECTION "joypad read", ROM0[$02d2] ; length: 4
    call relocated_read_from_joypad
    nop
ENDSECTION

SECTION "relocated read from joypad", ROM0[$0000] ; length: $003d
relocated_read_from_joypad:
    ld a,$30
    ld [$ff00+$00],a

    ld a, b
    ld [$ff00+$b0], a
    INCLUDE "src/features/savestates/joypad_check.asm"
    ld a, [$ff00+$b0]
    ld b, a

    ret
ENDSECTION


; save/load state
SECTION "save/load state", ROMX[$4000], BANK[$0008] ; length: $0220
    DB "--- Save Patch ---"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
