; md5 b3e011cde1fa6b5bebcac15ac970c4a9

; ROM "Hook (E) [!].gb"
; builds "Hook (E) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $c08d


; reset ram
    entry_point $0150
    free_space_rom0 $0070, $0070 + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $ffb0
DEF swap_joypad EQU 1

; custom, hand-written relocated_read_from_joypad body (register preservation
; around the standard check.asm) doesn't match the framework's generic
; implementation, so its automatic placement is skipped; it goes in the
; second ROM0 region since the first is reset_ram's.
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    joypad_hook $02d2
    free_space_rom0_b $0000, $0000 + $50
    rom0_code_b
relocated_read_from_joypad:
    ld a,$30
    ld [$ff00+$00],a

    ld a, b
    ld [$ff00+$b0], a
    INCLUDE "src/core/hooks/joypad/check.asm"
    ld a, [$ff00+$b0]
    ld b, a

    ret
    end_code


; save/load state
    free_space_romx $0008, $4000, $4000 + $0220
