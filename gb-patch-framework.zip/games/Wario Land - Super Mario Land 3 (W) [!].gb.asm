; md5 d9d957771484ef846d4e8d241f6f2815

; ROM "Wario Land - Super Mario Land 3 (W) [!].gb"
; builds "Wario Land - Super Mario Land 3 (W) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff00+$80
DEF joypad_2 EQU $ff00+$81
DEF current_rom_bank EQU $a8c5
DEF current_nr34_value EQU $a64e
DEF SRAM_SIZE EQU CART_SRAM_8KB
;***************
;* joypad read *
;***************

; Custom shape: hand-written MBC1-style bank switch (direct $2100 write, not
; call_in_other_bank.asm), two hook sites (one for the joypad read, one for
; a separate joypad-check call site), and a custom, hand-placed
; relocated_read_from_joypad in the save/load payload — needs
; JOYPAD_CUSTOM_RELOCATED_READ.
DEF JOYPAD_HOOK_VARIANT EQU 1
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    patch_rom $00, $11f0
    ld a,[current_rom_bank]
    push af
    ld a,BANK(relocated_read_from_joypad)
    ld [current_rom_bank],a
    ld [$2100],a
    call relocated_read_from_joypad
    pop af
    ld [current_rom_bank],a
    ld [$2100],a
    jr resume

invoke_joypad_check:
    ld a,[current_rom_bank]
    push af
    ld a,BANK(joypad_check)
    ld [current_rom_bank],a
    ld [$2100],a
    call joypad_check
    pop af
    ld [current_rom_bank],a
    ld [$2100],a
    ret
resume:
    end_patch

    patch_rom $00, $124d
    jp invoke_joypad_check
    end_patch


;*******************
;* save/load state *
;*******************

    savestates_marker --- Wario Land Save Patch ---
    free_space_romx $11, $7A00, $7A00 + $600
    romx_code

relocated_read_from_joypad:
    INCLUDE "src/core/hooks/joypad/read.asm"
    ret

    INCLUDE "src/core/hooks/joypad/check.asm"
    ret
    end_code
