; md5 6e8166c3783d1807d0a8c3b649e583c1

; ROM "Blades of Steel (E) [!].gb"
; builds "Blades of Steel (E) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $d806
DEF joypad_2 EQU $d807
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $0031, $0031 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $0c33, $0c6e


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $7B84, $7B84 + $02a0
