; md5 66fc892b9682e8e2981fa83fa681ccad

; ROM "Hit the Ice (UE) [!].gb"
; builds "Hit the Ice (UE) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c5e9
DEF current_rom_bank EQU $c5a1


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $0bfe


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $772A, $772A + $02a0
