; md5 66fc892b9682e8e2981fa83fa681ccad

; ROM "Hit the Ice (UE) [!].gb"
; builds "savestates/Hit the Ice (UE) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c5e9
DEF current_rom_bank EQU $c5a1


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $0bfe


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $772A, $772A + $02a0
