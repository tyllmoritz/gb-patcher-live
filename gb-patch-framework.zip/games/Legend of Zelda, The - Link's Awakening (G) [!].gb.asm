; md5 8b7af1a8ca96c74301d633e0ce83ba0b

; ROM "Legend of Zelda, The - Link's Awakening (G) [!].gb"
; builds "savestates/Legend of Zelda, The - Link's Awakening (G) [!] (savestates).gb" with _SAVESTATES


; config
DEF current_rom_bank EQU $dbaf
DEF game_uses_save_ram EQU 1


; reset ram
    entry_point $0150

INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0006, $0006 + $F
    on_boot_inline reset_ram


; joypad
DEF joypad EQU $ffcb
DEF joypad_2 EQU $ffcc
DEF swap_joypad EQU 1

    free_space_rom0_b $0092, $0092 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $2838


; save/load state
    free_space_romx $0009, $6e2a, $6e2a + $0245
