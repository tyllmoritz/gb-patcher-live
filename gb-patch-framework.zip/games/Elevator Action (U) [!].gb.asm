; md5 7876945a990ea94ac6b1fe5cf01bc00f

; ROM "Elevator Action (U) [!].gb"
; builds "savestates/Elevator Action (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffac
DEF joypad_2 EQU $ffad

; MANUAL EDIT - current rom bank not stored, so assume bank 1 during joypad read routine
DEF current_rom_bank EQU $01a5

;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $0e57, $0e87


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $02a0
