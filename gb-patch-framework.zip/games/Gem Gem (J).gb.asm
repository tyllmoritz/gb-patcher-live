; md5 75963dd8e91147452bfa88f0d608d554

; ROM "Gem Gem (J).gb"
; builds "Gem Gem (J) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF joypad_3 EQU $d00e
DEF current_rom_bank EQU $c103
DEF SRAM_SIZE EQU CART_SRAM_8KB
;*************
;* reset ram *
;*************

    entry_point $016c
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0062, $0062 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $04dc


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $0245
