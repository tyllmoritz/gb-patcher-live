; md5 75963dd8e91147452bfa88f0d608d554

; ROM "Gem Gem (J).gb"
; builds "savestates/Gem Gem (J) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF joypad_3 EQU $d00e
DEF current_rom_bank EQU $c103
DEF game_uses_save_ram EQU 1


;*************
;* reset ram *
;*************

    entry_point $016c
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0062, $0062 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $04dc


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $0245
