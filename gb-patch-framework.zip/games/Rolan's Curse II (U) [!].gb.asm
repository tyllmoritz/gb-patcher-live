; md5 27f2c99b13cbdb5a5be4afce87b9039b

; ROM "Rolan's Curse II (U) [!].gb"
; builds "savestates/Rolan's Curse II (U) [!] (savestates).gb"


; config
DEF current_rom_bank EQU $ff8e
DEF game_uses_save_ram EQU 1


;*************
;* reset ram *
;*************
    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00c0, $00c0 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

DEF vblank_handler EQU $0062
DEF original_vblank_handler EQU $039c
DEF original_vblank_handler_pushes EQU 1
MACRO original_vblank_handler_pushes_macro
    db $f5, $c5, $d5, $e5
ENDM
INCLUDE "src/features/savestates/vblank_handler.asm"


; save/load state
SECTION "save/load state", ROMX[$4000], BANK[$0008] ; length: $02c5
    DB "--- Save Patch ---"
    INCLUDE "src/features/savestates/joypad_read_and_check.asm"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
