; md5 27f2c99b13cbdb5a5be4afce87b9039b

; ROM "Rolan's Curse II (U) [!].gb"
; builds "Rolan's Curse II (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC2_BAT


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ff8e
DEF SRAM_SIZE EQU CART_SRAM_2KB  ; MBC2 512x4-bit internal RAM (not real 8/32kb SRAM)
;*************
;* reset ram *
;*************
    entry_point $0150
    free_space_rom0 $00c0, $00c0 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

MACRO original_vblank_handler_pushes_macro
    db $f5, $c5, $d5, $e5
ENDM
    joypad_vblank_hook $0062, $039c, original_vblank_handler_pushes


; save/load state
    free_space_romx $0008, $4000, $4000 + $02c5
