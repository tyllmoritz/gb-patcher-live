; md5 3c3f9f06b791df796b55ac94f2188ff2

; ROM "Rainbow Islands (E) (M5) [C][!].gbc"
; builds "Rainbow Islands (E) (M5) [C][!] (savestates).gbc" with _SAVESTATES
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $ff89
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5


; joypad
DEF joypad EQU $c134
DEF joypad_2 EQU $c135

    free_space_rom0 $0062, $0062 + $40

    joypad_hook $0395


; save/load state
    free_space_rom0_b $3d8a, $3d8a + $0270
    savestates_payload_in_rom0_b
