; md5 9b846e9a4eb6b80cdbc8e6c82f2b9e9e

; ROM "Ghosts 'N Goblins (U) [C][!].gbc"
; builds "savestates/Ghosts 'N Goblins (U) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF is_cgb EQU 1
DEF current_rom_bank EQU $7fff
DEF uses_mbc5 EQU 1


; joypad
DEF joypad EQU $c0e0
DEF joypad_2 EQU $c0e1

    free_space_rom0 $00bf, $00bf + $40

    savestates_joypad_hook $009b


; save/load state
    free_space_romx $0002, $5BD9, $5BD9 + $0270
