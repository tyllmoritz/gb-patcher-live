; md5 9b846e9a4eb6b80cdbc8e6c82f2b9e9e

; ROM "Ghosts 'N Goblins (U) [C][!].gbc"
; builds "Ghosts 'N Goblins (U) [C][!] (savestates).gbc" with _SAVESTATES
DEF SRAM_SIZE EQU CART_SRAM_NONE
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG_GBC


; config
DEF CHANGE_GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC  ; save/load code needs CGB-exclusive hardware; forbid DMG-mode boot
DEF current_rom_bank EQU $7fff
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5


; joypad
DEF joypad EQU $c0e0
DEF joypad_2 EQU $c0e1

    free_space_rom0 $00bf, $00bf + $40

    joypad_hook $009b


; save/load state
    free_space_romx $0002, $5BD9, $5BD9 + $0270
