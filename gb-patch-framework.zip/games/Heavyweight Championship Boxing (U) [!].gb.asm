; md5 1f8089ca53d6e9aff6d1907710d28bc8

; ROM "Heavyweight Championship Boxing (U) [!].gb"
; builds "savestates/Heavyweight Championship Boxing (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $df09
DEF joypad_2 EQU $df0a
DEF current_rom_bank EQU $4000


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0062, $0062 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $2748


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4001, $4001 + $0220

SECTION "new bank", ROMX[$4000], BANK[$0004] ; length: 1
    DB $4
ENDSECTION
