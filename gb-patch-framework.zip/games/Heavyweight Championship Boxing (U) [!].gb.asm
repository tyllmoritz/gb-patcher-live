; md5 1f8089ca53d6e9aff6d1907710d28bc8

; ROM "Heavyweight Championship Boxing (U) [!].gb"
; builds "Heavyweight Championship Boxing (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $df09
DEF joypad_2 EQU $df0a
DEF current_rom_bank EQU $4000


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0062, $0062 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $2748


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4001, $4001 + $0220

SECTION "new bank", ROMX[$4000], BANK[$0004] ; length: 1
    DB $4
ENDSECTION
