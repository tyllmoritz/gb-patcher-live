; md5 16bb3fb83e8cbbf2c4c510b9f50cf4ee

; ROM "Wario Land 3 (JU) (M2) [C][!].gbc"
; builds "Wario Land 3 (JU) (M2) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $c5ff
DEF SRAM_SIZE EQU CART_SRAM_32KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT
DEF current_sram_bank EQU $c08e


; joypad
DEF joypad EQU $c093
DEF joypad_2 EQU $c094

    free_space_rom0 $009b, $009b + $40

    joypad_hook $0413


; save/load state
    free_space_rom0_b $1c6d, $1c6d + $02bd
    savestates_payload_in_rom0_b
