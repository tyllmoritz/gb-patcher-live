; md5 16bb3fb83e8cbbf2c4c510b9f50cf4ee

; ROM "Wario Land 3 (JU) (M2) [C][!].gbc"
; builds "savestates/Wario Land 3 (JU) (M2) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF is_cgb EQU 1
DEF current_rom_bank EQU $c5ff
DEF game_uses_save_ram EQU 1
DEF uses_mbc5 EQU 1
DEF current_sram_bank EQU $c08e


; joypad
DEF joypad EQU $c093
DEF joypad_2 EQU $c094

    free_space_rom0 $009b, $009b + $40

    savestates_joypad_hook $0413


; save/load state
    free_space_rom0_b $1c6d, $1c6d + $02bd
    savestates_payload_in_rom0_b
