; md5 8fdffb08770609255ec3cd314f79f976

; ROM "Banishing Racer (J).gb"
; builds "savestates/Banishing Racer (J) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffdc
DEF joypad_2 EQU $ffdd
DEF current_rom_bank EQU $ffe6


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0020, $0020 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $05bc, $05fc


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
