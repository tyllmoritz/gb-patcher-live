; md5 7c65e9da405d2225d079f75e56276822

; ROM "Castlevania II - Belmont's Revenge (U) [!].gb"
; builds "savestates/Castlevania II - Belmont's Revenge (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c886
DEF joypad_2 EQU $c887
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $7fff
DEF current_nr34_value EQU $c1c4
DEF restore_sound EQU 1


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $3503


;*******************
;* save/load state *
;*******************

    free_space_romx $8, $4000, $4000 + $4000
    savestates_marker --- Castlevania 2 Save Patch ---
