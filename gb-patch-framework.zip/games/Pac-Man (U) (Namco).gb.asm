; md5 cd9027e147f4605f26ee261c537441b3

; ROM "Pac-Man (U) (Namco).gb"
; builds "Pac-Man (U) (Namco) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $d600


; reset ram
    entry_point $0867
    free_space_rom0 $00d4, $00d4 + $F
    on_boot_inline reset_ram



; vblank
    joypad_vblank_hook $0004, $03bb


; save/load state
    free_space_rom0_b $3381, $3381 + $02a0
    savestates_payload_in_rom0_b
