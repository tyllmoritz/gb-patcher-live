; md5 b4e5876c5acedd12b62e25a12973a4ae

; ROM "Duck Tales 2 (U) [!].gb"
; builds "savestates/Duck Tales 2 (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff92
DEF joypad_2 EQU $ff93
DEF current_rom_bank EQU $ff98


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $03c1


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $7D40, $7D40 + $0220
