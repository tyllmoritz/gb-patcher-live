; md5 ed5525a71dda6eaf4bbf8d5601b6b3b9

; ROM "Aladdin (U) [S][!].gb"
; builds "savestates/Aladdin (U) [S][!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c280
DEF current_rom_bank EQU $ddfa


;*************
;* reset ram *
;*************

    entry_point $01da
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0059, $0059 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0000, $0000 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $04ae


;*******************
;* save/load state *
;*******************

    free_space_romx $0010, $4000, $4000 + $220
