; md5 ed5525a71dda6eaf4bbf8d5601b6b3b9

; ROM "Aladdin (U) [S][!].gb"
; builds "Aladdin (U) [S][!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c280
DEF current_rom_bank EQU $ddfa


;*************
;* reset ram *
;*************

    entry_point $01da
    free_space_rom0 $0059, $0059 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0000, $0000 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $04ae


;*******************
;* save/load state *
;*******************

    free_space_romx $0010, $4000, $4000 + $220
