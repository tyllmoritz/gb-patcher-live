; md5 f6c1715b8b93356b8b8ad27f5574dc96

; ROM "Beetlejuice (U).gb"
; builds "Beetlejuice (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c939
DEF joypad_2 EQU $c93a
DEF current_rom_bank EQU $7fff


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $3de6, $3e19


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0

SECTION "new bank", ROMX[$7FFF], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
