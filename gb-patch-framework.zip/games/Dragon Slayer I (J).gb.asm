; md5 bc35dc3bf102cfa265c5c7348e674ba9

; ROM "Dragon Slayer I (J).gb"
; builds "savestates/Dragon Slayer I (J) (savestates).gb" with _SAVESTATES


; config
DEF current_rom_bank EQU $0159


; reset ram
    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $000c, $000c + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $ff8c
DEF joypad_2 EQU $ff8b

    free_space_rom0_b $0062, $0062 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $01fa


; save/load state
    free_space_romx $0002, $4000, $4000 + $0220
