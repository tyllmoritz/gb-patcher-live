; md5 bc35dc3bf102cfa265c5c7348e674ba9

; ROM "Dragon Slayer I (J).gb"
; builds "Dragon Slayer I (J) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $0159


; reset ram
    entry_point $0150
    free_space_rom0 $000c, $000c + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $ff8c
DEF joypad_2 EQU $ff8b

    free_space_rom0_b $0062, $0062 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $01fa


; save/load state
    free_space_romx $0002, $4000, $4000 + $0220
