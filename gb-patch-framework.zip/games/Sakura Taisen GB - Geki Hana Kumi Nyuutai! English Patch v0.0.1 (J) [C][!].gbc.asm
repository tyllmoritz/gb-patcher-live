; md5 ce604c67bf2806f5a6f736ba168ed271

; ROM "Sakura Taisen GB - Geki Hana Kumi Nyuutai! English Patch v0.0.1 (J) [C][!].gbc"
; builds "Sakura Taisen GB - Geki Hana Kumi Nyuutai! English Patch v0.0.1 (J) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $c292
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT


; joypad
DEF joypad EQU $c215

    free_space_rom0 $0064, $0064 + $40

    joypad_hook $03d1


; save/load state
    free_space_rom0_b $3300, $3300 + $0295
    savestates_payload_in_rom0_b


; fix for write to SRAM bank selection register at $08:$5f33
SECTION "fix", ROMX[$5F33], BANK[$0008] ; length: $1
    dec hl
ENDSECTION
