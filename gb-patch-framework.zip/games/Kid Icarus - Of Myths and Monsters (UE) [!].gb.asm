; md5 23c7be98ac9a4d3b046ad1be3f0965e4

; ROM "Kid Icarus - Of Myths and Monsters (UE) [!].gb"
; builds "Kid Icarus - Of Myths and Monsters (UE) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC2_BAT
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c015
DEF joypad_2 EQU $c016
DEF current_rom_bank EQU $7fff


;*************************
;* relocated joypad read *
;*************************

; the standard read_and_check.asm body is placed in its own ROM0 region here
; instead of alongside the save/load payload (which is in a different ROMX
; bank), so its automatic placement (which assumes the same region as the
; payload for this variant) is skipped; the hook site is a jp, not a call,
; so it's patched manually too.
DEF JOYPAD_HOOK_VARIANT EQU 1
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    free_space_rom0 $0080, $0080 + $70
    rom0_code
    INCLUDE "src/core/hooks/joypad/read_and_check.asm"
    end_code

    patch_rom $00, $0308
    jp relocated_read_from_joypad
    end_patch


;*******************
;* save/load state *
;*******************

    savestates_marker --- Kid Icarus Save Patch ---
    free_space_romx $01, $7D00, $7D00 + $2fe
