; ------------------------------------------------------------------------------
;                            Pokemon BW3: Genesis
;        find hack here: https://www.pokecommunity.com/threads/444114/
;        github: https://github.com/AzureKeys/BW3G/releases/tag/v1.2
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; ROM "Pokemon - Black and White 3 Genesis.gbc"
; md5 8e2b1b69fc12a4e75abd8063a55aa6ef
;
; builds "Pokemon - Black and White 3 Genesis (batteryless).gbc" with _BATTERYLESS
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC3_RAM_BAT_RTC
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
;
; ------------------------------------------------------------------------------

; game properties
; original header: CART_COMPATIBLE_GBC — save/load code doesn't need CGB-exclusive hardware here, so GB_COMPATIBILITY is left at its
; default (CART_COMPATIBLE_DMG) and the header is untouched
DEF SRAM_SIZE EQU CART_SRAM_32KB
DEF current_rom_bank EQU $ff9d
DEF flash_data_bank EQU $84

; free space in the original ROM/RAM
    free_space_rom0 $0063, $0100
    free_space_romx $80, $4000, $4300
    free_space_wram $dd00, $ddab, $5

; the game's `jp` at $0101 goes to $016e
    entry_point $016e

; call site of the game's own save routine ($5:$4b7c)
    save_hook $05, $4b53, $4b7c
