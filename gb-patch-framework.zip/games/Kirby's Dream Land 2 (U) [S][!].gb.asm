; md5 ddb5bfae32b0ca39cf8ab6c46880126c

; ROM "Kirby's Dream Land 2 (U) [S][!].gb"
; builds "Kirby's Dream Land 2 (U) [S][!] (savestates).gb" with _MBC5 _SAVESTATES


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ffc0        ; these bytes appear to be unused
DEF joypad_2 EQU $ffc1

DEF current_rom_bank EQU $ffa4
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF calling_from_vblank EQU 1
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT
; deliberately targets MBC5 (not the ROM's real original header type)
; — the save-state payload's bank placement, or a bootleg-flash-cart
; requirement, needs MBC5's addressing; CHANGE_CARTRIDGE_TYPE forces
; the header patch since the real original isn't already MBC5
IF DEF(_MBC5)
    DEF CHANGE_CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT
ENDC
DEF current_nr34_value EQU $ce14


;*************************
;* relocated joypad read *
;*************************

; Custom shape: reads the joypad from a direct jump at the vblank vector
; (not the standard vblank_handler.asm trampoline: no register push / JOYP
; select, since calling_from_vblank already tells the framework interrupts
; are disabled and no bank has been changed yet). Save/load payload uses
; the standard read_and_check.asm body, so JOYPAD_HOOK_VARIANT is declared
; manually without JOYPAD_CUSTOM_RELOCATED_READ.
DEF JOYPAD_HOOK_VARIANT EQU 1
    patch_rom $00, $0044
    jp invoke_relocated_read_from_joypad_in_other_bank
    end_patch

    free_space_rom0 $0080, $0080 + $70
    rom0_code
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    jp $0159
    end_code


;*******************
;* save/load state *
;*******************

    savestates_marker --- Kirby's Dream Land 2 Save Patch ---
    free_space_romx $20, $4000, $4000 + $4000
