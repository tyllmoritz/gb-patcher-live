; md5 4f3b84eb325f9162086fac77ac577e7c

; ROM "Double Dragon 2 (U) [!].gb"
; builds "Double Dragon 2 (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c907
DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00cb, $00cb + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $008a, $008a + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $140e


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220

SECTION "new bank", ROMX[$7FFF], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
