; md5 4f3b84eb325f9162086fac77ac577e7c

; ROM "Double Dragon 2 (U) [!].gb"
; builds "savestates/Double Dragon 2 (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c907
DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00cb, $00cb + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $008a, $008a + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $140e


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220

SECTION "new bank", ROMX[$7FFF], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
