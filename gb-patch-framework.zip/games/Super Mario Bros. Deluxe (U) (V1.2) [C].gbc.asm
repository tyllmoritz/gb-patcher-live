; md5 b5a71128227f5bc953fd55cb0025807f

; ROM "Super Mario Bros. Deluxe (U) (V1.2) [C].gbc"
; builds "savestates/Super Mario Bros. Deluxe (U) (V1.2) [C] (savestates).gbc" with _SAVESTATES


; config
DEF is_cgb EQU 1
DEF current_rom_bank EQU $ffbe
DEF game_uses_save_ram EQU 1
DEF uses_mbc5 EQU 1


; joypad
DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c

    free_space_rom0 $0062, $0062 + $40

    savestates_joypad_hook $120d


; save/load state
    free_space_romx $0003, $79D1, $79D1 + $0295
