; md5 d9da15a5481fdc184d75c6d190d45fd3

; ROM "Hyper Black Bass '95 (J).gb"
; builds "Hyper Black Bass '95 (J) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $c0ca


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0062, $0062 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $3963


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $7C57, $7C57 + $0220
