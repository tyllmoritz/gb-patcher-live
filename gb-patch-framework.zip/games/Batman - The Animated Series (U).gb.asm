; md5 ae073c63ff7d151dc2dd406830fbbdc2

; ROM "Batman - The Animated Series (U).gb"
; builds "savestates/Batman - The Animated Series (U) (savestates).gb" with _SAVESTATES


; config
DEF current_rom_bank EQU $ffa3


; joypad
DEF joypad EQU $ffa4
DEF joypad_2 EQU $ffa6
DEF joypad_3 EQU $ffa5
DEF joypad_4 EQU $ffa7
DEF swap_joypad EQU 1

    savestates_joypad_hook_banked $00, $0843, $087d


; save/load state
    free_space_romx $0008, $4000, $4000 + $02a0
