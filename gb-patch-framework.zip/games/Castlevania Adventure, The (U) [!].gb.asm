; md5 0b4410c6b94d6359dba5609ae9a32909

; ROM "Castlevania Adventure, The (U) [!].gb"
; builds "savestates/Castlevania Adventure, The (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c00c
DEF joypad_2 EQU $c00d
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $7fff
DEF current_nr34_value EQU $c236


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $0232


;*******************
;* save/load state *
;*******************


    free_space_romx $03, $7D4E, $7D4E + $2B0
    savestates_marker --- Castlevania Save Patch ---
