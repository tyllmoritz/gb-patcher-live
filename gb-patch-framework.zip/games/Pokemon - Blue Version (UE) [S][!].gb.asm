; md5 50927e843568814f7ed45ec4f944bd8b

; ROM "Pokemon - Blue Version (UE) [S][!].gb"
; builds "savestates/Pokemon - Blue Version (UE) [S][!] (savestates).gb" with _SAVESTATES


; config
DEF current_rom_bank EQU $ffb8
DEF game_uses_save_ram EQU 1
DEF current_sram_bank EQU $fffd
DEF uses_mbc5 EQU 1


; mbc 5 fix
SECTION "patch rom bank 0 req", ROMX[$6763], BANK[$0001] ; length: $1
    DB $01
ENDSECTION


; track current sram bank
SECTION "set sram bank", ROM0[$0001] ; length: $0007
set_sram_bank:
    ld [current_sram_bank], a
    ld [$4000], a
    ret
ENDSECTION

SECTION "call set sram bank 1", ROM0[$250d] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 2", ROM0[$169d] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 3", ROM0[$16eb] ; length: $3
    call set_sram_bank
ENDSECTION

SECTION "call set sram bank 4", ROMX[$60A8], BANK[$0001] ; length: $3
    call set_sram_bank
ENDSECTION

SECTION "call set sram bank 5", ROMX[$762D], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 6", ROMX[$769A], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 7", ROMX[$76C7], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 8", ROMX[$7ADB], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 9", ROMX[$7796], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 10", ROMX[$77EC], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 11", ROMX[$7819], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 12", ROMX[$791A], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 13", ROMX[$7A35], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 14", ROMX[$7A3D], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 15", ROMX[$7A94], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 16", ROMX[$7A9C], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 17", ROMX[$7B5C], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 18", ROMX[$7B8F], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION

SECTION "call set sram bank 19", ROMX[$6CE1], BANK[$000f] ; length: $3
    call set_sram_bank
ENDSECTION


; joypad
DEF joypad EQU $fff8

    free_space_rom0 $00bf, $00bf + $0040

    savestates_joypad_hook $0195


; save/load state
    free_space_romx $0001, $7C4A, $7C4A + $0260
