; md5 f97902058640f3700b5acff422969ba3

; ROM "GB Basketball (J).gb"
; builds "GB Basketball (J) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff9a


;*************
;* reset ram *
;*************

    entry_point $03f0
    free_space_rom0 $00eb, $00eb + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $00aa, $00aa + $40
    joypad_relocated_read_in_rom0_c

    joypad_hook $0713


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $3d4a, $3d4a + $0220
    savestates_payload_in_rom0_b
