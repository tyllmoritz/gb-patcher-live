; md5 4fd68c1cf8b57e90a5b11b054fc68b46

; ROM "Donald Duck - Goin' Quackers (U) (M5) [C][!].gbc"
; builds "Donald Duck - Goin' Quackers (U) (M5) [C][!] (savestates).gbc" with _SAVESTATES
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $0168
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5


; joypad

; Custom shape: the hook site lives in ROMX bank 1, calling a ROM0 stub that
; bank-switches to relocated_read_from_joypad (which lives in the save/load
; payload's own ROMX bank) — see Burning Paper for the same pattern.
DEF joypad EQU $c46e
DEF JOYPAD_HOOK_VARIANT EQU 1
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    free_space_rom0 $0024, $0024 + 40
    rom0_code
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    ret
    end_code

    patch_rom $0001, $41DB
    call invoke_relocated_read_from_joypad_in_other_bank
    end_patch


; save/load state
    free_space_romx $0001, $7A6D, $7A6D + $02f0
    romx_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    end_code
