; md5 6dfcaebffc8e2645bb2b1e5be69e1514

; ROM "Donald Duck in Maui Mallard (U) [!].gb"
; builds "Donald Duck in Maui Mallard (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8c
DEF current_rom_bank EQU $4000


;*************
;* reset ram *
;*************

    entry_point $0444
    free_space_rom0 $00ab, $00ab + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $006b, $006b + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $060a


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $7724, $7724 + $0220
