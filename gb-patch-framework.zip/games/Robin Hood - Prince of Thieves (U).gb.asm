; md5 2815ff13131712bcd00c3852d461b414

; ROM "Robin Hood - Prince of Thieves (U).gb"
; builds "savestates/Robin Hood - Prince of Thieves (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $fffe


;*************
;* reset ram *
;*************

    entry_point $0070
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0029, $0029 + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $d053
DEF joypad_2 EQU $d054

    savestates_joypad_hook_banked $00, $0e8d, $0ec1


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $7339, $7339 + $02a0
