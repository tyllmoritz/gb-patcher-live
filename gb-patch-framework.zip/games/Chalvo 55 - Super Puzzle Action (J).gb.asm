; md5 ba50565630891680c9cf8b1827fca429

; ROM "Chalvo 55 - Super Puzzle Action (J).gb"
; builds "Chalvo 55 - Super Puzzle Action (J) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff9b
DEF joypad_2 EQU $ff9c
DEF current_rom_bank EQU $c9ff
DEF current_nr34_value EQU $cb74

;*************************
;* relocated joypad read *
;*************************

    free_space_rom0 $0080, $0080 + $70


;***************
;* joypad read *
;***************

    joypad_hook $02f0
    savestates_marker --- Chalvo 55 Save Patch ---


;*******************
;* save/load state *
;*******************

    free_space_romx $1, $7A00, $7A00 + $600
