; md5 f9e94b9a134d900a3b971e206f4e826c

; ROM "Dragon Heart (U) [!].gb"
; builds "Dragon Heart (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* vblank *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
    joypad_vblank_hook $00dc, $20ef


;*******************
;* save/load state *
;*******************

    free_space_rom0 $3cd7, $3cd7 + $02a0
    savestates_payload_in_rom0
