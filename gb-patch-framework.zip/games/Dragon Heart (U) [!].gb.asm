; md5 f9e94b9a134d900a3b971e206f4e826c

; ROM "Dragon Heart (U) [!].gb"
; builds "savestates/Dragon Heart (U) [!] (savestates).gb"


;**********
;* vblank *
;**********

DEF vblank_handler EQU $00dc
DEF original_vblank_handler EQU $20ef
INCLUDE "src/features/savestates/vblank_handler.asm"


;*******************
;* save/load state *
;*******************

SECTION "save/load state", ROM0[$3cd7] ; length: $02a0
    DB "--- Save Patch ---"
    INCLUDE "src/features/savestates/joypad_read_and_check.asm"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
