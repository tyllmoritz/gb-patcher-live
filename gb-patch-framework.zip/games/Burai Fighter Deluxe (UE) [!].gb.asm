; md5 dd5aa6e85827a3ce6e4b7500e75a3262

; ROM "Burai Fighter Deluxe (UE) [!].gb"
; builds "Burai Fighter Deluxe (UE) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF current_rom_bank EQU $0151


; joypad
; Custom shape: the ROMX hook site calls a ROM0 stub (split across two
; disjoint free-space windows) that bank-switches to
; relocated_read_from_joypad, which lives in the save/load payload's own
; ROMX bank — see Burning Paper for the same general pattern (this one's
; stub is just split in two, unlike joypad_hook_banked_split which patches
; over existing game code rather than using free ROM0 space).
DEF joypad EQU $c0e3
DEF joypad_2 EQU $c0e4
DEF JOYPAD_HOOK_VARIANT EQU 1
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    free_space_rom0 $00e9, $00e9 + 18
    rom0_code
    INCLUDE "src/core/hooks/joypad/call_in_other_bank_part_1.asm"
    end_code

    free_space_rom0_b $0062, $0062 + 25
    rom0_code_b
    INCLUDE "src/core/hooks/joypad/call_in_other_bank_part_2.asm"
    ret
    end_code

    patch_rom $0001, $489F
    call invoke_relocated_read_from_joypad_in_other_bank
    nop
    end_patch


; save/load state
    free_space_romx $0004, $4000, $4000 + $02a0
    romx_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    end_code
