; md5 6e30394fd7ef4a4dc3fe1edd9fc69f72

; ROM "Donkey Kong Land 2 (UE) [S][!].gb"
; builds "Donkey Kong Land 2 (UE) [S][!] (savestates).gb" with _MBC5 _SAVESTATES


; config
DEF current_rom_bank EQU $4000
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT
; deliberately targets MBC5 (not the ROM's real original header type)
; — the save-state payload's bank placement, or a bootleg-flash-cart
; requirement, needs MBC5's addressing; CHANGE_CARTRIDGE_TYPE forces
; the header patch since the real original isn't already MBC5
IF DEF(_MBC5)
    DEF CHANGE_CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT
ENDC
DEF joypad EQU $dea1
DEF joypad_2 EQU $dea2

    joypad_hook_banked $00, $383a, $386d
; custom relocated_read_from_joypad body (standard read.asm + custom bit
; manipulation + standard check.asm) doesn't match the framework's generic
; relocated-read implementation, so its automatic placement is skipped.
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1


; save/load state
    free_space_romx $0020, $4001, $4001 + $02c5
    romx_code
relocated_read_from_joypad:
    INCLUDE "src/core/hooks/joypad/read.asm"

    ld a, [$dea1]
    cpl
    and c
    ld [$dea2], a
    ld a, c
    ld [$dea1], a
    ld a, $30
    ld [$ff00+$00], a

    push bc
    INCLUDE "src/core/hooks/joypad/check.asm"
    pop bc
    ret
    end_code

SECTION "new bank", ROMX[$4000], BANK[$0020] ; length: 1
    DB $20
ENDSECTION
