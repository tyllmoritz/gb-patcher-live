; md5 c27ebebee5a53fe6eb857747c0556111

; ROM "Flappy Special (J).gb"
; builds "savestates/Flappy Special (J) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $01de


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0062, $0062 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $3937


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $7CB3, $7CB3 + $0220
