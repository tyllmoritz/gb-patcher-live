; md5 7fe07271d04ed9e0bc0663dde55a2ae4

; ROM "Megaman II (U) [!].gb"
; builds "Megaman II (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8e


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $0061, $0061 + $40
    joypad_relocated_read_in_rom0_c

    joypad_hook $0395


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $3c94, $3c94 + $0220
    savestates_payload_in_rom0_b
