; md5 25dfaca5120462af05532aaf4756776a

; ROM "Flintstones, The - King Rock Treasure Island (U).gb"
; builds "Flintstones, The - King Rock Treasure Island (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ffa6
DEF joypad_2 EQU $ffa7
DEF current_rom_bank EQU $7fff


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $0380, $03b0


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0

SECTION "new bank", ROMX[$7FFF], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
