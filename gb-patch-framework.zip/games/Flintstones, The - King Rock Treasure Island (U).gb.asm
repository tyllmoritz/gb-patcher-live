; md5 25dfaca5120462af05532aaf4756776a

; ROM "Flintstones, The - King Rock Treasure Island (U).gb"
; builds "savestates/Flintstones, The - King Rock Treasure Island (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffa6
DEF joypad_2 EQU $ffa7
DEF current_rom_bank EQU $7fff


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $0380, $03b0


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0

SECTION "new bank", ROMX[$7FFF], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
