; md5 435b566a4b3745b0acc5a976bedd9245

; ROM "Chuck Rock (U) [!].gb"
; builds "Chuck Rock (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ffae
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $ffb1


;*************
;* reset ram *
;*************

    entry_point $019a
    free_space_rom0 $00d5, $00d5 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0095, $0095 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $08f8


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220
