; md5 0b5127a54cc8581acfabe0413378ca3d

; ROM "Sneaky Snakes (UE) [!].gb"
; builds "Sneaky Snakes (UE) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ffc4


;**********
;* joypad *
;**********

DEF joypad EQU $ff8f
DEF joypad_2 EQU $ff90

    joypad_hook_banked $00, $2ee2


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $7639, $7639 + $02a0
