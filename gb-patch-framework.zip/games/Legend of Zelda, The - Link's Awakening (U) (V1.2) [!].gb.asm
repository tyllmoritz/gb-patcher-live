; md5 69d643bf4e37b3c133518517338b6a1c

; ROM "Legend of Zelda, The - Link's Awakening (U) (V1.2) [!].gb"
; builds "Legend of Zelda, The - Link's Awakening (U) (V1.2) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $dbaf
DEF SRAM_SIZE EQU CART_SRAM_8KB
;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00d3, $00d3 + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $ffcb
DEF joypad_2 EQU $ffcc
DEF swap_joypad EQU 1

    free_space_rom0_b $0092, $0092 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $2834


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $7D04, $7D04 + $0245
