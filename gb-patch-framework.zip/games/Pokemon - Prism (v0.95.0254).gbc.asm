; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; Pokemon Prism v0.95.0254 — ROM hack
;
; ROM "Pokemon - Prism (v0.95.0254).gbc"
; md5 7777fe98c1985ed73d024e2518a3a83b
;
; builds "Pokemon - Prism (v0.95.0254) (batteryless).gbc" with _BATTERYLESS
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC3_RAM_BAT_RTC
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
;
; ------------------------------------------------------------------------------

; game properties
; original header: CART_COMPATIBLE_GBC — save/load code doesn't need CGB-exclusive hardware here, so GB_COMPATIBILITY is left at its
; default (CART_COMPATIBLE_DMG) and the header is untouched
DEF SRAM_SIZE EQU CART_SRAM_32KB
DEF current_rom_bank EQU $ff9d         ; hROMBank
DEF flash_data_bank EQU $84             ; past the 2MB ROM (expanded at link)

; free space in the original ROM/RAM
    free_space_rom0 $3fa0, $4000        ; zero padding at the end of bank 0 (xxd-verified)
    free_space_romx $80, $4000, $8000   ; first bank past the 2MB ROM (expanded at link)
; WRAM window from the pre-framework port (found with a debugger there);
; sized to the feature's current footprint — the build asserts on overflow
    free_space_wram $d997, $d997 + $ab, $2

; the entry at $0100 is `ldh [$ffe6],a / jr` to $016c — real code, not the
; nop+jp that entry_point can overwrite. custom_boot suppresses the
; feature's own boot registration; the patch below replaces the 4-byte
; entry with `jp prism_boot` (leaving the jr operand at $0103 as a dead
; byte) and replays the displaced instruction itself.
DEF custom_boot EQU 1
    patch_rom $00, $0100
        jp prism_boot
    end_patch
    rom0_code
prism_boot:
    call batteryless_boot               ; preserves all registers (incl. a,
                                        ; still holding the CGB revision)
    ldh [$ffe6], a                      ; replayed original entry instruction
    jp $016c                            ; the original jr's target
    end_code

; the save site is a plain `call CloseSRAM`-style call at $05:$4d71
    save_hook $05, $4d71, $4df3
