; md5 982ed5d2b12a0377eb14bcdc4123744e

; ROM "Tetris (W) (V1.1) [!].gb"
; builds "Tetris (W) (V1.1) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff80
DEF joypad_2 EQU $ff81
DEF current_rom_bank EQU $0087   ; value at this address is EQU $01
DEF current_nr34_value EQU $dfba


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $29a6


;*******************
;* save/load state *
;*******************

    free_space_romx $02, $4000, $4000 + $4000
    savestates_marker --- Tetris Save Patch ---
