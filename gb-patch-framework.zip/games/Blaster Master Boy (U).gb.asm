; md5 c4868bf46a993b4c33a9a8af5341282a

; ROM "Blaster Master Boy (U).gb"
; builds "Blaster Master Boy (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF joypad EQU $ffe1
DEF joypad_2 EQU $ffe2
DEF current_rom_bank EQU $c102


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $03be, $03ee


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
