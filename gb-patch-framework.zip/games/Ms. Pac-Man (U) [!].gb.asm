; md5 ffa8642a18781fbe79df436a761a9775

; ROM "Ms. Pac-Man (U) [!].gb"
; builds "savestates/Ms. Pac-Man (U) [!] (savestates).gb"


; config
DEF current_rom_bank EQU $4000


; reset ram
    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c

SECTION "relocated read from joypad", ROM0[$0062] ; length: $40
    INCLUDE "src/features/savestates/relocated_read_from_joypad.asm"
ENDSECTION

SECTION "joypad read", ROM0[$03ea] ; length: 5
    call relocated_read_from_joypad
    nop
    nop
ENDSECTION


; save/load state
SECTION "save/load state", ROMX[$7070], BANK[$0001] ; length: $0220
    DB "--- Save Patch ---"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
