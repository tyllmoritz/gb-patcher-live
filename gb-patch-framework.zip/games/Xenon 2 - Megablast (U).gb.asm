; md5 02d7df9a5ac5d859672b56be46343be1

; ROM "Xenon 2 - Megablast (U).gb"
; builds "Xenon 2 - Megablast (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c008
DEF cpl_joypad EQU 1
DEF current_rom_bank EQU $ff00+$fb


;***************
;* joypad read *
;***************

; custom tail doesn't fit joypad_hook_banked's fixed ret/jp tail, so the hook
; site stays hand-placed; JOYPAD_HOOK_VARIANT is declared manually to match
; what joypad_hook_banked would have set.
DEF JOYPAD_HOOK_VARIANT EQU 1
    free_space_rom0 $0ee9, $0ee9 + $29
    rom0_code
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    ld a,[$c008]
    jp $0f12
    end_code


;*******************
;* save/load state *
;*******************

    savestates_marker --- Xenon 2 Save Patch ---
    free_space_romx $08, $4000, $4000 + $4000
