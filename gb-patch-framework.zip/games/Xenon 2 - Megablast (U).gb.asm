; md5 02d7df9a5ac5d859672b56be46343be1

; ROM "Xenon 2 - Megablast (U).gb"
; builds "savestates/Xenon 2 - Megablast (U) (savestates).gb"


;**********
;* config *
;**********

DEF joypad EQU $c008
DEF cpl_joypad EQU 1
DEF current_rom_bank EQU $ff00+$fb


;***************
;* joypad read *
;***************

SECTION "joypad read", ROM0[$0ee9] ; length: $29
    INCLUDE "src/features/savestates/call_relocated_read_from_joypad_in_other_bank.asm"
    ld a,[$c008]
    jp $0f12
ENDSECTION


;*******************
;* save/load state *
;*******************

SECTION "save/load state", ROMX[$4000], BANK[$08] ; length: $4000
    DB "--- Xenon 2 Save Patch ---"
    INCLUDE "src/features/savestates/joypad_read_and_check.asm"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
