; md5 f70c60ca87714fa9d81be60c9ac93de0

; ROM "Balloon Kid (W) [!].gb"
; builds "savestates/Balloon Kid (W) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffa0
DEF current_rom_bank EQU $ffca


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $0c41


;*******************
;* save/load state *
;*******************

    free_space_romx $0007, $7D00, $7D00 + $220
