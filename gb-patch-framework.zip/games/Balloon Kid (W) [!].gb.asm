; md5 f70c60ca87714fa9d81be60c9ac93de0

; ROM "Balloon Kid (W) [!].gb"
; builds "Balloon Kid (W) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ffa0
DEF current_rom_bank EQU $ffca


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $0c41


;*******************
;* save/load state *
;*******************

    free_space_romx $0007, $7D00, $7D00 + $220
