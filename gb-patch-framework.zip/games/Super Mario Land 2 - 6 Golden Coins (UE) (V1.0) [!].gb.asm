; md5 a8413347d5df8c9d14f97f0330d67bce

; ROM "Super Mario Land 2 - 6 Golden Coins (UE) (V1.0) [!].gb"
; builds "Super Mario Land 2 - 6 Golden Coins (UE) (V1.0) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $a24e
DEF SRAM_SIZE EQU CART_SRAM_8KB
; joypad
DEF joypad EQU $ff80
DEF joypad_2 EQU $ff81

    joypad_hook_banked $00, $1fd7


; save/load state
    free_space_romx $000d, $5CDB, $5CDB + $02c5
