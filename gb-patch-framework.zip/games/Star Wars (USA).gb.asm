; md5 63098fde8f2dcb977c9a8f0389e0d033

; ROM "Star Wars (USA).gb"
; builds "Star Wars (USA) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff93
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $ff8c


;***************
;* joypad read *
;***************

; custom tail (joypad state copied into D register) doesn't fit
; joypad_hook_banked's fixed ret/jp tail, so the hook site stays hand-placed;
; JOYPAD_HOOK_VARIANT is declared manually to match what joypad_hook_banked
; would have set.
DEF JOYPAD_HOOK_VARIANT EQU 1
    free_space_rom0 $1e66, $1e66 + $2a
    rom0_code
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"

    ; Replicate register state of original read function
    ld a,[joypad]
    ld d, a

    ret
    end_code


;*******************
;* save/load state *
;*******************

    savestates_marker --- XXXXX Save Patch ---
    free_space_romx $02, $7D40, $7D40 + $2c0
