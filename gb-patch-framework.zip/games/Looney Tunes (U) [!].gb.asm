; md5 6e9dd3c1fb169da79292a1962e95a884

; ROM "Looney Tunes (U) [!].gb"
; builds "savestates/Looney Tunes (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $c4f7


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $ffe1
DEF joypad_2 EQU $ffe2

    free_space_rom0_b $0062, $0062 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $0cb0


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $7C1B, $7C1B + $0220
