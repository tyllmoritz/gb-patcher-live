; md5 421a923ba483f65a967b8455500b8880

; ROM "Robocop (U) (V1.0) [M][!].gb"
; builds "Robocop (U) (V1.0) [M][!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $c068


; reset ram
    entry_point $01a3
    free_space_rom0 $0062, $0062 + $F
    on_boot_inline reset_ram



; joypad
; Custom shape: two independent joypad-read hooks (one for each of two
; game code paths), each with its own hand-written relocated_read/check
; wrapper, both calling the same shared joypad_check. Together with
; reset_ram and the save/load payload, that's four disjoint ROM0 windows —
; beyond the region API's two/three-region limit — so both relocated-read
; routines are placed via patch_rom directly; JOYPAD_CUSTOM_RELOCATED_READ
; skips the framework's automatic relocated-read placement entirely.
DEF joypad EQU $ffb0
DEF swap_joypad EQU 1
DEF JOYPAD_HOOK_VARIANT EQU 0
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    patch_rom $00, $3f00
relocated_read_from_joypad:
    ld a, $ff
    ld [$ff00+$00], a
    ld [$c08e], a

    ld a, b
    ld [$ff00+$b0], a
    call joypad_check
    ld a, [$ff00+$b0]
    ld b, a

    ret

    INCLUDE "src/core/hooks/joypad/check.asm"
    ret
    end_patch

    patch_rom $00, $2974
    jp relocated_read_from_joypad
    end_patch

    patch_rom $00, $3f80
relocated_read_from_joypad2:
    ld b, a
    ld a,$30
    ld [$ff00+$00],a
    ld a, b

    ld [$ff00+$8a], a
    ld [$ff00+$b0], a
    call joypad_check
    ld a, [$ff00+$b0]
    ld [$ff00+$8a], a

    ret
    end_patch

    patch_rom $0004, $4D95
    jp relocated_read_from_joypad2
    end_patch


; save/load state
    free_space_rom0_b $3458, $3458 + $0220
    savestates_payload_in_rom0_b
