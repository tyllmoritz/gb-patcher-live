; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; ROM "Pokemon - Edicion Cristal (Spain).gbc"
; SHA1 889a06fc0bb863666865aa69def0adf97945ac2a
;
; builds "nortc/Pokemon - Edicion Cristal (Spain) (nortc).gbc" with _NORTC
; builds "batteryless/Pokemon - Edicion Cristal (Spain) (nortc) (batteryless).gbc" with _BATTERYLESS _NORTC
;
; ------------------------------------------------------------------------------

; game properties (same disassembly lineage as Crystal Version USA/Europe)
DEF sram_size_32kb EQU 1
DEF current_rom_bank EQU $ff9d
DEF flash_data_bank EQU $80

; free space in the original ROM/RAM
; (WRAM: sprite animation buffer, only used within a frame; stack is in WRAM0)
    free_space_rom0 $0070, $0100
    free_space_romx $01, $7550, $8000
    free_space_wram $d462, $d562, $5

; the game's `jp` at $0101 goes to $016e
    entry_point $016e

; both call sites of _SaveGameData ($5:$4c10)
    save_hook $05, $4b85, $4c10
    save_hook $05, $4be6, $4c10

IF DEF(_NORTC)
; offsets for the Pokegear RTC changer (Crystal lineage)
DEF FarCall EQU $8
DEF hJoypadDown EQU $ffa4
DEF wStartDay_ EQU $d4b6
DEF wScriptFlags EQU $d434
DEF wSpriteAnimAddrBackup EQU $c3b8
DEF wSpriteAnimAddrBackup_Value EQU $c3
DEF wJumptableIndex EQU $cf63
DEF UpdateTime_FixTime_ EQU $05ad
DEF FixTime_ EQU $061d
DEF PokegearClock_Joypad_buttoncheck_ EQU $4f67
DEF PokegearClock_Joypad_BANK EQU $24
ENDC
