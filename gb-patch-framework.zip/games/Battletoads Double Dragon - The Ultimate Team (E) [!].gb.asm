; md5 ec8dfc2600756d4ff306eedcd03defd2

; ROM "Battletoads Double Dragon - The Ultimate Team (E) [!].gb"
; builds "Battletoads Double Dragon - The Ultimate Team (E) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF joypad EQU $ca03
DEF joypad_2 EQU $ca01
DEF current_rom_bank EQU $4000


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $17f2, $1825


;*******************
;* save/load state *
;*******************

    free_space_romx $0009, $7965, $7965 + $02a0
