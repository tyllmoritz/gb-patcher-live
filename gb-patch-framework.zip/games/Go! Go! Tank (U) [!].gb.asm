; md5 23824d72928a05e9fcf052d42f3c91c6

; ROM "Go! Go! Tank (U) [!].gb"
; builds "savestates/Go! Go! Tank (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $ff8c


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0085, $0085 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    savestates_vblank_hook $0062, $01d8


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7CAF, $7CAF + $02a0
