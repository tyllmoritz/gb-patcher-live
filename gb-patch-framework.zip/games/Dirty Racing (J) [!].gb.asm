; md5 b2023017774d88ffe82a7d1b0af52c12

; ROM "Dirty Racing (J) [!].gb"
; builds "Dirty Racing (J) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c0a8
DEF cpl_joypad EQU 1


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a5, $00a5 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $0064, $0064 + $40
    joypad_relocated_read_in_rom0_c

    joypad_hook $2ddf


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $3643, $3643 + $0220
    savestates_payload_in_rom0_b
