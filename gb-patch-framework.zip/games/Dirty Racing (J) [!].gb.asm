; md5 b2023017774d88ffe82a7d1b0af52c12

; ROM "Dirty Racing (J) [!].gb"
; builds "savestates/Dirty Racing (J) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c0a8
DEF cpl_joypad EQU 1


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a5, $00a5 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $0064, $0064 + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $2ddf


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $3643, $3643 + $0220
    savestates_payload_in_rom0_b
