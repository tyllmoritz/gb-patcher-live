; md5 f005cbcb60f4d9f3e4f6190e809cff1d

; ROM "Metroid II - Return of Samus (W) [!] EJRTQ Colorization.gbc"
; builds "savestates/Metroid II - Return of Samus (W) [!] EJRTQ Colorization (savestates).gbc" with _SAVESTATES
; builds "batteryless/Metroid II - Return of Samus (W) [!] EJRTQ Colorization (batteryless).gbc" with _BATTERYLESS


; config
DEF is_cgb EQU 1
DEF current_rom_bank EQU $d04e         ; WRAMX bank 1 (same byte the game
                                       ; caches its ROM bank in)
DEF game_uses_save_ram EQU 1
DEF uses_mbc5 EQU 1


; mbc1->mbc5 patch — needed by both builds (flash carts and bootleg carts
; are MBC5): the game's MBC1-style bank-bit-5 writes are redirected to
; these helpers. The call sites are shared; the helper routines live at
; the fixed legacy address in the savestates build (byte-identical to the
; original port) and inside the free-space fragment in the batteryless
; build (which needs the $00c0 area for its own code).
SECTION "set bit 5", ROM0[$3f83] ; length: 5
    call set_rom_bank_bit_5
    nop
    nop
ENDSECTION

SECTION "reset bit 5", ROM0[$3f9a] ; length: 4
    call reset_rom_bank_bit_5
    nop
ENDSECTION


IF DEF(_SAVESTATES)

; joypad
DEF joypad EQU $ff80
DEF joypad_2 EQU $ff81

    free_space_rom0 $007c, $007c + $40

    savestates_joypad_hook $22b7


; save/load state
    free_space_romx $0001, $7B98, $7B98 + $0295


SECTION "mbc1 to mbc5 patch", ROM0[$00c0] ; length: 24
set_rom_bank_bit_5:
    ld a, [current_rom_bank]
    or $20
    ; ld [current_rom_bank], a
    ld [$2100], a
    ret

reset_rom_bank_bit_5:
    ld a, [current_rom_bank]
    ld [$2100], a
    ret
ENDSECTION

ENDC


IF DEF(_BATTERYLESS)

; game properties
DEF sram_size_32kb EQU 0                ; 8kb SRAM
DEF flash_data_bank EQU $14             ; banks $11-$1f are all zero padding
                                        ; (xxd-verified); must start a 64kb
                                        ; erase block (multiple of 4 banks).
                                        ; The previous value $16 worked only
                                        ; by luck: erasing wipes the whole
                                        ; $14-$17 sector regardless

; free space in the original ROM/RAM: the end of bank 0 is full of game
; code, so everything must fit between the interrupt vectors and the
; header ($007c-$0100 is zero padding, xxd-verified)
    free_space_rom0 $007c, $0100
    free_space_romx $11, $4000, $8000   ; whole bank is zero padding (xxd-verified)
; WRAM window from the pre-framework port (found with a debugger there);
; sized to the feature's current footprint — the build asserts on overflow
    free_space_wram $dea0, $dea0 + $ab, $1

    entry_point $0150

; the save site is the game's whole 5-byte routine tail
; `ld a,$4 / ldh [$ff9b],a / ret` — replaced with a call to a stub that
; replays it around the on_save hooks, keeping the site's own ret
    save_hook_manual
    patch_rom $01, $7b82
        call metroid_save_stub
        ret
        nop
    end_patch

    rom0_code
metroid_save_stub:
    ld a, $4                            ; original code: ld a,$4
    ldh [$ff9b], a                      ; original code: ldh [$ff9b],a
    jp save_trampoline_bare

set_rom_bank_bit_5:
    ld a, [current_rom_bank]
    or $20
    ld [$2100], a
    ret

reset_rom_bank_bit_5:
    ld a, [current_rom_bank]
    ld [$2100], a
    ret
    end_code

ENDC
