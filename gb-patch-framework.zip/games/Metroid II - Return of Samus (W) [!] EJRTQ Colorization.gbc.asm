; md5 f005cbcb60f4d9f3e4f6190e809cff1d

; ROM "Metroid II - Return of Samus (W) [!] EJRTQ Colorization.gbc"
; builds "Metroid II - Return of Samus (W) [!] EJRTQ Colorization (savestates).gbc" with _MBC5 _SAVESTATES
; builds "Metroid II - Return of Samus (W) [!] EJRTQ Colorization (batteryless).gbc" with _MBC5 _BATTERYLESS


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $d04e         ; WRAMX bank 1 (same byte the game
                                       ; caches its ROM bank in)
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT
; deliberately targets MBC5 (not the ROM's real original header type)
; — the save-state payload's bank placement, or a bootleg-flash-cart
; requirement, needs MBC5's addressing; CHANGE_CARTRIDGE_TYPE forces
; the header patch since the real original isn't already MBC5
IF DEF(_MBC5)
    DEF CHANGE_CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT
ENDC
SECTION "set bit 5", ROM0[$3f83] ; length: 5
    call set_rom_bank_bit_5
    nop
    nop
ENDSECTION

SECTION "reset bit 5", ROM0[$3f9a] ; length: 4
    call reset_rom_bank_bit_5
    nop
ENDSECTION


IF DEF(_SAVESTATES)

; joypad
DEF joypad EQU $ff80
DEF joypad_2 EQU $ff81

    free_space_rom0 $007c, $007c + $40

    joypad_hook $22b7


; save/load state
    free_space_romx $0001, $7B98, $7B98 + $0295


SECTION "mbc1 to mbc5 patch", ROM0[$00c0] ; length: 24
set_rom_bank_bit_5:
    ld a, [current_rom_bank]
    or $20
    ; ld [current_rom_bank], a
    ld [$2100], a
    ret

reset_rom_bank_bit_5:
    ld a, [current_rom_bank]
    ld [$2100], a
    ret
ENDSECTION

ENDC


IF DEF(_BATTERYLESS)

; game properties
DEF flash_data_bank EQU $14             ; banks $11-$1f are all zero padding
                                        ; (xxd-verified); must start a 64kb
                                        ; erase block (multiple of 4 banks).
                                        ; The previous value $16 worked only
                                        ; by luck: erasing wipes the whole
                                        ; $14-$17 sector regardless

; free space in the original ROM/RAM: the end of bank 0 is full of game
; code, so everything must fit between the interrupt vectors and the
; header ($007c-$0100 is zero padding, xxd-verified)
    free_space_rom0 $007c, $0100
    free_space_romx $11, $4000, $8000   ; whole bank is zero padding (xxd-verified)
; WRAM window from the pre-framework port (found with a debugger there);
; sized to the feature's current footprint — the build asserts on overflow
    free_space_wram $dea0, $dea0 + $ab, $1

    entry_point $0150

; the save site is the game's whole 5-byte routine tail
; `ld a,$4 / ldh [$ff9b],a / ret` — replaced with a call to a stub that
; replays it around the on_save hooks, keeping the site's own ret
    save_hook_manual
    patch_rom $01, $7b82
        call metroid_save_stub
        ret
        nop
    end_patch

    rom0_code
metroid_save_stub:
    ld a, $4                            ; original code: ld a,$4
    ldh [$ff9b], a                      ; original code: ldh [$ff9b],a
    jp save_trampoline_bare

set_rom_bank_bit_5:
    ld a, [current_rom_bank]
    or $20
    ld [$2100], a
    ret

reset_rom_bank_bit_5:
    ld a, [current_rom_bank]
    ld [$2100], a
    ret
    end_code

ENDC
