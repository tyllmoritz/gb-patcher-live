; md5 9d94d01d3133165d4469bb27d58f0f6c

; ROM "Bill & Ted's Excellent Gameboy Adventure (UE) [!].gb"
; builds "savestates/Bill & Ted's Excellent Gameboy Adventure (UE) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8e
DEF joypad_2 EQU $ff8f


;*************
;* reset ram *
;*************

    entry_point $0070
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0028, $0028 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $02aa, $02db


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $3ce1, $3ce1 + $02a0
    savestates_payload_in_rom0_b
