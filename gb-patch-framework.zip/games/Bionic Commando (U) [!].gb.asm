; md5 f89a33de3fa660a13ec29bb323efffa9

; ROM "Bionic Commando (U) [!].gb"
; builds "Bionic Commando (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c0c0
DEF joypad_2 EQU $c0c1
DEF current_rom_bank EQU $c0d3
DEF current_nr34_value EQU $c47a
DEF restore_sound EQU 1


;*************************
;* relocated joypad read *
;*************************

DEF interrupts_already_disabled EQU 1
    joypad_hook $0aef
    free_space_rom0 $3f00, $3f00 + $ff


;*******************
;* save/load state *
;*******************

    savestates_marker --- Bionic Commando Save Patch ---
    free_space_romx $0f, $7D00, $7D00 + $300
