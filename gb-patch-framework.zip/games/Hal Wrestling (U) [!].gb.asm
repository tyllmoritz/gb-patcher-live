; md5 7ac8443eefc33432b989f00cb984b9a1

; ROM "Hal Wrestling (U) [!].gb"
; builds "Hal Wrestling (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8d
DEF joypad_2 EQU $ff8e
DEF current_rom_bank EQU $ff97


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00d2, $00d2 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0091, $0091 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $1662


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $68FB, $68FB + $0220
