; md5 7ac8443eefc33432b989f00cb984b9a1

; ROM "Hal Wrestling (U) [!].gb"
; builds "savestates/Hal Wrestling (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8d
DEF joypad_2 EQU $ff8e
DEF current_rom_bank EQU $ff97


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00d2, $00d2 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0091, $0091 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $1662


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $68FB, $68FB + $0220
