; md5 ccd0cf7cc240714a9694e1fe296afb7c

; ROM "Noobow (J).gb"
; builds "Noobow (J) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8e
DEF current_rom_bank EQU $ffaa


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $0061, $0061 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $0475, $049d


;*******************
;* save/load state *
;*******************

    free_space_romx $0010, $4000, $4000 + $02a0
