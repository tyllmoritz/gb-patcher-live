; md5 4a967a8f1dd6f627e8b72950739c26d4

; ROM "Amazing Spider-Man, The (UE) [!].gb"
; builds "savestates/Amazing Spider-Man, The (UE) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $c361


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $008b, $008b + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $004b, $004b + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $046c


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $0220
