; md5 f6b898bfaa367ac1b0782a363cd098c7

; ROM "Pac-Man (U) (Namco Hometek) [!].gb"
; builds "savestates/Pac-Man (U) (Namco Hometek) [!] (savestates).gb"


; config
DEF current_rom_bank EQU $d600


; reset ram
    entry_point $0867
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00d4, $00d4 + $F
    on_boot_inline reset_ram



; vblank
DEF vblank_handler EQU $0004
DEF original_vblank_handler EQU $03bb
INCLUDE "src/features/savestates/vblank_handler.asm"


; save/load state
SECTION "save/load state", ROM0[$3381] ; length: $02a0
    DB "--- Save Patch ---"
    INCLUDE "src/features/savestates/joypad_read_and_check.asm"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
