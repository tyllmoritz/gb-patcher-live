; md5 028c4262dbb49f4fc462a6eb3e514d72

; ROM "Shantae (U) [C][!].gbc"
; builds "Shantae (U) [C][!] (savestates).gbc" with _SAVESTATES


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $ff91
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT


;**********
;* vblank *
;**********

    joypad_vblank_hook $0004, $0884


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7841, $7841 + $0305
