; md5 028c4262dbb49f4fc462a6eb3e514d72

; ROM "Shantae (U) [C][!].gbc"
; builds "savestates/Shantae (U) [C][!] (savestates).gbc" with _SAVESTATES


;**********
;* config *
;**********

DEF is_cgb EQU 1
DEF current_rom_bank EQU $ff91
DEF game_uses_save_ram EQU 1
DEF uses_mbc5 EQU 1


;**********
;* vblank *
;**********

    savestates_vblank_hook $0004, $0884


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7841, $7841 + $0305
