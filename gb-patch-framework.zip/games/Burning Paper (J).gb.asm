; md5 cb0a5d103c01d1d82d324602a45dd21b

; ROM "Burning Paper (J).gb"
; builds "Burning Paper (J) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ffb6
DEF joypad_2 EQU $ffb8
DEF current_rom_bank EQU $ffe3
DEF restore_wave_ram EQU 1


;*************************
;* relocated joypad read *
;*************************

; Custom shape: the hook site itself lives in ROMX bank 1 (not ROM0), so it
; can't directly call relocated_read_from_joypad if that's in a different
; bank without switching first — hence this ROM0 stub (always mapped,
; callable from any bank) that does the bank-switch via
; call_in_other_bank.asm. relocated_read_from_joypad itself lives in the
; save/load payload's own ROMX bank (below), not the usual ROM0 free space,
; so this doesn't fit joypad_hook_banked's assumed shape; JOYPAD_HOOK_VARIANT
; is declared manually and JOYPAD_CUSTOM_RELOCATED_READ skips the framework's
; automatic relocated-read placement.
DEF JOYPAD_HOOK_VARIANT EQU 1
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    free_space_rom0 $0080, $0080 + $70
    rom0_code
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    ret
    end_code


;***************
;* joypad read *
;***************

    patch_rom $01, $5D88
    call invoke_relocated_read_from_joypad_in_other_bank
    nop
    end_patch


;*******************
;* save/load state *
;*******************

    savestates_marker --- Burning Paper Save Patch ---
    free_space_romx $7, $7000, $7000 + $1000
    romx_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    end_code
