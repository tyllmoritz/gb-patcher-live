; md5 e10f788da29e18934c3e9161b25b96c7

; ROM "Gradius - The Interstellar Assault (U).gb"
; builds "savestates/Gradius - The Interstellar Assault (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c78e
DEF joypad_2 EQU $c78f
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $c7a4


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00ce, $00ce + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $0ca8


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7A20, $7A20 + $02a0
