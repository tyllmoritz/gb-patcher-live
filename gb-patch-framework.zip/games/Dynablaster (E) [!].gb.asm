; md5 2eb9a6891fc79cd878d8bc12d04a0790

; ROM "Dynablaster (E) [!].gb"
; builds "Dynablaster (E) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff00+$8a
DEF joypad_2 EQU $ff00+$8b
DEF current_rom_bank EQU $ff00+$c6
DEF current_nr34_value EQU $d82a


;*************************
;* relocated joypad read *
;*************************

DEF preserve_registers EQU 1
    joypad_hook $04d3
    free_space_rom0 $0080, $0080 + $70


;*******************
;* save/load state *
;*******************

    savestates_marker --- Dynablaster Save Patch ---
    free_space_romx $01, $5000, $5000 + $500
