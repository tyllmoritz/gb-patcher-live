; md5 24a6b4457a511cc667e9ac25417401ab

; ROM "Kid Dracula (U) [!].gb"
; builds "savestates/Kid Dracula (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c9c6
DEF joypad_2 EQU $c9c7
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $7fff
DEF current_nr34_value EQU $c7ed


;*************************
;* relocated joypad read *
;*************************

    free_space_rom0 $3f00, $3f00 + $d0


;***************
;* joypad read *
;***************

    savestates_joypad_hook $0537
    savestates_marker --- Kid Dracula Save Patch ---


;*******************
;* save/load state *
;*******************

    free_space_romx $03, $7D00, $7D00 + $2fe
