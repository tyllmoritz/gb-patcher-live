; md5 3f55fde8e05a4d372f7f30a1f7398fb5

; ROM "Hunchback of Notre Dame, The - Topsy Turvy Games (U) [S][!].gb"
; builds "savestates/Hunchback of Notre Dame, The - Topsy Turvy Games (U) [S][!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c300
DEF joypad_2 EQU $c301
DEF swap_joypad EQU 1


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a5, $00a5 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $0064, $0064 + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $12a7


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $3d0b, $3d0b + $0220
    savestates_payload_in_rom0_b
