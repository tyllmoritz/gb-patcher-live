; md5 4d606ab4ffd5c3d3ecf914a6af1c1f90

; ROM "Felix the Cat (U).gb"
; builds "savestates/Felix the Cat (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c16c
DEF joypad_2 EQU $c16d


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $0061, $0061 + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $0979


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $0153, $0153 + $0220
    savestates_payload_in_rom0_b
