; md5 1d2c316f9f32727261328c7a49b22e2c

; ROM "Super Mario Land 2 - 6 Golden Coins (UE) (V1.1) [!].gb"
; builds "Super Mario Land 2 - 6 Golden Coins (UE) (V1.1) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $a24e
DEF SRAM_SIZE EQU CART_SRAM_8KB
; reset ram
    entry_point $0150
    free_space_rom0 $005c, $005c + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $ff80
DEF joypad_2 EQU $ff81

    free_space_rom0_b $00bd, $00bd + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $2007


; save/load state
    free_space_romx $000d, $5CDB, $5CDB + $0245
