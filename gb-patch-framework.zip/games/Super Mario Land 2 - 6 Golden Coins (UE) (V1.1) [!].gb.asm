; md5 1d2c316f9f32727261328c7a49b22e2c

; ROM "Super Mario Land 2 - 6 Golden Coins (UE) (V1.1) [!].gb"
; builds "savestates/Super Mario Land 2 - 6 Golden Coins (UE) (V1.1) [!] (savestates).gb" with _SAVESTATES


; config
DEF current_rom_bank EQU $a24e
DEF game_uses_save_ram EQU 1


; reset ram
    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $005c, $005c + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $ff80
DEF joypad_2 EQU $ff81

    free_space_rom0_b $00bd, $00bd + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $2007


; save/load state
    free_space_romx $000d, $5CDB, $5CDB + $0245
