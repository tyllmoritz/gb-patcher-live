; md5 e24141ed6fc94b149bbf43b4bd9658e8

; ROM "Atlantis - The Lost Empire (E) (M3) (Eng-Spa-Ita) [C][!].gbc"
; builds "Atlantis - The Lost Empire (E) (M3) (Eng-Spa-Ita) [C][!] (savestates).gbc" with _SAVESTATES
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $7fff
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5


; joypad
DEF joypad EQU $c10a
DEF joypad_2 EQU $c10b

    joypad_hook_banked $00, $00b8


; save/load state
    free_space_rom0_b $3907, $3907 + $02f0
    savestates_payload_in_rom0_b
