; md5 e24141ed6fc94b149bbf43b4bd9658e8

; ROM "Atlantis - The Lost Empire (E) (M3) (Eng-Spa-Ita) [C][!].gbc"
; builds "savestates/Atlantis - The Lost Empire (E) (M3) (Eng-Spa-Ita) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF is_cgb EQU 1
DEF current_rom_bank EQU $7fff
DEF uses_mbc5 EQU 1


; joypad
DEF joypad EQU $c10a
DEF joypad_2 EQU $c10b

    savestates_joypad_hook_banked $00, $00b8


; save/load state
    free_space_rom0_b $3907, $3907 + $02f0
    savestates_payload_in_rom0_b
