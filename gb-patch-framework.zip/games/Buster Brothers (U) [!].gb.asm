; md5 d97f34c22a179fb4094acbc05616f565

; ROM "Buster Brothers (U) [!].gb"
; builds "Buster Brothers (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8e
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $ff8d


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $2d79, $2da1


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
