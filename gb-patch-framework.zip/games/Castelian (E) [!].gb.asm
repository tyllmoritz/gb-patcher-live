; md5 3502be0da5d444ec144aae9ce1409e0d

; ROM "Castelian (E) [!].gb"
; builds "Castelian (E) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c458
DEF current_rom_bank EQU $018d


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

; hook site is only 3 bytes (no trailing nop), which doesn't match
; joypad_hook's fixed 4-byte "call relocated_read_from_joypad / nop"
; emission, so it's patched manually; JOYPAD_HOOK_VARIANT is declared
; manually to match what joypad_hook would have set. relocated_read.asm
; goes in the second ROM0 region since the first is already reset_ram's.
DEF JOYPAD_HOOK_VARIANT EQU 0
    joypad_relocated_read_in_rom0_b
    free_space_rom0_b $0062, $0062 + $40

    patch_rom $00, $07b3
    call relocated_read_from_joypad
    end_patch


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $4000, $4000 + $0220
