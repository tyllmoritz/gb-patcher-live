; md5 3502be0da5d444ec144aae9ce1409e0d

; ROM "Castelian (E) [!].gb"
; builds "savestates/Castelian (E) [!] (savestates).gb"


;**********
;* config *
;**********

DEF joypad EQU $c458
DEF current_rom_bank EQU $018d


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

SECTION "relocated read from joypad", ROM0[$0062] ; length: $40
    INCLUDE "src/features/savestates/relocated_read_from_joypad.asm"
ENDSECTION

SECTION "joypad read", ROM0[$07b3] ; length: 3
    call relocated_read_from_joypad
ENDSECTION


;*******************
;* save/load state *
;*******************

SECTION "save/load state", ROMX[$4000], BANK[$0002] ; length: $0220
    DB "--- Save Patch ---"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
