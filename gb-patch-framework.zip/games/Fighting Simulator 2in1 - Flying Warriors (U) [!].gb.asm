; md5 42b8ce5b0d54f4565ba99e02f09fe115

; ROM "Fighting Simulator 2in1 - Flying Warriors (U) [!].gb"
; builds "savestates/Fighting Simulator 2in1 - Flying Warriors (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffa7


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00dc, $00dc + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $009b, $009b + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $03d4


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $1d4b, $1d4b + $0220
    savestates_payload_in_rom0_b
