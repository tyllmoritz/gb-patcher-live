; md5 0c7beead4f65e97a23b718ce20a1bf55

; ROM "Brain Drain (U) [S][!].gb"
; builds "Brain Drain (U) [S][!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

; MANUAL EDIT - joypad detected incorrectly
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b

DEF current_rom_bank EQU $ff9f


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

; hook site is only 3 bytes (no trailing nop), which doesn't match
; joypad_hook's fixed 4-byte "call relocated_read_from_joypad / nop"
; emission, so it's patched manually; JOYPAD_HOOK_VARIANT is declared
; manually to match what joypad_hook would have set. relocated_read.asm
; goes in the second ROM0 region since the first is already reset_ram's.
DEF JOYPAD_HOOK_VARIANT EQU 0
    joypad_relocated_read_in_rom0_b
    free_space_rom0_b $0061, $0061 + $40

    patch_rom $00, $039d
    call relocated_read_from_joypad
    end_patch


;*******************
;* save/load state *
;*******************

    free_space_romx $0007, $5A58, $5A58 + $0220
