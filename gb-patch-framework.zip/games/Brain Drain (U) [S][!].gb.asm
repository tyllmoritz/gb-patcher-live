; md5 0c7beead4f65e97a23b718ce20a1bf55

; ROM "Brain Drain (U) [S][!].gb"
; builds "savestates/Brain Drain (U) [S][!] (savestates).gb"


;**********
;* config *
;**********

; MANUAL EDIT - joypad detected incorrectly
DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b

DEF current_rom_bank EQU $ff9f


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

SECTION "relocated read from joypad", ROM0[$0061] ; length: $40
    INCLUDE "src/features/savestates/relocated_read_from_joypad.asm"
ENDSECTION

; MANUAL EDIT - wrong value for .ORG directive
SECTION "joypad read", ROM0[$039d] ; length: 3
    call relocated_read_from_joypad
ENDSECTION


;*******************
;* save/load state *
;*******************

SECTION "save/load state", ROMX[$5A58], BANK[$0007] ; length: $0220
    DB "--- Save Patch ---"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
