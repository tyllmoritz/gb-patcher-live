; md5 7ef69878c3b5bc5532c69a51a2dd42f3

; ROM "Harvest Moon GB (U) [S][!].gb"
; builds "Harvest Moon GB (U) [S][!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8c
DEF joypad_2 EQU $ff8b
DEF joypad_3 EQU $ff8a
DEF current_rom_bank EQU $4000
DEF SRAM_SIZE EQU CART_SRAM_8KB

;*************************
;* relocated joypad read *
;*************************

; Custom shape: the ROM0 hook site calls a separate ROM0 stub (invoke_read)
; that bank-switches to relocated_read_from_joypad, which lives in the
; save/load payload's own ROMX bank — see Burning Paper for the same
; pattern, just with the hook site in ROM0 instead of ROMX.
DEF JOYPAD_HOOK_VARIANT EQU 1
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    free_space_rom0 $00E4, $00E4 + $1B
    rom0_code
invoke_read:
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    ret
    end_code

    patch_rom $00, $2149
    call invoke_read
    nop
    end_patch


;*******************
;* save/load state *
;*******************

    savestates_marker --- Harvest Moon Save Patch ---
    free_space_romx $6, $7A80, $7A80 + $580
    romx_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    end_code
