; md5 4c614f884a07872f12056ad1a421e1f9

; ROM "Megaman III (U) [!].gb"
; builds "savestates/Megaman III (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff00+$8a
DEF joypad_2 EQU $ff00+$8b
DEF current_rom_bank EQU $de93


;*************************
;* relocated joypad read *
;*************************

    free_space_rom0 $3fa0, $3fa0 + $40


;***************
;* joypad read *
;***************

    savestates_joypad_hook $14df
    savestates_marker --- Megaman 3 Save Patch v1.0 ---


;*******************
;* save/load state *
;*******************

    free_space_romx $01, $7D1D, $7D1D + $2e3
