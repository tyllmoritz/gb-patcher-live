; md5 f7e13de010decf104efa3db865971f34

; ROM "Shanghai Pocket (U) (V1.1) [C][!].gbc"
; builds "Shanghai Pocket (U) (V1.1) [C][!] (savestates).gbc" with _SAVESTATES
DEF SRAM_SIZE EQU CART_SRAM_NONE
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG_GBC


; config
DEF CHANGE_GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC  ; save/load code needs CGB-exclusive hardware; forbid DMG-mode boot
DEF current_rom_bank EQU $d414
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5
DEF preserve_registers EQU 1
DEF swap_joypad EQU 1


; joypad
DEF joypad EQU $c0a4

; hook site is 8 bytes (extra register store, 2 trailing nops), which
; doesn't match joypad_hook's fixed 4-byte emission, so it's patched
; manually; JOYPAD_HOOK_VARIANT is declared manually to match what
; joypad_hook would have set.
DEF JOYPAD_HOOK_VARIANT EQU 0
    free_space_rom0 $00bf, $00bf + $003f

    patch_rom $00, $3ad2
    ld [joypad], a
    call relocated_read_from_joypad
    nop
    nop
    end_patch


; save/load state
    free_space_romx $0001, $6F81, $6F81 + $0270
