; md5 031e78c5067b88abe2870841d1125a29

; ROM "Pang (U).gb"
; builds "Pang (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8e
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $ff8d


;*************
;* reset ram *
;*************

    entry_point $0195
    free_space_rom0 $00b7, $00b7 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0077, $0077 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $2d9d


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $6DBF, $6DBF + $220
