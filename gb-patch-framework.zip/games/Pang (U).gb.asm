; md5 031e78c5067b88abe2870841d1125a29

; ROM "Pang (U).gb"
; builds "savestates/Pang (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8e
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $ff8d


;*************
;* reset ram *
;*************

    entry_point $0195
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00b7, $00b7 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0077, $0077 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $2d9d


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $6DBF, $6DBF + $220
