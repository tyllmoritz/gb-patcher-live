; md5 03c6d84a951be6703b7458478f4277b9

; ROM "Batman (JU) [!].gb"
; builds "Batman (JU) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff00+$b4
DEF joypad_2 EQU $ff00+$b5


;***************
;* joypad read *
;***************

    joypad_hook $0d28


;*******************
;* save/load state *
;*******************

    savestates_marker --- Batman Save Patch v1.0 ---
    free_space_rom0 $3d00, $3d00 + $300
    savestates_payload_in_rom0
