; md5 bc1a3848092bdc900c157996c29a7783

; ROM "Yoshi's Cookie (U) [!].gb"
; builds "Yoshi's Cookie (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8d
DEF joypad_2 EQU $ff8c
DEF joypad_3 EQU $ff8b
DEF current_rom_bank EQU $4000


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00cb, $00cb + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $008b, $008b + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $0300


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7CDB, $7CDB + $0220
