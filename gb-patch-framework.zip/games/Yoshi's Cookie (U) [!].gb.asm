; md5 bc1a3848092bdc900c157996c29a7783

; ROM "Yoshi's Cookie (U) [!].gb"
; builds "savestates/Yoshi's Cookie (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8d
DEF joypad_2 EQU $ff8c
DEF joypad_3 EQU $ff8b
DEF current_rom_bank EQU $4000


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00cb, $00cb + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $008b, $008b + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $0300


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7CDB, $7CDB + $0220
