; md5 8833ae0fd3b4c47b8249a12708c98a98

; ROM "Amazing Spider-Man 3, The - Invasion of the Spider-Slayers (U) [!].gb"
; builds "Amazing Spider-Man 3, The - Invasion of the Spider-Slayers (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF joypad EQU $ffb2
DEF joypad_2 EQU $d000
DEF current_rom_bank EQU $d045


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $034e


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220
