; md5 3a4bb57e9fbd4ef563c0c7b59a1c82a5

; ROM "Kwirk (UE) [!].gb"
; builds "savestates/Kwirk (UE) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $015e


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $2b81


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $4000, $4000 + $0220
