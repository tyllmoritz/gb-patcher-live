; md5 b7598a51e0acc0d74ca8f464826371ed

; ROM "Wario Land II (U) [C][!].gbc"
; builds "Wario Land II (U) [C][!] (savestates).gbc" with _SAVESTATES
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG_GBC


; config
DEF CHANGE_GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC  ; save/load code needs CGB-exclusive hardware; forbid DMG-mode boot
DEF current_rom_bank EQU $ffa4
DEF SRAM_SIZE EQU CART_SRAM_32KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT
DEF current_sram_bank EQU $ffa3
DEF current_nr34_value EQU $cf63


; joypad
DEF joypad EQU $c60b
DEF joypad_2 EQU $c60c

    free_space_rom0 $0062, $0062 + $40

    joypad_hook $1a9d


; save/load state
    free_space_rom0_b $33de, $33de + $0300
    savestates_payload_in_rom0_b
