; md5 b7598a51e0acc0d74ca8f464826371ed

; ROM "Wario Land II (U) [C][!].gbc"
; builds "savestates/Wario Land II (U) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF is_cgb EQU 1
DEF current_rom_bank EQU $ffa4
DEF game_uses_save_ram EQU 1
DEF uses_mbc5 EQU 1
DEF current_sram_bank EQU $ffa3
DEF current_nr34_value EQU $cf63


; joypad
DEF joypad EQU $c60b
DEF joypad_2 EQU $c60c

    free_space_rom0 $0062, $0062 + $40

    savestates_joypad_hook $1a9d


; save/load state
    free_space_rom0_b $33de, $33de + $0300
    savestates_payload_in_rom0_b
