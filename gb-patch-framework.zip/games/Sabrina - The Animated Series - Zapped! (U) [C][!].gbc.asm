; md5 ec39462e39e3cbcabe03667fabf12d5a

; ROM "Sabrina - The Animated Series - Zapped! (U) [C][!].gbc"
; builds "Sabrina - The Animated Series - Zapped! (U) [C][!] (savestates).gbc" with _SAVESTATES
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $ff91
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $0027, $0027 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    joypad_vblank_hook $0004, $084b


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $344c, $344c + $02d0
    savestates_payload_in_rom0_b
