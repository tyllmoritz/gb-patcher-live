; md5 ec39462e39e3cbcabe03667fabf12d5a

; ROM "Sabrina - The Animated Series - Zapped! (U) [C][!].gbc"
; builds "savestates/Sabrina - The Animated Series - Zapped! (U) [C][!] (savestates).gbc"


;**********
;* config *
;**********

DEF is_cgb EQU 1
DEF current_rom_bank EQU $ff91
DEF uses_mbc5 EQU 1


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0027, $0027 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

DEF vblank_handler EQU $0004
DEF original_vblank_handler EQU $084b
INCLUDE "src/features/savestates/vblank_handler.asm"


;*******************
;* save/load state *
;*******************

SECTION "save/load state", ROM0[$344c] ; length: $02d0
    DB "--- Save Patch ---"
    INCLUDE "src/features/savestates/joypad_read_and_check.asm"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
