; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; Pokemon Polished Crystal 3.0.0-beta by Rangi42
; https://github.com/Rangi42/polishedcrystal
; (the official nortc release build, so no _NORTC feature is needed on top)
;
; ROM "Pokemon - Polished Crystal (3.0.0-beta) (nortc).gbc"
; md5 0b4460fbbcb426201249b2ae1a9fb6ca
;
; builds "Pokemon - Polished Crystal (3.0.0-beta) (nortc) (batteryless).gbc" with _BATTERYLESS
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC3_RAM_BAT_RTC
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG_GBC
;
; ------------------------------------------------------------------------------

; game properties
; original header: CART_COMPATIBLE_DMG_GBC — save/load code doesn't need CGB-exclusive hardware here, so GB_COMPATIBILITY is left at its
; default (CART_COMPATIBLE_DMG) and the header is untouched
DEF SRAM_SIZE EQU CART_SRAM_32KB
DEF current_rom_bank EQU $ff93         ; hROMBank
DEF flash_data_bank EQU $74             ; banks $71-$7f are $ff padding (xxd-verified)

; free space in the original ROM/RAM
    free_space_rom0 $3d35, $4000        ; $ff padding to the end of bank 0 (xxd-verified)
    free_space_romx $71, $4000, $8000   ; whole bank is $ff padding (xxd-verified)
; WRAM window from the pre-framework port (found with a debugger there);
; sized to the feature's current footprint — the build asserts on overflow
    free_space_wram $d562, $d562 + $ab, $5

; the entry at $0100 is `nop; jr` to $0177 (not the usual nop+jp) — the
; 3-byte entry hook at $0100 covers it exactly
    entry_point $0177

; the game's save ends in a tail call: `jp CloseSRAM` ($2a60) at $05:$4cc5
    save_hook_jp $05, $4cc5, $2a60
