; md5 64080619789f154ee057f2946a98c61c

; ROM "Miracle Adventure of Esparks (Japan).gb"
; builds "savestates/Miracle Adventure of Esparks (Japan) (savestates).gb"


;**********
;* config *
;**********

DEF joypad EQU $fffa
DEF joypad_2 EQU $fffb
DEF current_rom_bank EQU $ffc7

;***************
;* joypad read *
;***************

SECTION "joypad read", ROM0[$5] ; length: $20
    INCLUDE "src/features/savestates/call_relocated_read_from_joypad_in_other_bank.asm"
    ret
ENDSECTION


;*******************
;* save/load state *
;*******************

SECTION "save/load state", ROMX[$4000], BANK[$08] ; length: $0255
    DB "--- XXXXX Save Patch ---"
	INCLUDE "src/features/savestates/joypad_read_and_check.asm"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
