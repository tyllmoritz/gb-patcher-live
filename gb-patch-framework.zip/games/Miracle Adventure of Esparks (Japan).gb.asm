; md5 64080619789f154ee057f2946a98c61c

; ROM "Miracle Adventure of Esparks (Japan).gb"
; builds "Miracle Adventure of Esparks (Japan) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $fffa
DEF joypad_2 EQU $fffb
DEF current_rom_bank EQU $ffc7

;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $5


;*******************
;* save/load state *
;*******************

    savestates_marker --- XXXXX Save Patch ---
    free_space_romx $08, $4000, $4000 + $0255
