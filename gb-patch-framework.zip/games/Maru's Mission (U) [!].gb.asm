; md5 7f26dd90f8e80b52ead8fc0e3609d4f2

; ROM "Maru's Mission (U) [!].gb"
; builds "savestates/Maru's Mission (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $4000


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $ff8f
DEF joypad_2 EQU $ff8e
DEF joypad_3 EQU $ff8d

    free_space_rom0_b $0062, $0062 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $2d2d


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $7ADC, $7ADC + $0220
