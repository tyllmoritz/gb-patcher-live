; md5 64f43161eb16eb1be99262c36867bc79

; ROM "Prehistorik Man (U).gb"
; builds "Prehistorik Man (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff00+$8d
DEF current_rom_bank EQU $ffce
DEF restore_sound EQU 1


;***************
;* joypad read *
;***************

; custom tail doesn't fit joypad_hook_banked's fixed ret/jp tail, so the hook
; site stays hand-placed; JOYPAD_HOOK_VARIANT is declared manually to match
; what joypad_hook_banked would have set. A second, disjoint patch site
; blanks 3 bytes of now-redundant game code.
DEF JOYPAD_HOOK_VARIANT EQU 1
    patch_rom $00, $119b
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    ld a,[$ff00+$8d]
    nop
    end_patch

    patch_rom $00, $11be
    nop
    nop
    nop
    end_patch


;*******************
;* save/load state *
;*******************

    savestates_marker --- Prehistorik Man Save Patch ---
    free_space_romx $8, $4000, $4000 + $4000
