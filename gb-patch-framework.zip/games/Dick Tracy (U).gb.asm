; md5 ab5f50d0e31a07e19739453bb9a2d328

; ROM "Dick Tracy (U).gb"
; builds "savestates/Dick Tracy (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $4000


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $000c, $000c + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $13c7


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4001, $4001 + $02a0

SECTION "new bank", ROMX[$4000], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
