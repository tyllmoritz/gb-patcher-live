; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; ROM "Pokemon - Crystal Version (USA, Europe).gbc"
; SHA1 f4cd194bdee0d04ca4eac29e09b8e4e9d818c133
;
; builds "nortc/Pokemon - Crystal Version (USA, Europe) (nortc).gbc" with _NORTC
; builds "batteryless/Pokemon - Crystal Version (USA, Europe) (nortc) (batteryless).gbc" with _BATTERYLESS _NORTC
;
; ------------------------------------------------------------------------------

; game properties
DEF sram_size_32kb EQU 1                        ; the game saves 32kb of SRAM
DEF current_rom_bank EQU $ff9d   ; hROMBank
DEF flash_data_bank EQU $80                     ; save data lives past the ROM

; free space in the original ROM/RAM
; (WRAM: sprite animation buffer, only used within a frame; stack is in WRAM0)
    free_space_rom0 $0070, $0100
    free_space_romx $01, $7550, $8000
    free_space_wram $d462, $d562, $5

; the game's `jp` at $0101 goes to $016e
    entry_point $016e

; both call sites of _SaveGameData ($5:$4c10)
    save_hook $05, $4b85, $4c10
    save_hook $05, $4be6, $4c10

IF DEF(_NORTC)
; offsets for the Pokegear RTC changer (Crystal USA/Europe)
DEF FarCall EQU $8
DEF hJoypadDown EQU $ffa4
DEF wStartDay_ EQU $d4b6
DEF wScriptFlags EQU $d434
DEF wSpriteAnimAddrBackup EQU $c3b8
DEF wSpriteAnimAddrBackup_Value EQU $c3
DEF wJumptableIndex EQU $cf63
DEF UpdateTime_FixTime_ EQU $05ad
DEF FixTime_ EQU $061d
DEF PokegearClock_Joypad_buttoncheck_ EQU $4f45
DEF PokegearClock_Joypad_BANK EQU $24
ENDC
