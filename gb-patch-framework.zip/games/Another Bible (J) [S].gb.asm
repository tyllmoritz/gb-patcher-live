; md5 ff9196caa266ae36d409ce7e53ddc77a

; ROM "Another Bible (J) [S].gb"
; builds "Another Bible (J) [S] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT


;**********
;* config *
;**********

DEF joypad EQU $c001
DEF joypad_2 EQU $c002
DEF current_rom_bank EQU $c077
DEF SRAM_SIZE EQU CART_SRAM_8KB
;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00c4, $00c4 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $0681


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $7B45, $7B45 + $02c5
