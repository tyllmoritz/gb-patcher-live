; md5 ff9196caa266ae36d409ce7e53ddc77a

; ROM "Another Bible (J) [S].gb"
; builds "savestates/Another Bible (J) [S] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c001
DEF joypad_2 EQU $c002
DEF current_rom_bank EQU $c077
DEF game_uses_save_ram EQU 1


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00c4, $00c4 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $0681


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $7B45, $7B45 + $02c5
