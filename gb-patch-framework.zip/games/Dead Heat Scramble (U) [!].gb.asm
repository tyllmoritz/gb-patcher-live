; md5 c2212d75077638539d6af4673b4939e6

; ROM "Dead Heat Scramble (U) [!].gb"
; builds "Dead Heat Scramble (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF joypad EQU $c1b5
DEF joypad_2 EQU $c1b6
DEF current_rom_bank EQU $ff94


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a4, $00a4 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0064, $0064 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $034c


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $0220
