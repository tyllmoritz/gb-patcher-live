; md5 c2212d75077638539d6af4673b4939e6

; ROM "Dead Heat Scramble (U) [!].gb"
; builds "savestates/Dead Heat Scramble (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c1b5
DEF joypad_2 EQU $c1b6
DEF current_rom_bank EQU $ff94


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a4, $00a4 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0064, $0064 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $034c


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $0220
