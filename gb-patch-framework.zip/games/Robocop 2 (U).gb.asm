; md5 3eb476d0c6347ce9034246f826866a58

; ROM "Robocop 2 (U).gb"
; builds "savestates/Robocop 2 (U) (savestates).gb"


; config
DEF current_rom_bank EQU $d269


; reset ram
    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0070, $0070 + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $ffb0
DEF swap_joypad EQU 1

SECTION "relocated read from joypad", ROM0[$3f00] ; length: $0050
relocated_read_from_joypad:
    ld a,$30
    ld [$ff00+$00],a

    ld a, b
    ld [$ff00+$b0], a
    INCLUDE "src/features/savestates/joypad_check.asm"
    ld a, [$ff00+$b0]
    ld b, a

    ret
ENDSECTION

SECTION "joypad read", ROM0[$02bd] ; length: 4
    call relocated_read_from_joypad
    nop
ENDSECTION


; save/load state
SECTION "save/load state", ROM0[$3b00] ; length: $0220
    DB "--- Save Patch ---"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
