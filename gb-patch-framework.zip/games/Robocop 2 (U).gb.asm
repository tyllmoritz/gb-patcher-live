; md5 3eb476d0c6347ce9034246f826866a58

; ROM "Robocop 2 (U).gb"
; builds "Robocop 2 (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $d269


; reset ram
    entry_point $0150
    free_space_rom0 $0070, $0070 + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $ffb0
DEF swap_joypad EQU 1

; custom, hand-written relocated_read_from_joypad body (register preservation
; around the standard check.asm) doesn't match the framework's generic
; implementation, so its automatic placement is skipped. A third, disjoint
; ROM0 window is needed (reset_ram's, this one, and the save/load payload's
; below), beyond the region API's two-region limit, so this one is placed
; via patch_rom directly instead of a third free_space_rom0 region.
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    joypad_hook $02bd
    patch_rom $00, $3f00
relocated_read_from_joypad:
    ld a,$30
    ld [$ff00+$00],a

    ld a, b
    ld [$ff00+$b0], a
    INCLUDE "src/core/hooks/joypad/check.asm"
    ld a, [$ff00+$b0]
    ld b, a

    ret
    end_patch


; save/load state
    free_space_rom0_b $3b00, $3b00 + $0220
    savestates_payload_in_rom0_b
