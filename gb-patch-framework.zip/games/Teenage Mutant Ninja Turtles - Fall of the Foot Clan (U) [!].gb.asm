; md5 ad868e84fb6071a3b6a211d16e6cbb66

; ROM "Teenage Mutant Ninja Turtles - Fall of the Foot Clan (U) [!].gb"
; builds "Teenage Mutant Ninja Turtles - Fall of the Foot Clan (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c05c
DEF joypad_2 EQU $c010
DEF joypad_3 EQU $c00f
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $c021


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $041a


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
