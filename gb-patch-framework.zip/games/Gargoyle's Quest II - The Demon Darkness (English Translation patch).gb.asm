; md5 3574c3ae7c83faeb018cb1c05950c25d

; ROM "Gargoyle's Quest II - The Demon Darkness (English Translation patch).gb"
; builds "Gargoyle's Quest II - The Demon Darkness (English Translation patch) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ffc7


; joypad
DEF joypad EQU $fffa
DEF joypad_2 EQU $fffb

    joypad_hook_banked $00, $2ff8, $3028


; save/load state
    free_space_romx $0005, $72DB, $72DB + $02a0
