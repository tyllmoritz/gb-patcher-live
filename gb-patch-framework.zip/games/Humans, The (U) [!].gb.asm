; md5 4a1ecc8ccc706ed5fdce2fdab2aaf03e

; ROM "Humans, The (U) [!].gb"
; builds "Humans, The (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $cf88
DEF joypad_2 EQU $cf8a


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $0061, $0061 + $40
    joypad_relocated_read_in_rom0_c

    joypad_hook $3a78


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $3b96, $3b96 + $0220
    savestates_payload_in_rom0_b
