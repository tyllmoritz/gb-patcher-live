; md5 a8b74d14e66f7a3049e79ca147141d52

; ROM "F-15 Strike Eagle (U) [!].gb"
; builds "F-15 Strike Eagle (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF current_rom_bank EQU $c8aa


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $0027, $0027 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    joypad_vblank_hook $0004, $0339


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $79F9, $79F9 + $02a0
