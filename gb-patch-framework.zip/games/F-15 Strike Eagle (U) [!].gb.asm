; md5 a8b74d14e66f7a3049e79ca147141d52

; ROM "F-15 Strike Eagle (U) [!].gb"
; builds "savestates/F-15 Strike Eagle (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $c8aa


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0027, $0027 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    savestates_vblank_hook $0004, $0339


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $79F9, $79F9 + $02a0
