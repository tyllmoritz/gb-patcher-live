; md5 4681f5b931a2e60ca163facd1adf56ed

; ROM "Megaman Xtreme (U) [C][!].gbc"
; builds "Megaman Xtreme (U) [C][!] (savestates).gbc" with _SAVESTATES
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG_GBC


; config
DEF CHANGE_GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC  ; save/load code needs CGB-exclusive hardware; forbid DMG-mode boot
DEF current_rom_bank EQU $7ffe
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT


; joypad
DEF joypad EQU $ff8f
DEF joypad_2 EQU $ff90
DEF preserve_registers EQU 1

    free_space_rom0 $0087, $0087 + $40

    joypad_hook $0911


; save/load state
    free_space_romx $0002, $7D3F, $7D3F + $0295
