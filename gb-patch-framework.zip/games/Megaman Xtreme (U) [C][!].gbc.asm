; md5 4681f5b931a2e60ca163facd1adf56ed

; ROM "Megaman Xtreme (U) [C][!].gbc"
; builds "savestates/Megaman Xtreme (U) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF is_cgb EQU 1
DEF current_rom_bank EQU $7ffe
DEF game_uses_save_ram EQU 1
DEF uses_mbc5 EQU 1


; joypad
DEF joypad EQU $ff8f
DEF joypad_2 EQU $ff90
DEF preserve_registers EQU 1

    free_space_rom0 $0087, $0087 + $40

    savestates_joypad_hook $0911


; save/load state
    free_space_romx $0002, $7D3F, $7D3F + $0295
