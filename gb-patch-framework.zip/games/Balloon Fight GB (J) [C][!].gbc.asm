; md5 f94f61e6beaec6222e0d35229e2e271e

; ROM "Balloon Fight GB (J) [C][!].gbc"
; builds "Balloon Fight GB (J) [C][!] (savestates).gbc" with _SAVESTATES
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG_GBC


; config
DEF CHANGE_GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC  ; save/load code needs CGB-exclusive hardware; forbid DMG-mode boot
DEF current_rom_bank EQU $ffca
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT


; joypad
DEF joypad EQU $ffa0

    free_space_rom0 $0062, $0062 + $40

    joypad_hook $0b72


; save/load state
    free_space_rom0_b $3cd3, $3cd3 + $0300
    savestates_payload_in_rom0_b
