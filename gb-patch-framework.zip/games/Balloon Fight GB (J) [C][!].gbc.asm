; md5 f94f61e6beaec6222e0d35229e2e271e

; ROM "Balloon Fight GB (J) [C][!].gbc"
; builds "savestates/Balloon Fight GB (J) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF is_cgb EQU 1
DEF current_rom_bank EQU $ffca
DEF game_uses_save_ram EQU 1
DEF uses_mbc5 EQU 1


; joypad
DEF joypad EQU $ffa0

    free_space_rom0 $0062, $0062 + $40

    savestates_joypad_hook $0b72


; save/load state
    free_space_rom0_b $3cd3, $3cd3 + $0300
    savestates_payload_in_rom0_b
