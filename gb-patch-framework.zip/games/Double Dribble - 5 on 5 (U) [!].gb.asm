; md5 ff3e6d70d42987dd7f6214067dc83afe

; ROM "Double Dribble - 5 on 5 (U) [!].gb"
; builds "savestates/Double Dribble - 5 on 5 (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c05f
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $c024


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00ec, $00ec + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $0393, $03c4


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $66D5, $66D5 + $02a0
