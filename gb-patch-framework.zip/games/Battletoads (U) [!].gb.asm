; md5 6d24c94d3acd89b4b703f7bd2a504833

; ROM "Battletoads (U) [!].gb"
; builds "Battletoads (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c903
DEF joypad_2 EQU $c901
DEF current_rom_bank EQU $4000
DEF do_not_disable_interrupts EQU 1

;***************
;* joypad read *
;***************

; custom tail (self-looping via a resume_joypad_read: label) doesn't fit
; joypad_hook_banked's fixed ret/jp tail, so the hook site stays hand-placed;
; JOYPAD_HOOK_VARIANT is declared manually to match what joypad_hook_banked
; would have set.
DEF JOYPAD_HOOK_VARIANT EQU 1
    free_space_rom0 $32cc, $32cc + $33
    rom0_code
resume_joypad_read:
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    ld a,[joypad]
    ld c,a
    jr resume_joypad_read
    end_code


;*******************
;* save/load state *
;*******************

    savestates_marker --- Battletoads Save Patch ---
    free_space_romx $08, $4000, $4000 + $4000

SECTION "bank 8", ROMX[$7FFF], BANK[$08] ; length: 1
    DB $8
ENDSECTION
