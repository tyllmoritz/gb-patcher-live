; md5 e84971b95d5dbb25efaf4ea89564a1a9

; ROM "Football International (U).gb"
; builds "savestates/Football International (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8d
DEF joypad_2 EQU $ff8b
DEF joypad_3 EQU $ff8e
DEF current_rom_bank EQU $4000


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0062, $0062 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $37c5


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $7006, $7006 + $0220
