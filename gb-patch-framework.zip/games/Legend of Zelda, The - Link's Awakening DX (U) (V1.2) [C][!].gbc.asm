; md5 7351daa3c0a91d8f6fe2fbcca6182478

; ROM "Legend of Zelda, The - Link's Awakening DX (U) (V1.2) [C][!].gbc"
; builds "Legend of Zelda, The - Link's Awakening DX (U) (V1.2) [C][!] (savestates).gbc" with _SAVESTATES
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG_GBC


; config
DEF CHANGE_GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC  ; save/load code needs CGB-exclusive hardware; forbid DMG-mode boot
DEF current_rom_bank EQU $dbaf
DEF SRAM_SIZE EQU CART_SRAM_32KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT


; joypad
DEF joypad EQU $ffcb
DEF joypad_2 EQU $ffcc
DEF swap_joypad EQU 1

    joypad_hook $2879
    free_space_rom0 $0006, $0006 + $003a  ; note: manually changed to skip rom debug tool bytes at $0003-$0005


; save/load state
    free_space_romx $0002, $7CF5, $7CF5 + $0295
