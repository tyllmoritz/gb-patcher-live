; md5 ccaf9331318d4dfe3d1ee681928a74fd

; ROM "Mario's Picross (UE) [S][!].gb"
; builds "savestates/Mario's Picross (UE) [S][!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $c312
DEF game_uses_save_ram EQU 1


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a5, $00a5 + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $c31a

    free_space_rom0_c $0064, $0064 + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $06f6


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $3250, $3250 + $0245
    savestates_payload_in_rom0_b
