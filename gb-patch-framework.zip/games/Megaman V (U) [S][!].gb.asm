; md5 ceb17d831b410d91aa41bf2819cbed82

; ROM "Megaman V (U) [S][!].gb"
; builds "Megaman V (U) [S][!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $de91
DEF joypad_2 EQU $de92
DEF current_rom_bank EQU $df00
DEF current_nr34_value EQU $dc7b


;*************************
;* relocated joypad read *
;*************************

    patch_rom $00, $0023
    call mbc1_on_mbc5_fix
    end_patch

; relocated_read.asm has an extra routine (mbc1_on_mbc5_fix) appended after
; it, so its automatic placement is skipped; the hook site itself still fits
; joypad_hook's plain ADDR shape exactly.
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    joypad_hook $18ba
    free_space_rom0 $3f80, $3f80 + $80
    rom0_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"

    ; prevent selecting rom bank 0
    mbc1_on_mbc5_fix:
        push af
        or a
        jr nz,mbc1_on_mbc5_fix_skip
        inc a
    mbc1_on_mbc5_fix_skip:
        ld [$2100],a
        pop af
        ret
    end_code


;*******************
;* save/load state *
;*******************

    savestates_marker --- Megaman 5 Save Patch ---
    free_space_romx $01, $7D80, $7D80 + $280
