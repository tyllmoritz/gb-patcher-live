; md5 63e3f5f4b90f17bdf6d2f2aed515e248

; ROM "Gargoyle's Quest - Ghosts'n Goblins (UE) [!].gb"
; builds "savestates/Gargoyle's Quest - Ghosts'n Goblins (UE) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c261
DEF joypad_2 EQU $c262
DEF current_rom_bank EQU $c3c5


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $0b31


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
