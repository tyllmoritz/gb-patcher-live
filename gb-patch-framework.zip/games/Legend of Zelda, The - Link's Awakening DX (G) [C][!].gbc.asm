; md5 e91fd46e7092d32ca264f21853f09539

; ROM "Legend of Zelda, The - Link's Awakening DX (G) [C][!].gbc"
; builds "savestates/Legend of Zelda, The - Link's Awakening DX (G) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF is_cgb EQU 1
DEF current_rom_bank EQU $dbaf
DEF game_uses_save_ram EQU 1
DEF uses_mbc5 EQU 1


; joypad
DEF joypad EQU $ffcb
DEF joypad_2 EQU $ffcc
DEF swap_joypad EQU 1

    free_space_rom0 $0092, $0092 + $40

    savestates_joypad_hook $2868


; save/load state
    free_space_romx $0002, $7cf5, $7cf5 + $0295
