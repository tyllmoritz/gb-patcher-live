; md5 e91fd46e7092d32ca264f21853f09539

; ROM "Legend of Zelda, The - Link's Awakening DX (G) [C][!].gbc"
; builds "Legend of Zelda, The - Link's Awakening DX (G) [C][!] (savestates).gbc" with _SAVESTATES
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG_GBC


; config
DEF CHANGE_GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC  ; save/load code needs CGB-exclusive hardware; forbid DMG-mode boot
DEF current_rom_bank EQU $dbaf
DEF SRAM_SIZE EQU CART_SRAM_32KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT


; joypad
DEF joypad EQU $ffcb
DEF joypad_2 EQU $ffcc
DEF swap_joypad EQU 1

    free_space_rom0 $0092, $0092 + $40

    joypad_hook $2868


; save/load state
    free_space_romx $0002, $7cf5, $7cf5 + $0295
