; md5 2a2ae531b2cebd995508707b0e82b1b1

; ROM "B.C. Kid 2 (E) [S].gb"
; builds "B.C. Kid 2 (E) [S] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c860
DEF joypad_2 EQU $c861
DEF current_rom_bank EQU $c865
DEF current_nr34_value EQU $dc2a


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $18d4


;*******************
;* save/load state *
;*******************


    free_space_romx $10, $4000, $4000 + $4000
    savestates_marker --- B.C. Kid 2 Save Patch ---
