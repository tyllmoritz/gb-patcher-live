; md5 2a2ae531b2cebd995508707b0e82b1b1

; ROM "B.C. Kid 2 (E) [S].gb"
; builds "savestates/B.C. Kid 2 (E) [S] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c860
DEF joypad_2 EQU $c861
DEF current_rom_bank EQU $c865
DEF current_nr34_value EQU $dc2a


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $18d4


;*******************
;* save/load state *
;*******************


    free_space_romx $10, $4000, $4000 + $4000
    savestates_marker --- B.C. Kid 2 Save Patch ---
