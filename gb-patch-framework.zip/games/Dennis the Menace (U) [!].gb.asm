; md5 f064bd662fdcb40a9f6926cc3baee116

; ROM "Dennis the Menace (U) [!].gb"
; builds "savestates/Dennis the Menace (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c2bb
DEF current_rom_bank EQU $c2b0


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00ca, $00ca + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0089, $0089 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $28ce


;*******************
;* save/load state *
;*******************

    free_space_romx $0006, $7C99, $7C99 + $0220
