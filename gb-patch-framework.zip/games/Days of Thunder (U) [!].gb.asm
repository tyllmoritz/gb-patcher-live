; md5 bdcf042bc2458768522c3cca43c89ee1

; ROM "Days of Thunder (U) [!].gb"
; builds "savestates/Days of Thunder (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $d541
DEF joypad_2 EQU $d543
DEF current_rom_bank EQU $ffef


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a4, $00a4 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0063, $0063 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $0e09


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220
