; md5 d5c27ff8cb1b69cb56df4ff170e2baf0

; ROM "Final Fantasy Legend, The (U) [!].gb"
; builds "Final Fantasy Legend, The (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC2_BAT


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ff8b
DEF SRAM_SIZE EQU CART_SRAM_2KB  ; MBC2 512x4-bit internal RAM (not real 8/32kb SRAM)
;**********
;* joypad *
;**********

DEF joypad EQU $ff8d

    joypad_hook_banked $00, $06f7, $0717


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02c5
