; md5 d5c27ff8cb1b69cb56df4ff170e2baf0

; ROM "Final Fantasy Legend, The (U) [!].gb"
; builds "savestates/Final Fantasy Legend, The (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $ff8b
DEF game_uses_save_ram EQU 1


;**********
;* joypad *
;**********

DEF joypad EQU $ff8d

    savestates_joypad_hook_banked $00, $06f7, $0717


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02c5
