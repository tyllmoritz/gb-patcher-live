; md5 308abd707a48ee9d69c287d818469fd6

; ROM "Boxxle 2 (U) [!].gb"
; builds "Boxxle 2 (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8d
DEF joypad_2 EQU $ff8e
DEF current_rom_bank EQU $0160


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $000d, $000d + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $25a8


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $4000, $4000 + $02a0
