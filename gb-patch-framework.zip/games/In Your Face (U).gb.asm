; md5 a4fc8158d1f2b6359ddac6c66d747a95

; ROM "In Your Face (U).gb"
; builds "savestates/In Your Face (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $ffe6


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $ffd5
DEF joypad_2 EQU $ffd6

    free_space_rom0_c $0062, $0062 + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $028c


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $3839, $3839 + $0220
    savestates_payload_in_rom0_b
