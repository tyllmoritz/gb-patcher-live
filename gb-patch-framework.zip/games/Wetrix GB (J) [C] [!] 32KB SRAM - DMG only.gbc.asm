; md5 f36cd3e0a8a8eacf4a9c5a2a755f237e

; ROM "Wetrix GB (J) [C][!].gbc"
; builds "Wetrix GB (J) [C] [!] 32KB SRAM - DMG only (savestates).gbc" with _SAVESTATES
DEF SRAM_SIZE EQU CART_SRAM_NONE
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG_GBC


; config
; original header: CART_COMPATIBLE_DMG_GBC — save/load code doesn't need CGB-exclusive hardware here, so GB_COMPATIBILITY is left at its
; default (CART_COMPATIBLE_DMG) and the header is untouched
DEF current_rom_bank EQU $ffb1
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5


; reset ram
    entry_point $0150
    free_space_rom0 $0001, $0001 + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $ff8c
DEF joypad_2 EQU $ff8d

    free_space_rom0_c $007e, $007e + $40
    joypad_relocated_read_in_rom0_c

    joypad_hook $08c6


; save/load state
    free_space_rom0_b $119e, $119e + $0220
    savestates_payload_in_rom0_b
