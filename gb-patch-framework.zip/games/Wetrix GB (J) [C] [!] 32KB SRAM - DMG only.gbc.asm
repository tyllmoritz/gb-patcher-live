; md5 f36cd3e0a8a8eacf4a9c5a2a755f237e

; ROM "Wetrix GB (J) [C][!].gbc"
; builds "savestates/Wetrix GB (J) [C] [!] 32KB SRAM - DMG only (savestates).gbc" with _SAVESTATES


; config
DEF current_rom_bank EQU $ffb1
DEF uses_mbc5 EQU 1


; reset ram
    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0001, $0001 + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $ff8c
DEF joypad_2 EQU $ff8d

    free_space_rom0_c $007e, $007e + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $08c6


; save/load state
    free_space_rom0_b $119e, $119e + $0220
    savestates_payload_in_rom0_b
