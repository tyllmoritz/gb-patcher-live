; md5 1c94dccdfaaa0c3e1d6bda5969704885

; ROM "Qix (JU) [!].gb"
; builds "Qix (JU) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ff8f


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $001c, $001c + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b

    joypad_hook_banked $00, $2bf8, $2c28


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7A8B, $7A8B + $02a0
