; md5 1c94dccdfaaa0c3e1d6bda5969704885

; ROM "Qix (JU) [!].gb"
; builds "savestates/Qix (JU) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $ff8f


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $001c, $001c + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b

    savestates_joypad_hook_banked $00, $2bf8, $2c28


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7A8B, $7A8B + $02a0
