; md5 85d05f95c07ed1b7d787062fe4d2e251

; ROM "Super Off Road (U) [!].gb"
; builds "Super Off Road (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c70b


;*************
;* reset ram *
;*************

    entry_point $0150


;***************
;* joypad read *
;***************

    joypad_hook $2c21


;*******************
;* save/load state *
;*******************

; No room for a save-patch marker in this game's tight free-space budget
; (its original config never had a DB marker line at all) — SAVESTATES_MARKER
; set to empty directly. relocated_read.asm and the save/load payload share
; the same ROM0 region (region 1, joypad_hook's default), matching
; code.asm's own ordering.
DEF SAVESTATES_MARKER EQUS ""
    free_space_rom0 $3b00, $3b00 + $4fd
    on_boot_inline reset_ram
    savestates_payload_in_rom0
