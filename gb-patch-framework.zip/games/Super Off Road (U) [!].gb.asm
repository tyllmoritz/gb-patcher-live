; md5 85d05f95c07ed1b7d787062fe4d2e251

; ROM "Super Off Road (U) [!].gb"
; builds "savestates/Super Off Road (U) [!] (savestates).gb"


;**********
;* config *
;**********

DEF joypad EQU $c70b


;*************
;* reset ram *
;*************

    entry_point $0150


;***************
;* joypad read *
;***************

SECTION "joypad read", ROM0[$2c21] ; length: 4
    call relocated_read_from_joypad
    nop
ENDSECTION


;*******************
;* save/load state *
;*******************

INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $3b00, $3b00 + $4fd
    on_boot_inline reset_ram
    rom0_code
    INCLUDE "src/features/savestates/relocated_read_from_joypad.asm"
    INCLUDE "src/features/savestates/legacy_includes.asm"
    end_code
