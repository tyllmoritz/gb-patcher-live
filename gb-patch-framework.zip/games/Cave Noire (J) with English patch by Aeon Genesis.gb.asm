; md5 9cf7725b41ee950f58c33e060718c2cf

; ROM "Cave Noire (J) with English patch by Aeon Genesis.gb"
; builds "savestates/Cave Noire (J) with English patch by Aeon Genesis (savestates).gb" with _SAVESTATES


; config
DEF current_rom_bank EQU $c024
DEF game_uses_save_ram EQU 1


; joypad
DEF joypad EQU $c00e
DEF joypad_2 EQU $c00f
DEF swap_joypad EQU 1

    savestates_joypad_hook_banked $00, $02a1


; save/load state
    free_space_romx $0008, $4000, $4000 + $02c5
