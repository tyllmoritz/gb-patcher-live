; md5 9cf7725b41ee950f58c33e060718c2cf

; ROM "Cave Noire (J) with English patch by Aeon Genesis.gb"
; builds "Cave Noire (J) with English patch by Aeon Genesis (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC2_BAT


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $c024
DEF SRAM_SIZE EQU CART_SRAM_2KB  ; MBC2 512x4-bit internal RAM (not real 8/32kb SRAM)
; joypad
DEF joypad EQU $c00e
DEF joypad_2 EQU $c00f
DEF swap_joypad EQU 1

    joypad_hook_banked $00, $02a1


; save/load state
    free_space_romx $0008, $4000, $4000 + $02c5
