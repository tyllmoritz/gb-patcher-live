; md5 8f6b6ef366a787852f664d945c86eb72

; ROM "Adventures of Lolo (U) [S][!].gb"
; builds "Adventures of Lolo (U) [S][!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $c5fc


; joypad
DEF joypad EQU $c3a1
DEF joypad_2 EQU $c3a2
DEF swap_joypad EQU 1

    free_space_rom0 $0087, $0087 + $40

    joypad_hook $06f2


; save/load state
    free_space_romx $0010, $4000, $4000 + $0220
