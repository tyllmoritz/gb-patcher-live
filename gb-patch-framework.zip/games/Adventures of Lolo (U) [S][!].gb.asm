; md5 8f6b6ef366a787852f664d945c86eb72

; ROM "Adventures of Lolo (U) [S][!].gb"
; builds "savestates/Adventures of Lolo (U) [S][!] (savestates).gb" with _SAVESTATES


; config
DEF current_rom_bank EQU $c5fc


; joypad
DEF joypad EQU $c3a1
DEF joypad_2 EQU $c3a2
DEF swap_joypad EQU 1

    free_space_rom0 $0087, $0087 + $40

    savestates_joypad_hook $06f2


; save/load state
    free_space_romx $0010, $4000, $4000 + $0220
