; md5 1efea4210026a8d733a5b2ade2b005f1

; ROM "Ikari no Yousai 2 (J) [!].gb"
; builds "Ikari no Yousai 2 (J) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00c1, $00c1 + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $ffdd
DEF joypad_2 EQU $ffde

    free_space_rom0_b $0071, $0071 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $034e


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $76B1, $76B1 + $0220
