; md5 e731fa23d9cd0c3d4dec7d5565beef61

; ROM "Simpsons, The - Escape from Camp Deadly (U) [!].gb"
; builds "Simpsons, The - Escape from Camp Deadly (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8c
DEF current_rom_bank EQU $c698
DEF restore_sound EQU 1


;*************************
;* relocated joypad read *
;*************************

    free_space_rom0 $00A0, $00A0 + $40


;***************
;* joypad read *
;***************

    joypad_hook $0cfa
    savestates_marker --- The Simpsons - Escape From Camp Deadly Save Patch ---


;*******************
;* save/load state *
;*******************

    free_space_romx $01, $7940, $7940 + $480
