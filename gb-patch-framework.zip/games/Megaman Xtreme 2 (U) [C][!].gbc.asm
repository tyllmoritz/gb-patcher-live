; md5 1f64989765f605d05cbd013e7ffcc352

; ROM "Megaman Xtreme 2 (U) [C][!].gbc"
; builds "savestates/Megaman Xtreme 2 (U) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF is_cgb EQU 1
DEF current_rom_bank EQU $ff92
DEF game_uses_save_ram EQU 1
DEF uses_mbc5 EQU 1


; joypad
DEF joypad EQU $ff8f
DEF joypad_2 EQU $ff90

    free_space_rom0 $0062, $0062 + $40

    savestates_joypad_hook $062a


; save/load state
    free_space_romx $0001, $7D00, $7D00 + $0295
