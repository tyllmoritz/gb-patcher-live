; md5 1f64989765f605d05cbd013e7ffcc352

; ROM "Megaman Xtreme 2 (U) [C][!].gbc"
; builds "Megaman Xtreme 2 (U) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $ff92
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT


; joypad
DEF joypad EQU $ff8f
DEF joypad_2 EQU $ff90

    free_space_rom0 $0062, $0062 + $40

    joypad_hook $062a


; save/load state
    free_space_romx $0001, $7D00, $7D00 + $0295
