; md5 314ca1610e00861bc97611c8f874503a

; ROM "Disney's Mulan (U) [S].gb"
; builds "Disney's Mulan (U) [S] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00e1, $00e1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $00a1, $00a1 + $40
    joypad_relocated_read_in_rom0_c

    joypad_hook $031b


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $0a53, $0a53 + $0220
    savestates_payload_in_rom0_b
