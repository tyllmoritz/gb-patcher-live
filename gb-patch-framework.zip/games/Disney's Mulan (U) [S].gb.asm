; md5 314ca1610e00861bc97611c8f874503a

; ROM "Disney's Mulan (U) [S].gb"
; builds "savestates/Disney's Mulan (U) [S] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00e1, $00e1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $00a1, $00a1 + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $031b


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $0a53, $0a53 + $0220
    savestates_payload_in_rom0_b
