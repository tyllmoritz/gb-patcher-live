; md5 023a8fd8eacad0656b5110da26dcdd44

; ROM "Battle Unit Zeoth (U) [!].gb"
; builds "savestates/Battle Unit Zeoth (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $c0eb


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0003, $0003 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $32b9, $32f9


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $45B7, $45B7 + $02a0
