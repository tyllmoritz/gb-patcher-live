; md5 023a8fd8eacad0656b5110da26dcdd44

; ROM "Battle Unit Zeoth (U) [!].gb"
; builds "Battle Unit Zeoth (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $c0eb


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $0003, $0003 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $32b9, $32f9


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $45B7, $45B7 + $02a0
