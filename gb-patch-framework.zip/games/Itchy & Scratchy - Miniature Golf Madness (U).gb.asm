; md5 ed0a8885341ee6a201873b2038c87582

; ROM "Itchy & Scratchy - Miniature Golf Madness (U).gb"
; builds "Itchy & Scratchy - Miniature Golf Madness (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $0158
    free_space_rom0 $00ab, $00ab + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $ffd2
DEF joypad_2 EQU $ffd3

    free_space_rom0_b $006a, $006a + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $03d6


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220

SECTION "new bank", ROMX[$7FFF], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
