; md5 ed0a8885341ee6a201873b2038c87582

; ROM "Itchy & Scratchy - Miniature Golf Madness (U).gb"
; builds "savestates/Itchy & Scratchy - Miniature Golf Madness (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $0158
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00ab, $00ab + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $ffd2
DEF joypad_2 EQU $ffd3

    free_space_rom0_b $006a, $006a + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $03d6


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220

SECTION "new bank", ROMX[$7FFF], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
