; md5 abd4baa57f0b90b402c2e56090394f9e

; ROM "Hercules (U) [S].gb"
; builds "Hercules (U) [S] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b
DEF current_rom_bank EQU $ff8f


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $04bc, $04ec


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7624, $7624 + $02a0
