; md5 abd4baa57f0b90b402c2e56090394f9e

; ROM "Hercules (U) [S].gb"
; builds "savestates/Hercules (U) [S] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b
DEF current_rom_bank EQU $ff8f


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $04bc, $04ec


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7624, $7624 + $02a0
