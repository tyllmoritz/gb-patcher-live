; md5 7db13139bc32e2aadb732d610f4c1604

; ROM "Mr Nutz (U).gb"
; builds "Mr Nutz (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $d8dc
DEF joypad_2 EQU $d8dd
DEF joypad_debounce EQU 1
DEF current_rom_bank EQU $7fff
DEF preserve_register_a EQU 1


;***************
;* joypad read *
;***************

; Custom shape: the hook site ($1296) jumps to a separate ROM0 stub ($80)
; that bank-switches to relocated_read_from_joypad, which lives in the
; save/load payload's own ROMX bank — see Burning Paper for the same
; pattern; the stub's own custom tail (jp back into game code) also doesn't
; fit joypad_hook_banked's fixed ret/jp tail.
DEF JOYPAD_HOOK_VARIANT EQU 1
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    free_space_rom0 $80, $80 + $80
    rom0_code
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    jp $12a6
    end_code

    patch_rom $00, $1296
    jp $0080
    end_patch


;*******************
;* save/load state *
;*******************

    savestates_marker --- Mr Nutz Save Patch ---
    free_space_romx $01, $7DA0, $7DA0 + $260
    romx_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    end_code


;*******************
;* bank numbers... *
;*******************

SECTION "bank 1", ROMX[$7FFF], BANK[$01] ; length: 1
    DB $1
ENDSECTION

SECTION "bank 2", ROMX[$7FFF], BANK[$02] ; length: 1
    DB $2
ENDSECTION

SECTION "bank 3", ROMX[$7FFF], BANK[$03] ; length: 1
    DB $3
ENDSECTION

SECTION "bank 4", ROMX[$7FFF], BANK[$04] ; length: 1
    DB $4
ENDSECTION

SECTION "bank 5", ROMX[$7FFF], BANK[$05] ; length: 1
    DB $5
ENDSECTION

SECTION "bank 6", ROMX[$7FFF], BANK[$06] ; length: 1
    DB $6
ENDSECTION

SECTION "bank 7", ROMX[$7FFF], BANK[$07] ; length: 1
    DB $7
ENDSECTION

SECTION "bank 8", ROMX[$7FFF], BANK[$08] ; length: 1
    DB $8
ENDSECTION

SECTION "bank 9", ROMX[$7FFF], BANK[$09] ; length: 1
    DB $9
ENDSECTION

SECTION "bank a", ROMX[$7FFF], BANK[$0a] ; length: 1
    DB $a
ENDSECTION

SECTION "bank b", ROMX[$7FFF], BANK[$0b] ; length: 1
    DB $b
ENDSECTION

SECTION "bank c", ROMX[$7FFF], BANK[$0c] ; length: 1
    DB $c
ENDSECTION

SECTION "bank d", ROMX[$7FFF], BANK[$0d] ; length: 1
    DB $d
ENDSECTION

SECTION "bank e", ROMX[$7FFF], BANK[$0e] ; length: 1
    DB $e
ENDSECTION

SECTION "bank f", ROMX[$7FFF], BANK[$0f] ; length: 1
    DB $f
ENDSECTION
