; md5 c94afb46cada0118aa8ff08cc07749a4

; ROM "Parodius (UE) [!].gb"
; builds "Parodius (UE) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $cb86
DEF joypad_2 EQU $cb87
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $7fff
DEF current_nr34_value EQU $c1b6


;*************************
;* relocated joypad read *
;*************************

; Custom shape: the ROM0 stub has an extra call before call_in_other_bank.asm,
; and the actual hook site is a separate, disjoint patch (call to the stub).
; relocated_read_from_joypad lives in the save/load payload's own ROMX bank —
; see Burning Paper for the same general pattern. No room for a save-patch
; marker in this game's tight free-space budget (its own legacy comment: "no
; space"), so SAVESTATES_MARKER is set to empty directly.
DEF JOYPAD_HOOK_VARIANT EQU 1
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
DEF SAVESTATES_MARKER EQUS ""
    free_space_rom0 $00a0, $00a0 + $60
    rom0_code
will_read_from_joypad:
    call $4087
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    ret
    end_code

    patch_rom $00, $02fd
    call will_read_from_joypad
    end_patch


;*******************
;* save/load state *
;*******************

    free_space_romx $0e, $7D10, $7D10 + $25f
    romx_code
    DEF joypad_read_already_finished EQU 1
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    end_code
