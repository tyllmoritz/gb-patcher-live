; md5 159c8ca77e153b1cc5fe6d5d82a091c2

; ROM "Barbie - Game Girl (U).gb"
; builds "savestates/Barbie - Game Girl (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8c
DEF current_rom_bank EQU $4000


;*************
;* reset ram *
;*************

    entry_point $037e
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00ab, $00ab + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $006b, $006b + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $04e6


;*******************
;* save/load state *
;*******************

    free_space_romx $0005, $7C11, $7C11 + $0220
