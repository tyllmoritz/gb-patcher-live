; md5 4ba4398181d98958fa7434ba7716f11a

; ROM "Megaman - Dr. Wily's Revenge (U) [!].gb"
; builds "savestates/Megaman - Dr. Wily's Revenge (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $0061, $0061 + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $15b2


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $3979, $3979 + $0220
    savestates_payload_in_rom0_b
