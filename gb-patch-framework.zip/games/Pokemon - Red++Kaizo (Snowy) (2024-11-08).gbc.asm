; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; Pokemon Red++Kaizo (Snowy) 2024-11-08 — pokered-lineage ROM hack
;
; ROM "Pokemon - Red++Kaizo (Snowy) (2024-11-08).gbc"
; md5 9a57cca6d63f83ea3a0c244d7b9dbd4c
;
; builds "Pokemon - Red++Kaizo (Snowy) (2024-11-08) (batteryless).gbc" with _BATTERYLESS
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC3_RAM_BAT
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
;
; ------------------------------------------------------------------------------

; game properties
; original header: CART_COMPATIBLE_GBC — save/load code doesn't need CGB-exclusive hardware here, so GB_COMPATIBILITY is left at its
; default (CART_COMPATIBLE_DMG) and the header is untouched
DEF SRAM_SIZE EQU CART_SRAM_32KB
DEF current_rom_bank EQU $ffb8         ; H_LOADEDROMBANK (pokered lineage)
DEF flash_data_bank EQU $40             ; first bank past the 1MB ROM

; free space in the original ROM/RAM
    free_space_rom0 $3f30, $4000        ; zero padding after the game's
                                        ; bank-switch code ends at $3f20
                                        ; (xxd-verified)
    free_space_romx $3f, $4000, $8000   ; whole bank is zero padding (xxd-verified)
; WRAM window from the pre-framework port (found with a debugger there);
; sized to the feature's current footprint — the build asserts on overflow
    free_space_wram $d000, $d000 + $ab, $3

; the entry at $0100 is a bare `jp $00be` (no leading nop) — the 3-byte
; entry hook at $0100 covers it exactly
    entry_point $00be

; the save site is not a call: the 3-byte `ld [wHaltAudio], a` right after
; SaveSAVtoSRAM completes is replaced and replayed in the generated stub
    save_hook_inline $1c, $691b
        ld [$c0fe], a                   ; original: ld [wHaltAudio], a
    end_save_hook_inline
