; md5 5e441af514d1bcdaec08c133ceea4e5e

; ROM "Garfield Labyrinth (U).gb"
; builds "savestates/Garfield Labyrinth (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $ffd5


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $002f, $002f + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    savestates_vblank_hook $000c, $01bb


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $6E88, $6E88 + $02a0
