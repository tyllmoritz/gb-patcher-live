; md5 5e441af514d1bcdaec08c133ceea4e5e

; ROM "Garfield Labyrinth (U).gb"
; builds "Garfield Labyrinth (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ffd5


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $002f, $002f + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    joypad_vblank_hook $000c, $01bb


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $6E88, $6E88 + $02a0
