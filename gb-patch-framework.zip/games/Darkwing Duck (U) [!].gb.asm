; md5 7d776329212fa7cc2b00c5a46f06dd92

; ROM "Darkwing Duck (U) [!].gb"
; builds "Darkwing Duck (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff92
DEF joypad_2 EQU $ff93
DEF current_rom_bank EQU $ff98

;*************************
;* relocated joypad read *
;*************************

    free_space_rom0 $00C0, $00C0 + $40


;***************
;* joypad read *
;***************

    joypad_hook $0381
    savestates_marker --- Darkwing Duck Save Patch ---


;*******************
;* save/load state *
;*******************

    free_space_romx $08, $4000, $4000 + $4000
