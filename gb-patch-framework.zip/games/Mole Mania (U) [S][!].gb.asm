; md5 f28ade3926852a8ad2e449c274683956

; ROM "Mole Mania (U) [S][!].gb"
; builds "savestates/Mole Mania (U) [S][!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b
DEF current_rom_bank EQU $ff8c
DEF game_uses_save_ram EQU 1
DEF restore_wave_ram EQU 1


;*************************
;* relocated joypad read *
;*************************

INCLUDE "src/features/savestates/reset_ram.asm"
        free_space_rom0 $00a0, $00a0 + $60
    on_boot_inline reset_ram


;*************
;* reset ram *
;*************

    entry_point $0150


;***************
;* joypad read *
;***************

    savestates_joypad_hook $01e2
    savestates_marker --- Mole Mania Save Patch ---


;*******************
;* save/load state *
;*******************

    free_space_romx $02, $7A00, $7A00 + $600
