; md5 f28ade3926852a8ad2e449c274683956

; ROM "Mole Mania (U) [S][!].gb"
; builds "Mole Mania (U) [S][!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b
DEF current_rom_bank EQU $ff8c
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF restore_wave_ram EQU 1


;*************************
;* relocated joypad read *
;*************************

        free_space_rom0 $00a0, $00a0 + $60
    on_boot_inline reset_ram


;*************
;* reset ram *
;*************

    entry_point $0150


;***************
;* joypad read *
;***************

    joypad_hook $01e2
    savestates_marker --- Mole Mania Save Patch ---


;*******************
;* save/load state *
;*******************

    free_space_romx $02, $7A00, $7A00 + $600
