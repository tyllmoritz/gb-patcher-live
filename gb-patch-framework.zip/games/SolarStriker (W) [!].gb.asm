; md5 83bed4ebefeece45748258fd2ef105b3

; ROM "SolarStriker (W) [!].gb"
; builds "SolarStriker (W) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $4004


; detect current rom bank based on unique values in rom
DEF should_detect_rom_bank EQU 1
MACRO detect_rom_bank
    push bc
    push hl
    ld a, [current_rom_bank]
    ld b, a
    ld c, 1
    ld hl, .bank_values\@
.jump\@
    ld a, [hl+]
    cp b
    jr z, .bank_detected\@
    inc c
    jr .jump\@
.bank_values\@
DB $06, $00, $01
.bank_detected\@
    ld a, c
    pop hl
    pop bc
ENDM


; joypad
DEF joypad EQU $cf80
DEF joypad_2 EQU $cf81

    joypad_hook_banked $00, $081a


; save/load state
    free_space_romx $0004, $4000, $4000 + $02a0
