; md5 76010c6ff6bd0c4e8ac934dc69fb96ab

; ROM "Atomic Punk (U) [!].gb"
; builds "savestates/Atomic Punk (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b
DEF current_rom_bank EQU $ffc9


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $04d3


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $4C25, $4C25 + $0220
