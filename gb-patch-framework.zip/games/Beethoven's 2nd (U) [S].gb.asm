; md5 5544efa64429127007aa3779beaa654e

; ROM "Beethoven's 2nd (U) [S].gb"
; builds "Beethoven's 2nd (U) [S] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8b
DEF joypad_2 EQU $d19d

; MANUAL EDIT - current rom bank not stored, so assume bank 1 during joypad read routine
DEF current_rom_bank EQU $0175


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $01ca


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $476F, $476F + $0220
