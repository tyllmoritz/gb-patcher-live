; md5 8963803e642dbfbe4f5f3bc5a567785d

; ROM "Bugs Bunny - Crazy Castle II (U) [!].gb"
; builds "savestates/Bugs Bunny - Crazy Castle II (U) [!] (savestates).gb" with _SAVESTATES


; config
DEF current_rom_bank EQU $ffd6


; reset ram
    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00c4, $00c4 + $F
    on_boot_inline reset_ram



; vblank
    savestates_vblank_hook $000c, $01b0


; save/load state
    free_space_romx $0001, $7CF4, $7CF4 + $02a0
