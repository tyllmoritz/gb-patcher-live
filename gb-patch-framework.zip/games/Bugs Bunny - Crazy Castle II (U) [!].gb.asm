; md5 8963803e642dbfbe4f5f3bc5a567785d

; ROM "Bugs Bunny - Crazy Castle II (U) [!].gb"
; builds "Bugs Bunny - Crazy Castle II (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF current_rom_bank EQU $ffd6


; reset ram
    entry_point $0150
    free_space_rom0 $00c4, $00c4 + $F
    on_boot_inline reset_ram



; vblank
    joypad_vblank_hook $000c, $01b0


; save/load state
    free_space_romx $0001, $7CF4, $7CF4 + $02a0
