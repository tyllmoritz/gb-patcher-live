; md5 0beb67de765ef358d50c28836a39bfb0

; ROM "Fish Dude (U).gb"
; builds "Fish Dude (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ff8a


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $0027, $0027 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    joypad_vblank_hook $0004, $04e3


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $7C17, $7C17 + $02a0
