; md5 0beb67de765ef358d50c28836a39bfb0

; ROM "Fish Dude (U).gb"
; builds "savestates/Fish Dude (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $ff8a


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0027, $0027 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    savestates_vblank_hook $0004, $04e3


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $7C17, $7C17 + $02a0
