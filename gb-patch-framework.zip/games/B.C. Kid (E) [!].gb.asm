; md5 d335d4d79ed002c7a67863e82ceaa472

; ROM "B.C. Kid (E) [!].gb"
; builds "B.C. Kid (E) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF joypad EQU $ff8d
DEF joypad_2 EQU $ff8e
DEF current_rom_bank EQU $c148


;***************
;* joypad read *
;***************

; custom tail (ei / jp, not a plain ret) doesn't fit joypad_hook_banked's
; fixed ret/jp tail, so the hook site stays hand-placed; JOYPAD_HOOK_VARIANT
; is declared manually to match what joypad_hook_banked would have set.
DEF JOYPAD_HOOK_VARIANT EQU 1
DEF resume_read_from_joypad EQU $0597
    free_space_rom0 $0562, $0562 + $34
    rom0_code
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    ei
    jp resume_read_from_joypad
    end_code


;*******************
;* save/load state *
;*******************

    savestates_marker --- B.C. Kid Save Patch ---
    free_space_romx $10, $4000, $4000 + $4000
