; md5 d335d4d79ed002c7a67863e82ceaa472

; ROM "B.C. Kid (E) [!].gb"
; builds "savestates/B.C. Kid (E) [!] (savestates).gb"


;**********
;* config *
;**********

DEF joypad EQU $ff8d
DEF joypad_2 EQU $ff8e
DEF current_rom_bank EQU $c148


;***************
;* joypad read *
;***************

DEF resume_read_from_joypad EQU $0597
SECTION "joypad read", ROM0[$0562] ; length: $34
    INCLUDE "src/features/savestates/call_relocated_read_from_joypad_in_other_bank.asm"
    ei
    jp resume_read_from_joypad
ENDSECTION


;*******************
;* save/load state *
;*******************

SECTION "save/load state", ROMX[$4000], BANK[$10] ; length: $4000
    DB "--- B.C. Kid Save Patch ---"
    INCLUDE "src/features/savestates/joypad_read_and_check.asm"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
