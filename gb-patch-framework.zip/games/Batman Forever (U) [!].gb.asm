; md5 28737a5c760938a9746fa9e1a2fcefc6

; ROM "Batman Forever (U) [!].gb"
; builds "savestates/Batman Forever (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $d89d


;*************
;* reset ram *
;*************

    entry_point $0068
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00d7, $00d7 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    savestates_vblank_hook $00b4, $06a6


;*******************
;* save/load state *
;*******************

    free_space_romx $0010, $4000, $4000 + $02a0
