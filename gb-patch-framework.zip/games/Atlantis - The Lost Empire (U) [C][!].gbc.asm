; md5 5aab47cf957c82c969bbc0a93232f883

; ROM "Atlantis - The Lost Empire (U) [C][!].gbc"
; builds "savestates/Atlantis - The Lost Empire (U) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF is_cgb EQU 1
DEF current_rom_bank EQU $7fff
DEF uses_mbc5 EQU 1


; joypad
DEF joypad EQU $c106
DEF joypad_2 EQU $c107

    savestates_joypad_hook_banked $00, $00b8


; save/load state
    free_space_rom0_b $378b, $378b + $02f0
    savestates_payload_in_rom0_b
