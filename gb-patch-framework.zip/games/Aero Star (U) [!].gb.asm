; md5 f777a4526089a83ca758efbf01007ec1

; ROM "Aero Star (U) [!].gb"
; builds "savestates/Aero Star (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8e
DEF joypad_2 EQU $ff8f
DEF joypad_3 EQU $ff90
DEF current_rom_bank EQU $ffb6


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $007b, $007b + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $02ee


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $67CD, $67CD + $02a0
