; md5 545de5c311259b7f7ec313a9d58cf4b4

; ROM "Double Dragon (U) [!].gb"
; builds "savestates/Double Dragon (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c417
DEF joypad_2 EQU $c419
DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0003, $0003 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $2048


;*******************
;* save/load state *
;*******************

    free_space_romx $0006, $7D00, $7D00 + $02a0
