; md5 133ae23114bf442fef6acccd1b8e187a

; ROM "Terminator 2 - Judgment Day (UE) [!].gb"
; builds "Terminator 2 - Judgment Day (UE) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $d093
DEF joypad_2 EQU $d094
DEF current_rom_bank EQU $d104


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $026b


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7C89, $7C89 + $0220
