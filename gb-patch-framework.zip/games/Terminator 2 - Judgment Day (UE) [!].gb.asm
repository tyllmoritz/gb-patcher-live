; md5 133ae23114bf442fef6acccd1b8e187a

; ROM "Terminator 2 - Judgment Day (UE) [!].gb"
; builds "savestates/Terminator 2 - Judgment Day (UE) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $d093
DEF joypad_2 EQU $d094
DEF current_rom_bank EQU $d104


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $026b


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7C89, $7C89 + $0220
