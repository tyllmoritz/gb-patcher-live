; md5 9639948ad274fa15281f549e5f9c4d87

; ROM "Metroid II - Return of Samus (W) [!].gb"
; builds "savestates/Metroid II - Return of Samus (W) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff00+$80
DEF joypad_2 EQU $ff00+$81
DEF current_rom_bank EQU $d04e
DEF game_uses_save_ram EQU 1
DEF current_nr34_value EQU $cf1e


;*************************
;* relocated joypad read *
;*************************

INCLUDE "src/features/savestates/reset_ram.asm"
        free_space_rom0 $0080, $0080 + $70
    on_boot_inline reset_ram


;*************
;* reset ram *
;*************

    entry_point $0150


;***************
;* joypad read *
;***************

    savestates_joypad_hook $22b7
    savestates_marker --- Metroid II Save Patch ---

;*******************
;* save/load state *
;*******************

    free_space_romx $01, $7C00, $7C00 + $400
