; md5 91ecec5f8d06f18724bd1462b53c4b3d

; ROM "Adventures of Star Saver, The (U) [!].gb"
; builds "Adventures of Star Saver, The (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c0a2
DEF joypad_2 EQU $c0a0
DEF joypad_3 EQU $c0a1
DEF current_rom_bank EQU $c0b7


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00e2, $00e2 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $00a2, $00a2 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $02c1


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220
