; md5 4ca44cbdd4e05c9b3c22da96d3de6338

; ROM "Legend of Zelda, The - Oracle of Seasons (E) (M5) [C][!].gbc"
; builds "Legend of Zelda, The - Oracle of Seasons (E) (M5) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $7fff
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT


; vblank
MACRO original_vblank_handler_pushes_macro
    db $f5, $c5, $d5, $e5
ENDM
    joypad_vblank_hook $3ef3, $09f6, original_vblank_handler_pushes


; save/load state
    free_space_romx $0033, $4001, $4001 + $0315
