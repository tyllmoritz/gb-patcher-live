; md5 97bc907deba1e7d7c9bc72fca0310822

; ROM "Batman - Return of the Joker (U) [!].gb"
; builds "savestates/Batman - Return of the Joker (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffe1
DEF joypad_2 EQU $ffe2
DEF current_rom_bank EQU $c703


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $07f8


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220
