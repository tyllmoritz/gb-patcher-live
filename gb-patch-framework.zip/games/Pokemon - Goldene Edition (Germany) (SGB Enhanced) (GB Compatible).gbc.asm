; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; ROM "Pokemon - Goldene Edition (Germany) (SGB Enhanced) (GB Compatible).gbc"
; SHA1 9254195d461ea942eaaa08cc4b83de3cf82aea0d
;
; builds "nortc/Pokemon - Goldene Edition (Germany) (SGB Enhanced) (GB Compatible) (nortc).gbc" with _NORTC
; builds "batteryless/Pokemon - Goldene Edition (Germany) (SGB Enhanced) (GB Compatible) (nortc) (batteryless).gbc" with _BATTERYLESS _NORTC
;
; ------------------------------------------------------------------------------

; game properties (same disassembly lineage as Gold Version USA/Europe)
DEF sram_size_32kb EQU 1
DEF current_rom_bank EQU $ff9f
DEF flash_data_bank EQU $80

; free space in the original ROM/RAM
; (WRAM: shadow OAM, only used within a frame; stack is in WRAM0)
    free_space_rom0 $0070, $0100
    free_space_romx $01, $7640, $8000
    free_space_wram $c300, $c400

; the game's `jp` at $0101 goes to $05c6
    entry_point $05c6

; both call sites of _SaveGameData ($5:$4ccc)
    save_hook $05, $4c23, $4ccc
    save_hook $05, $4ca2, $4ccc

IF DEF(_NORTC)
; offsets for the Pokegear RTC changer (Gold/Silver USA/Europe lineage)
DEF FarCall EQU $8
DEF hJoypadDown EQU $ffa6
DEF wStartDay_ EQU $d1dc
DEF wScriptFlags EQU $d15b
DEF wSpriteAnimAddrBackup EQU $c5c0
DEF wSpriteAnimAddrBackup_Value EQU $c5
DEF wJumptableIndex EQU $ce63
DEF UpdateTime_FixTime_ EQU $046d
DEF FixTime_ EQU $04de
DEF PokegearClock_Joypad_buttoncheck_ EQU $4f0e
DEF PokegearClock_Joypad_BANK EQU $24
ENDC
