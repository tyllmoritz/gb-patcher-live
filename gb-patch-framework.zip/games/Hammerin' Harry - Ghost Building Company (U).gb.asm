; md5 131993b986f3ba1f682d8d74f050487b

; ROM "Hammerin' Harry - Ghost Building Company (U).gb"
; builds "savestates/Hammerin' Harry - Ghost Building Company (U) (savestates).gb"


;**********
;* config *
;**********

DEF joypad EQU $ff00+$fb

DEF current_nr34_value EQU $4821


;*************
;* reset ram *
;*************

    entry_point $0150


;***************
;* joypad read *
;***************

SECTION "joypad read call", ROM0[$1cec] ; length: 8
    push bc
    call relocated_read_from_joypad
    pop bc
    ld a,[$ff00+$fb]
    ret
ENDSECTION


;*******************
;* save/load state *
;*******************

INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $3600, $3600 + $A00
    on_boot_inline reset_ram
    rom0_code
    DB "--- Hammerin' Harry Save Patch ---"
    INCLUDE "src/features/savestates/joypad_read_and_check.asm"
    INCLUDE "src/features/savestates/legacy_includes.asm"
    end_code
