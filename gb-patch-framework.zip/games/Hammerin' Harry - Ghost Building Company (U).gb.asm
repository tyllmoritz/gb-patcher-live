; md5 131993b986f3ba1f682d8d74f050487b

; ROM "Hammerin' Harry - Ghost Building Company (U).gb"
; builds "Hammerin' Harry - Ghost Building Company (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff00+$fb

DEF current_nr34_value EQU $4821


;*************
;* reset ram *
;*************

    entry_point $0150


;***************
;* joypad read *
;***************

; custom wrapping around the call (push/pop bc, extra register load) doesn't
; fit joypad_hook_banked's fixed tail, so the hook site stays hand-placed;
; relocated_read_from_joypad itself comes from the standard read_and_check.asm
; body in the save/load payload below (no bank switch needed — both are in
; ROM0), so JOYPAD_HOOK_VARIANT is declared manually to match what
; joypad_hook_banked would have set.
DEF JOYPAD_HOOK_VARIANT EQU 1
    patch_rom $00, $1cec
    push bc
    call relocated_read_from_joypad
    pop bc
    ld a,[$ff00+$fb]
    ret
    end_patch


;*******************
;* save/load state *
;*******************

    savestates_marker --- Hammerin' Harry Save Patch ---
    free_space_rom0 $3600, $3600 + $A00
    on_boot_inline reset_ram
    savestates_payload_in_rom0
