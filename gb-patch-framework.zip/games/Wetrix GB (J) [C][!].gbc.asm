; md5 f36cd3e0a8a8eacf4a9c5a2a755f237e

; ROM "Wetrix GB (J) [C][!].gbc"
; builds "Wetrix GB (J) [C][!] (savestates).gbc" with _SAVESTATES
DEF SRAM_SIZE EQU CART_SRAM_NONE
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG_GBC


; config
DEF CHANGE_GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC  ; save/load code needs CGB-exclusive hardware; forbid DMG-mode boot
DEF current_rom_bank EQU $ffb1
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5


; joypad
DEF joypad EQU $ff8c
DEF joypad_2 EQU $ff8d

    free_space_rom0 $007e, $007e + $40

    joypad_hook $08c6


; save/load state
    free_space_rom0_b $119e, $119e + $0270
    savestates_payload_in_rom0_b
