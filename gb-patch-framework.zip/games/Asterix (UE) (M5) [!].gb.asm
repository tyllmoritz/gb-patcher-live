; md5 812db832566202610bb1e42e643e2b93

; ROM "Asterix (UE) (M5) [!].gb"
; builds "Asterix (UE) (M5) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $4000


; detect current rom bank based on unique values in rom
DEF should_detect_rom_bank EQU 1
MACRO detect_rom_bank
    push bc
    push hl
    ld a, [current_rom_bank]
    ld b, a
    ld c, 1
    ld hl, .bank_values\@
:   ld a, [hl+]
    cp b
    jr z, .bank_detected\@
    inc c
    jr :-
.bank_values\@:
DB $5f, $00, $4b, $90, $56, $c0, $6e
.bank_detected\@:
    ld a, c
    pop hl
    pop bc
ENDM


; joypad — custom tail (extra "ld a,[$ff00+$8a]" after the bank-switching
; call) doesn't fit joypad_hook_banked's plain ret/jp tail, so the hook site
; stays hand-placed; JOYPAD_HOOK_VARIANT is declared manually to match what
; joypad_hook_banked would have set.
DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b
DEF JOYPAD_HOOK_VARIANT EQU 1
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1

    free_space_rom0 $1b06, $1b06 + 58
    rom0_code
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    ld a, [$ff00+$8a]       ; joypad read should return value in A
    ret
    end_code


; save/load state — custom relocated_read_from_joypad body (raw bytes),
; see JOYPAD_CUSTOM_RELOCATED_READ above
    free_space_romx $0008, $4001, $4001 + $02a0
    romx_code
    DB "--- Save Patch ---"

relocated_read_from_joypad:
    DB $C5, $0E, $00, $3E, $20, $E2, $F2, $F2, $F2, $47, $3E, $10, $E2, $78, $E6, $0F
    DB $CB, $37, $47, $F2, $F2, $F2, $F2, $F2, $F2, $F2, $F2, $F2, $F2, $F2, $F2, $F2
    DB $F2, $E6, $0F, $B0, $2F, $47, $3E, $30, $E2, $F0, $8A, $A8, $A0, $E0, $8B, $F0
    DB $8A, $E0, $D7, $78, $E0, $8A, $E0, $91, $C1

    push bc
    INCLUDE "src/core/hooks/joypad/check.asm"
    pop bc
    ret

    end_code

SECTION "new bank", ROMX[$4000], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
