; md5 f9445b104ebb70d8fb91c8c64452c0a4

; ROM "Wizards & Warriors Chapter X - The Fortress of Fear (E) [!].gb"
; builds "savestates/Wizards & Warriors Chapter X - The Fortress of Fear (E) [!] (savestates).gb" with _SAVESTATES


; config
DEF current_rom_bank EQU $4000


; reset ram
    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00bc, $00bc + $F
    on_boot_inline reset_ram



; vblank
    savestates_vblank_hook $0004, $126a


; save/load state
    free_space_romx $0004, $4001, $4001 + $02a0

SECTION "new bank", ROMX[$4000], BANK[$0004] ; length: 1
    DB $4
ENDSECTION
