; md5 f9445b104ebb70d8fb91c8c64452c0a4

; ROM "Wizards & Warriors Chapter X - The Fortress of Fear (E) [!].gb"
; builds "Wizards & Warriors Chapter X - The Fortress of Fear (E) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF current_rom_bank EQU $4000


; reset ram
    entry_point $0150
    free_space_rom0 $00bc, $00bc + $F
    on_boot_inline reset_ram



; vblank
    joypad_vblank_hook $0004, $126a


; save/load state
    free_space_romx $0004, $4001, $4001 + $02a0

SECTION "new bank", ROMX[$4000], BANK[$0004] ; length: 1
    DB $4
ENDSECTION
