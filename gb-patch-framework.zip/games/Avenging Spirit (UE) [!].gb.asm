; md5 e88eab57ab4614966748280bf3c97f52

; ROM "Avenging Spirit (UE) [!].gb"
; builds "Avenging Spirit (UE) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ffde
DEF joypad_2 EQU $ffdf
DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a2, $00a2 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0062, $0062 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $04a6


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7B8E, $7B8E + $0220
