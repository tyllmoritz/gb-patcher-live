; md5 e88eab57ab4614966748280bf3c97f52

; ROM "Avenging Spirit (UE) [!].gb"
; builds "savestates/Avenging Spirit (UE) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffde
DEF joypad_2 EQU $ffdf
DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a2, $00a2 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0062, $0062 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $04a6


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7B8E, $7B8E + $0220
