; md5 bc76c0516129c6791e4087f93f5d3c99

; ROM "Battletoads in Ragnarok's World (E) [!].gb"
; builds "savestates/Battletoads in Ragnarok's World (E) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ca03
DEF joypad_2 EQU $ca01
DEF current_rom_bank EQU $4000


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $2e5e, $2e91


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4001, $4001 + $02a0

SECTION "new bank", ROMX[$4000], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
