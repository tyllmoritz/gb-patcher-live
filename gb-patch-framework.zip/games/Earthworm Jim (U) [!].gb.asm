; md5 0d24eeff28040ff2a8f63de5bc8cbea2

; ROM "Earthworm Jim (U) [!].gb"
; builds "Earthworm Jim (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c101
DEF joypad_2 EQU $c102
DEF current_rom_bank EQU $7fff


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $00b6


;*******************
;* save/load state *
;*******************

    free_space_romx $0010, $4000, $4000 + $02a0

SECTION "new bank", ROMX[$7FFF], BANK[$0010] ; length: 1
    DB $10
ENDSECTION
