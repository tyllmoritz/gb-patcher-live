; md5 012ee0a196c03cca91a43a9eadbecfb6

; ROM "Altered Space (U) [!].gb"
; builds "savestates/Altered Space (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c07a
DEF joypad_2 EQU $c07b
DEF current_rom_bank EQU $c0c7


;*************
;* reset ram *
;*************

    entry_point $0964
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00dc, $00dc + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $06cd, $0700


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
