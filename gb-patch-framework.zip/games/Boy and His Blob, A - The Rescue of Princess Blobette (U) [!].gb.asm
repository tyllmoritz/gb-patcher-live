; md5 81f7dee7546e630de075a3397349efb8

; ROM "Boy and His Blob, A - The Rescue of Princess Blobette (U) [!].gb"
; builds "Boy and His Blob, A - The Rescue of Princess Blobette (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF joypad EQU $ffe3
DEF joypad_2 EQU $ffe4
DEF current_rom_bank EQU $c2df


;*************
;* reset ram *
;*************

    entry_point $0185
    free_space_rom0 $0061, $0061 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0000, $0000 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $03c6


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $7D80, $7D80 + $0220
