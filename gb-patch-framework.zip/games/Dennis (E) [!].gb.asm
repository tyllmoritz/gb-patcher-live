; md5 2fa78f748aa9bced4cedd95f330c9a11

; ROM "Dennis (E) [!].gb"
; builds "Dennis (E) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c2bb
DEF current_rom_bank EQU $c2b0


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00ca, $00ca + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0089, $0089 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $28ce


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $7CEB, $7CEB + $0220
