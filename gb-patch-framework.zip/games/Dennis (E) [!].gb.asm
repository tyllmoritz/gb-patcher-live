; md5 2fa78f748aa9bced4cedd95f330c9a11

; ROM "Dennis (E) [!].gb"
; builds "savestates/Dennis (E) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c2bb
DEF current_rom_bank EQU $c2b0


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00ca, $00ca + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0089, $0089 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $28ce


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $7CEB, $7CEB + $0220
