; md5 797580a91cf9dc710c37f5af04dbbca5

; ROM "BreakThru! (U) [!].gb"
; builds "savestates/BreakThru! (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffc8
DEF joypad_2 EQU $ffc9
DEF current_rom_bank EQU $4000


;***************
;* joypad read *
;***************

    free_space_rom0 $00be, $00be + $40

    savestates_joypad_hook $1974


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $56B9, $56B9 + $0220
