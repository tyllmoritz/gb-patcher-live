; md5 b3f3d35f58a0ea3affc0ec6d4ee1183d

; ROM "Alien 3 (UE) [!].gb"
; builds "Alien 3 (UE) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c2bc
DEF joypad_2 EQU $c2bd
DEF current_rom_bank EQU $c2ed
DEF current_nr34_value EQU $c24e


;*************************
;* relocated joypad read *
;*************************

        free_space_rom0 $0080, $0080 + $70
    on_boot_inline reset_ram


;*************
;* reset ram *
;*************

    entry_point $0150


;***************
;* joypad read *
;***************

    joypad_hook $0277
    savestates_marker --- Alien 3 Save Patch ---


;*******************
;* save/load state *
;*******************

    free_space_romx $01, $7C00, $7C00 + $400
