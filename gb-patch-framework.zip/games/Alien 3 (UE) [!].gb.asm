; md5 b3f3d35f58a0ea3affc0ec6d4ee1183d

; ROM "Alien 3 (UE) [!].gb"
; builds "savestates/Alien 3 (UE) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c2bc
DEF joypad_2 EQU $c2bd
DEF current_rom_bank EQU $c2ed
DEF current_nr34_value EQU $c24e


;*************************
;* relocated joypad read *
;*************************

INCLUDE "src/features/savestates/reset_ram.asm"
        free_space_rom0 $0080, $0080 + $70
    on_boot_inline reset_ram


;*************
;* reset ram *
;*************

    entry_point $0150


;***************
;* joypad read *
;***************

    savestates_joypad_hook $0277
    savestates_marker --- Alien 3 Save Patch ---


;*******************
;* save/load state *
;*******************

    free_space_romx $01, $7C00, $7C00 + $400
