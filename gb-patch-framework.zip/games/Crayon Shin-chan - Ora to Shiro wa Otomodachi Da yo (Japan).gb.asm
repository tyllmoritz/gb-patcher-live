; md5 a5d383a5f6e9d61b505429257f2c44c1

; ROM "Crayon Shin-chan - Ora to Shiro wa Otomodachi Da yo (Japan).gb"
; builds "Crayon Shin-chan - Ora to Shiro wa Otomodachi Da yo (Japan) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8d
DEF current_rom_bank EQU $ff90


;*************************
;* relocated joypad read *
;*************************

; relocated_read.asm has a trailing ret beyond its own internal one, so its
; automatic placement is skipped (preserves the exact byte layout); the hook
; site itself still fits joypad_hook's plain ADDR shape exactly.
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    joypad_hook $02e7
    free_space_rom0 $3700, $3700 + $40
    rom0_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    ret
    end_code


;*******************
;* save/load state *
;*******************

    savestates_marker --- XXXXX Save Patch ---
    free_space_romx $01, $77A0, $77A0 + $0220
