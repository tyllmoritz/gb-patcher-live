; md5 239fd20f424ee53d2f11018dbd942df4

; ROM "Boxxle (U) (V1.1) [!].gb"
; builds "savestates/Boxxle (U) (V1.1) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $0160


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $21c7


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $4000, $4000 + $0220
