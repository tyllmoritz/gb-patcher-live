; ------------------------------------------------------------------------------
;           Battery-less patch for Pokemon Crystal Ultimate v1.0.7.5
;                           https://discord.gg/XMYBvDA
;      https://discord.com/channels/430843040308133889/743307521225261117
;    (find old version here: https://www.pokecommunity.com/threads/441959/)
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; ROM "Pokemon - Crystal Ultimate (v1.0.7.5).gbc"
; SHA1 929e752f347ac79e8dbac35980f784b9a661a168
;
; builds "batteryless/Pokemon - Crystal Ultimate (v1.0.7.5) (batteryless).gbc" with _BATTERYLESS
;
; ------------------------------------------------------------------------------

; game properties
DEF sram_size_32kb EQU 1
DEF current_rom_bank EQU $ff9d
DEF flash_data_bank EQU $80

; free space in the original ROM/RAM
    free_space_rom0 $3f90, $4000   ; all-zero padding, verified wider than the old config's $3fb8
    free_space_romx $7f, $7b00, $7e00
    free_space_wram $dd00, $ddab, $5

; the game's `jp` at $0101 goes to $016e
    entry_point $016e

; call site of the game's own save routine ($5:$2e66 CloseSRAM)
    save_hook $05, $4b1a, $2e66
