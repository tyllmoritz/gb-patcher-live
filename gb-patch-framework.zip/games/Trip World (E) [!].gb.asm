; md5 c46e059a69d9b3b4b0b9d8d303c559b3

; ROM "Trip World (E) [!].gb"
; builds "savestates/Trip World (E) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff00+$8b
DEF joypad_2 EQU $ff00+$8c
DEF current_rom_bank EQU $ff00+$9b
DEF current_nr34_value EQU $ffd9


;*************************
;* relocated joypad read *
;*************************

    free_space_rom0 $0, $0 + $40


;***************
;* joypad read *
;***************

    savestates_joypad_hook $26b2
    savestates_marker --- Trip World Save Patch ---


;*******************
;* save/load state *
;*******************

    free_space_romx $04, $7C00, $7C00 + $400
