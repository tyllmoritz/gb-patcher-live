; md5 8f160aa0b2f69a019911fd57ac8c5b31

; ROM "Beavis and Butt-head (U) [!].gb"
; builds "savestates/Beavis and Butt-head (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffe8
DEF joypad_2 EQU $ffe9
DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $2097
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a9, $00a9 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0069, $0069 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $2978


;*******************
;* save/load state *
;*******************

    free_space_romx $001f, $4000, $4000 + $0220
