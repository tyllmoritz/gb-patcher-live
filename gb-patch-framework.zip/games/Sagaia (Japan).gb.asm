; md5 70a9ef90ad443881ca90cdd8d910ae66

; ROM "Sagaia (Japan).gb"
; builds "Sagaia (Japan) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c018
DEF joypad_2 EQU $c019
DEF current_rom_bank EQU $c013


;*************************
;* relocated joypad read *
;*************************

; relocated_read.asm has a trailing ret beyond its own internal one, so its
; automatic placement is skipped (preserves the exact byte layout); the hook
; site itself still fits joypad_hook's plain ADDR shape exactly.
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    joypad_hook $1384
    free_space_rom0 $70, $70 + $40
    rom0_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    ret
    end_code


;*******************
;* save/load state *
;*******************

    savestates_marker --- XXXXX Save Patch ---
    free_space_romx $07, $7310, $7310 + $0255
