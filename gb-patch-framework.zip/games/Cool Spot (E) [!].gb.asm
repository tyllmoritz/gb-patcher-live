; md5 1ddff2c150456069776f8c79671cb9f7

; ROM "Cool Spot (E) [!].gb"
; builds "savestates/Cool Spot (E) [!] (savestates).gb"


;**********
;* config *
;**********

DEF joypad EQU $ff8a
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $db4f


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00dc, $00dc + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

SECTION "joypad read", ROM0[$0bd2] ; length: $20
    INCLUDE "src/features/savestates/call_relocated_read_from_joypad_in_other_bank.asm"

    ; MANUAL EDIT - joypad state must be copied into D register after reading
    ld a,[$ff8a]
    ld d,a

    jp $0bfb
ENDSECTION


;*******************
;* save/load state *
;*******************

SECTION "save/load state", ROMX[$4000], BANK[$0008] ; length: $02a0
    DB "--- Save Patch ---"
    INCLUDE "src/features/savestates/joypad_read_and_check.asm"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
