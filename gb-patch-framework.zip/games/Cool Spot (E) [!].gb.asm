; md5 1ddff2c150456069776f8c79671cb9f7

; ROM "Cool Spot (E) [!].gb"
; builds "Cool Spot (E) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8a
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $db4f


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00dc, $00dc + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

; custom tail (joypad state copied into D register) doesn't fit
; joypad_hook_banked's fixed ret/jp tail, so the hook site stays hand-placed;
; JOYPAD_HOOK_VARIANT is declared manually to match what joypad_hook_banked
; would have set.
DEF JOYPAD_HOOK_VARIANT EQU 1
    free_space_rom0_b $0bd2, $0bd2 + $30
    rom0_code_b
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"

    ; MANUAL EDIT - joypad state must be copied into D register after reading
    ld a,[$ff8a]
    ld d,a

    jp $0bfb
    end_code


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
