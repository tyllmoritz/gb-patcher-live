; md5 80034da43f35307291714ae2553d9ddf

; ROM "Prince of Persia (U).gb"
; builds "savestates/Prince of Persia (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $7fff


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $1167


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0

SECTION "new bank", ROMX[$7FFF], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
