; md5 f07ed24e96f84ce78787709f248263c8

; ROM "Flintstones, The (U) [!].gb"
; builds "Flintstones, The (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ff95


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $0085, $0085 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    joypad_vblank_hook $0062, $036f


;*******************
;* save/load state *
;*******************

    free_space_romx $0010, $4000, $4000 + $02a0
