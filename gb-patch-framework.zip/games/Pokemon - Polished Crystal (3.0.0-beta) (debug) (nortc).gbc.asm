; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; Pokemon Polished Crystal 3.0.0-beta (debug build) by Rangi42
; https://github.com/Rangi42/polishedcrystal
; (the official nortc release build, so no _NORTC feature is needed on top)
;
; ROM "Pokemon - Polished Crystal (3.0.0-beta-22d6f8e1) (debug) (nortc).gbc"
; SHA1 065403a03c260a45347a786fa2cd197c16837b01
;
; builds "batteryless/Pokemon - Polished Crystal (3.0.0-beta) (debug) (nortc) (batteryless).gbc" with _BATTERYLESS
;
; ------------------------------------------------------------------------------

; game properties
DEF sram_size_32kb EQU 1
DEF current_rom_bank EQU $ff93         ; hROMBank
DEF flash_data_bank EQU $74             ; banks $71-$7f are $ff padding (xxd-verified)

; free space in the original ROM/RAM
    free_space_rom0 $3d35, $4000        ; $ff padding to the end of bank 0 (xxd-verified)
    free_space_romx $71, $4000, $8000   ; whole bank is $ff padding (xxd-verified)
; WRAM window from the pre-framework port (found with a debugger there);
; sized to the feature's current footprint — the build asserts on overflow
    free_space_wram $d562, $d562 + $ab, $5

; the entry at $0100 is `nop; jr` to $0177 (not the usual nop+jp) — the
; 3-byte entry hook at $0100 covers it exactly
    entry_point $0177

; the game's save ends in a tail call: `jp CloseSRAM` ($2a60) at $05:$4cc5
    save_hook_jp $05, $4cc5, $2a60
