; md5 ba760b6d4b96baf0fa2e7ad6e4498a95

; ROM "Nemesis II - The Return of the Hero (E) [!].gb"
; builds "Nemesis II - The Return of the Hero (E) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $c7a4


; reset ram
    entry_point $0150
    free_space_rom0 $00cf, $00cf + $F
    on_boot_inline reset_ram



; joypad
DEF joypad EQU $c78e
DEF joypad_2 EQU $c78f
DEF swap_joypad EQU 1

    joypad_hook_banked $00, $0ca8


; save/load state
    free_space_romx $0002, $7A21, $7A21 + $02a0
