; md5 ebd1866dc6c13ca48f45538ed33ea46f

; ROM "Rolan's Curse (U) [!].gb"
; builds "Rolan's Curse (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ff8e


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $c13e
DEF joypad_2 EQU $c13d

    free_space_rom0_b $0062, $0062 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $0a30


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $0220
