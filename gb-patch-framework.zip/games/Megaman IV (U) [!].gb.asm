; md5 8a00f627b8902c92327435901c249e19

; ROM "Megaman IV (U) [!].gb"
; builds "Megaman IV (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $dea1
DEF joypad_2 EQU $dea2
DEF current_rom_bank EQU $df00
DEF current_nr34_value EQU $dc7b


;*************************
;* relocated joypad read *
;*************************

DEF interrupts_already_disabled EQU 1
    joypad_hook $179d
    free_space_rom0 $3ea8, $3ea8 + $58

    patch_rom $00, $0101
    jp $150
    end_patch


;*******************
;* save/load state *
;*******************

    savestates_marker --- Megaman 4 Save Patch ---
    free_space_romx $01, $7D80, $7D80 + $280
