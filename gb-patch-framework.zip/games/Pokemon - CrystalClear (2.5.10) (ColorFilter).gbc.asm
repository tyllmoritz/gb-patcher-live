; ------------------------------------------------------------------------------
;  get CrystalClear_2_5_10_ColorFilter_1_1.bps from https://discord.gg/tskaCr2
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; ROM "Pokemon - CrystalClear (2.5.10) (ColorFilter).gbc"
; SHA1 1a3de02fd0dbad5db0c8151851ecc3c4b96735b1
;
; builds "batteryless/Pokemon - CrystalClear (2.5.10) (ColorFilter) (batteryless).gbc" with _BATTERYLESS
;
; ------------------------------------------------------------------------------

; game properties
DEF sram_size_32kb EQU 1
DEF current_rom_bank EQU $ff9d
DEF flash_data_bank EQU $80

; free space in the original ROM/RAM
    free_space_rom0 $0063, $0100
    free_space_romx $7f, $7a50, $7d50
    free_space_wram $df00, $dfab, $5

; the game's `jp` at $0101 goes to $0383
    entry_point $0383

; three of the four call sites of the game's own save routine ($5:$51dd).
; the old config's 4th site ($21:$6361) is an `ld hl, $51dd` feeding an
; indirect farcall, not a `call` instruction — save_hook can only redirect
; a direct call site, and blindly overwriting a `ld hl, nnnn` with a `call`
; instruction would corrupt whatever uses hl afterwards. Left unhooked
; rather than guessed at; the three direct call sites already cover saving.
    save_hook $05, $505d, $51dd
    save_hook $05, $507a, $51dd
    save_hook $05, $51b4, $51dd
