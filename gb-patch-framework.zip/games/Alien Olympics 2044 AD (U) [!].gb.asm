; md5 d300bf9412617a95b00b80fa468a8a04

; ROM "Alien Olympics 2044 AD (U) [!].gb"
; builds "savestates/Alien Olympics 2044 AD (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff9a
DEF current_rom_bank EQU $c009


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $32e7, $330f


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
