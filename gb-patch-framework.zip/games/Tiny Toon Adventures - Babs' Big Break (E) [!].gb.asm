; md5 cbb45188c780ce5bbdf502ceb2b9994a

; ROM "Tiny Toon Adventures - Babs' Big Break (E) [!].gb"
; builds "Tiny Toon Adventures - Babs' Big Break (E) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF current_rom_bank EQU $015a
DEF calling_from_vblank EQU 1
DEF already_changed_rom_bank EQU 1
DEF interrupts_already_disabled EQU 1


; joypad
; Custom shape: hand-written bank-switch stub (not call_in_other_bank.asm)
; called from a ROMX hook site — same general pattern as Burning Paper.
DEF joypad EQU $c986
DEF joypad_2 EQU $c987
DEF swap_joypad EQU 1
DEF JOYPAD_HOOK_VARIANT EQU 1
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    free_space_rom0 $00f1, $00f1 + 14
    rom0_code
invoke_relocated_read_from_joypad_in_other_bank:
    ld a,BANK(relocated_read_from_joypad)
    ld [$2000],a
    call relocated_read_from_joypad
    ld a, 1         ; joypad read function is in bank 1
    ld [$2000],a
    ret
    end_code

    patch_rom $0001, $4209
    call invoke_relocated_read_from_joypad_in_other_bank
    nop
    end_patch


; save/load state
    free_space_romx $0003, $7D19, $7D19 + $02a0
    romx_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    end_code
