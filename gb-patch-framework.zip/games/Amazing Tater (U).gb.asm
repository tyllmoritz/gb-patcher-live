; md5 53b746bff74c50cd3ebcf41161c66cf3

; ROM "Amazing Tater (U).gb"
; builds "savestates/Amazing Tater (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $c2d3


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $0477


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $5688, $5688 + $0220
