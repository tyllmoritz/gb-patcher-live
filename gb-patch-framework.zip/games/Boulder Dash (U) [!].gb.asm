; md5 800c1a8f99bea585490673352b5f11f4

; ROM "Boulder Dash (U) [!].gb"
; builds "Boulder Dash (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff90
DEF joypad_2 EQU $ff91


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a9, $00a9 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0069, $0069 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $06c5


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $6E0A, $6E0A + $0220
