; ------------------------------------------------------------------------------
;                           Shin Pokemon (Green)
;         find hack here: https://www.romhacking.net/hacks/8189/
;         source: https://github.com/jojobear13/shinpokered
;         patch:  https://github.com/jojobear13/shinpokered/releases/tag/1.24.5
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; ROM "Shin Pokemon (Green) (1.24.5).gbc"
; md5 c0926c6fef49476048ac0e5893e2782a
;
; builds "Shin Pokemon (Green) (1.24.5) (batteryless).gbc" with _BATTERYLESS
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC3_RAM_BAT
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG_GBC
;
; ------------------------------------------------------------------------------

; game properties
; original header: CART_COMPATIBLE_DMG_GBC — save/load code doesn't need CGB-exclusive hardware here, so GB_COMPATIBILITY is left at its
; default (CART_COMPATIBLE_DMG) and the header is untouched
DEF SRAM_SIZE EQU CART_SRAM_32KB
DEF current_rom_bank EQU $ffb9
DEF flash_data_bank EQU $40

; free space in the original ROM/RAM. The RST/interrupt vector table
; ($0000-$0067) is all-zero except a single stray $ff at $0000 in this ROM
; (verified — this hack apparently never uses RST calls or hardware
; interrupts), so it's genuinely free; inherited from the old repo's own
; config, which already shipped a working build using exactly this window.
    free_space_rom0 $0000, $0068
    free_space_romx $3f, $7b00, $7e00
    free_space_wram $c340, $c3eb

; the game's `jp` at $0101 goes to $0150
    entry_point $0150

; call site of the game's own save routine ($1c:$7939)
    save_hook $1c, $7a06, $7939
