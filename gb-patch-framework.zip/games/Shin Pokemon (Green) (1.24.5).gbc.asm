; ------------------------------------------------------------------------------
;                           Shin Pokemon (Green)
;         find hack here: https://www.romhacking.net/hacks/8189/
;         source: https://github.com/jojobear13/shinpokered
;         patch:  https://github.com/jojobear13/shinpokered/releases/tag/1.24.5
; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; ROM "Shin Pokemon (Green) (1.24.5).gbc"
; SHA1 ece5a732cbaaf268b23f9d946b4ad43ae3784440
;
; builds "batteryless/Shin Pokemon (Green) (1.24.5) (batteryless).gbc" with _BATTERYLESS
;
; ------------------------------------------------------------------------------

; game properties
DEF sram_size_32kb EQU 1
DEF current_rom_bank EQU $ffb9
DEF flash_data_bank EQU $40

; free space in the original ROM/RAM. The RST/interrupt vector table
; ($0000-$0067) is all-zero except a single stray $ff at $0000 in this ROM
; (verified — this hack apparently never uses RST calls or hardware
; interrupts), so it's genuinely free; inherited from the old repo's own
; config, which already shipped a working build using exactly this window.
    free_space_rom0 $0000, $0068
    free_space_romx $3f, $7b00, $7e00
    free_space_wram $c340, $c3eb

; the game's `jp` at $0101 goes to $0150
    entry_point $0150

; call site of the game's own save routine ($1c:$7939)
    save_hook $1c, $7a06, $7939
