; md5 d6d8e759c19c1ba384670f2a06b4d11b

; ROM "Battle Bull (U) [!].gb"
; builds "savestates/Battle Bull (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $d501
DEF joypad_2 EQU $d502
DEF current_rom_bank EQU $c14a


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $03b8


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $7D46, $7D46 + $0220
