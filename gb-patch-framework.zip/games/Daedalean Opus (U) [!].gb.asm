; md5 34b3d0f0843b83e5b0e00bc3d0669793

; ROM "Daedalean Opus (U) [!].gb"
; builds "Daedalean Opus (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $d000
DEF joypad_2 EQU $d001
DEF current_rom_bank EQU $0179


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00ea, $00ea + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $00aa, $00aa + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $07a7


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $4000, $4000 + $0220
