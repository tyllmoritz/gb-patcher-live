; md5 9627134ca3ea6e885275d30460ce3563

; ROM "Burger Time Deluxe (JU) [!].gb"
; builds "savestates/Burger Time Deluxe (JU) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffb3
DEF joypad_2 EQU $ffb2
DEF current_rom_bank EQU $ffc7


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0061, $0061 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $027f, $02b3


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $7C38, $7C38 + $300
