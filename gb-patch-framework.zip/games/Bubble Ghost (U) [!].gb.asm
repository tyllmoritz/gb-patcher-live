; md5 7f970d79f06cfb4270dea4b051277098

; ROM "Bubble Ghost (U) [!].gb"
; builds "savestates/Bubble Ghost (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $0180


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $04df


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $4000, $4000 + $220
