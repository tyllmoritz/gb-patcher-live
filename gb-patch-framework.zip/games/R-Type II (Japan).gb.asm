; md5 acac255e33082dde52eee7af941d8681

; ROM "R-Type II (Japan).gb"
; builds "R-Type II (Japan) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $d006
DEF joypad_2 EQU $d007
DEF current_rom_bank EQU $d093


;*************************
;* relocated joypad read *
;*************************

; hook site is only 3 bytes (no trailing nop), which doesn't match
; joypad_hook's fixed 4-byte emission, so it's patched manually;
; JOYPAD_HOOK_VARIANT is declared manually to match what joypad_hook would
; have set. relocated_read.asm has a trailing ret beyond its own internal
; one, so its automatic placement is skipped too (preserves the exact byte
; layout).
DEF JOYPAD_HOOK_VARIANT EQU 0
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    free_space_rom0 $3d20, $3d20 + $40
    rom0_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    ret
    end_code

    patch_rom $00, $637
    call relocated_read_from_joypad
    end_patch


;*******************
;* save/load state *
;*******************

    savestates_marker --- XXXXX Save Patch ---
    free_space_rom0_b $3d80, $3d80 + $0220
    savestates_payload_in_rom0_b
