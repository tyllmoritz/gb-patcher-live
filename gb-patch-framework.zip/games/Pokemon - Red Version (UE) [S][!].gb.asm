; md5 3d45c1ee9abd5738df46d2bdda8b57dc

; ROM "Pokemon - Red Version (UE) [S][!].gb"
; builds "savestates/Pokemon - Red Version (UE) [S][!] (savestates).gb" with _MBC5 _SAVESTATES
; builds "savestates/Pokemon - Red Version (UE) [S][!] (batteryless).gb" with _MBC5 _BATTERYLESS
; builds "savestates/Pokemon - Red Version (UE) [S][!] (batteryless_savestates).gb" with _MBC5 _BATTERYLESS _SAVESTATES

; game info
DEF game_uses_save_ram EQU 1
DEF sram_size_32kb EQU 1

; config
DEF current_rom_bank EQU $ffb8
DEF current_sram_bank EQU $fffd
; batteryless config
DEF flash_data_bank EQU $40             ; first bank past the 1MB ROM
; savestates config
DEF joypad EQU $fff8


; boot hook
entry_point $0150

; regions
free_space_romx $2d, $4000, $8000   ; whole bank is zero padding (xxd-verified)
free_space_rom0 $3fa8, $4000
free_space_rom0_b $00bf, $00bf + $0040
free_space_wram $c300, $c400 ; shadow OAM + Tilemap (glitches sprites for a frame)

IF DEF(_MBC5)
    ; mbc 5 fix
    DEF uses_mbc5 EQU 1
    SECTION "patch rom bank 0 req", ROMX[$6763], BANK[$0001] ; length: $1
        DB $01
    ENDSECTION
ENDC

IF DEF(_SAVESTATES)
    ; batteryless's own boot/save trampolines already claim most of
    ; free_space_rom0 when both features are combined, so the relocated
    ; joypad-read routine (~$40 bytes) goes into the separate rom0_b window
    ; instead of sharing the main pool
    savestates_relocated_read_in_rom0_b
    savestates_joypad_hook $0195
ENDC


IF DEF(_BATTERYLESS)
    save_hook_inline $1c, $7844
        ld [$0000], a                   ; original: ld [rRAMG], a
    end_save_hook_inline
ENDC




; track current sram bank
SECTION "set sram bank", ROM0[$0001] ; length: $0007
set_sram_bank:
    ld [current_sram_bank], a
    ld [$4000], a
    ret
ENDSECTION

SECTION "call set sram bank 1", ROM0[$250d] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 2", ROM0[$169d] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 3", ROM0[$16eb] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 4", ROMX[$60A8], BANK[$0001] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 5", ROMX[$762D], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 6", ROMX[$769A], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 7", ROMX[$76C7], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 8", ROMX[$7ADB], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 9", ROMX[$7796], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 10", ROMX[$77EC], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 11", ROMX[$7819], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 12", ROMX[$791A], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 13", ROMX[$7A35], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 14", ROMX[$7A3D], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 15", ROMX[$7A94], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 16", ROMX[$7A9C], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 17", ROMX[$7B5C], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 18", ROMX[$7B8F], BANK[$001c] ; length: $3
    call set_sram_bank
ENDSECTION
SECTION "call set sram bank 19", ROMX[$6CE1], BANK[$000f] ; length: $3
    call set_sram_bank
ENDSECTION
