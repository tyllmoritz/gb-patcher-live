; md5 c5b36de3dd613b23e2aef7fc4427e5f8

; ROM "Frank Thomas' Big Hurt Baseball (U) [!].gb"
; builds "Frank Thomas' Big Hurt Baseball (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c4f4
DEF joypad_2 EQU $c4f5
DEF current_rom_bank EQU $4000


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $0472, $04a5


;*******************
;* save/load state *
;*******************

    free_space_romx $0014, $58D1, $58D1 + $02a0
