; md5 4859ec2b18c4fabf489eb570c1d7d326

; ROM "Donkey Kong (JU) (V1.1) [S][!].gb"
; builds "Donkey Kong (JU) (V1.1) [S][!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b
DEF SRAM_SIZE EQU CART_SRAM_8KB
;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $0061, $0061 + $40
    joypad_relocated_read_in_rom0_c

    joypad_hook $1052


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $392b, $392b + $0245
    savestates_payload_in_rom0_b
