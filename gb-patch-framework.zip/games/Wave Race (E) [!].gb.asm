; md5 10fd41703b816fcb2a3d6766574b98f9

; ROM "Wave Race (E) [!].gb"
; builds "savestates/Wave Race (E) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $ffa4


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00b6, $00b6 + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $caf6
DEF joypad_2 EQU $caf7

    free_space_rom0_b $0075, $0075 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $07be


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220
