; md5 10fd41703b816fcb2a3d6766574b98f9

; ROM "Wave Race (E) [!].gb"
; builds "Wave Race (E) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC2_BAT
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ffa4


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00b6, $00b6 + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $caf6
DEF joypad_2 EQU $caf7

    free_space_rom0_b $0075, $0075 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $07be


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220
