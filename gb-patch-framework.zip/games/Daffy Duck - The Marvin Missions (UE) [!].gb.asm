; md5 f1dbc21b1b8f8dcbe9a15bc9ef68fb9c

; ROM "Daffy Duck - The Marvin Missions (UE) [!].gb"
; builds "Daffy Duck - The Marvin Missions (UE) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ffa0


;**********
;* vblank *
;**********

    joypad_vblank_hook $0079, $0719


;*******************
;* save/load state *
;*******************

    free_space_romx $0006, $7CC8, $7CC8 + $02a0
