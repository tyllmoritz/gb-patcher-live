; md5 insert-md5-hash

; ROM "insert-rom-file-name"
; builds "insert-output-file-name" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $tttt
DEF joypad_2 EQU $ssss          ; delete if the game has no second copy
DEF current_rom_bank EQU $iiii  ; delete if the game never bank-switches
                                ; during the save/load path


;*************
;* reset ram *
;*************

; delete this whole block if the game clears its internal RAM itself
; (RESET_RAM_DONE of pre-macro-API configs = the entry_point value)
    entry_point $0150
    free_space_rom0 $0080, $0080 + $F
    on_boot_inline reset_ram


;***************
;* joypad read *
;***************

; standard variant: the game's joypad read ends with a short, freely
; overwritable tail (see docs/HOW-TO.md). Needs its own ~$40 bytes of ROM0
; free space, disjoint from the reset_ram region above — delete the
; free_space_rom0_b/joypad_relocated_read_in_rom0_b lines below only if
; the two windows happen to be adjacent, in which case widen the single
; free_space_rom0 declaration above instead and drop joypad_hook's
; second line.
    free_space_rom0_b $0100, $0100 + $40
    joypad_relocated_read_in_rom0_b
    joypad_hook $qqqq

; banked variant instead, for games with no ROM0 free space at all:
;     DEF current_rom_bank EQU $iiii
;     joypad_hook_banked $bb, $qqqq


;*******************
;* save/load state *
;*******************

; ~$220 bytes ($315 for CGB games, add `DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC` above)
    free_space_romx $zz, $xxxx, $xxxx + $220
