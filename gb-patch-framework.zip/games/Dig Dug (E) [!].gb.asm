; md5 c4801ac17a34635fdce973354e85faef

; ROM "Dig Dug (E) [!].gb"
; builds "savestates/Dig Dug (E) [!] (savestates).gb"


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0061, $0061 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

SECTION "relocated read from joypad", ROM0[$0000] ; length: $40
    INCLUDE "src/features/savestates/relocated_read_from_joypad.asm"
ENDSECTION

SECTION "joypad read", ROM0[$18d9] ; length: 5
    call relocated_read_from_joypad
    nop
    nop
ENDSECTION


;*******************
;* save/load state *
;*******************

SECTION "save/load state", ROMX[$741F], BANK[$0001] ; length: $220
    DB "--- Save Patch ---"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
