; md5 84ff06249f96442626cdd75a5fa440ce

; ROM "Animaniacs (U) [S][!].gb"
; builds "savestates/Animaniacs (U) [S][!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $ff94


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0024, $0024 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    savestates_vblank_hook $0001, $0ede


;*******************
;* save/load state *
;*******************

    free_space_romx $0010, $4000, $4000 + $02a0
