; md5 84ff06249f96442626cdd75a5fa440ce

; ROM "Animaniacs (U) [S][!].gb"
; builds "Animaniacs (U) [S][!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ff94


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $0024, $0024 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    joypad_vblank_hook $0001, $0ede


;*******************
;* save/load state *
;*******************

    free_space_romx $0010, $4000, $4000 + $02a0
