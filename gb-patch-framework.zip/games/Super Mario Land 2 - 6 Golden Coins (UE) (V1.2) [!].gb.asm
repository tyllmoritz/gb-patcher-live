; md5 4bd6e929ec716a5c7fe7dc684860d551

; ROM "Super Mario Land 2 - 6 Golden Coins (UE) (V1.2) [!].gb"
; builds "savestates/Super Mario Land 2 - 6 Golden Coins (UE) (V1.2) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff00+$80
DEF joypad_2 EQU $ff00+$81
DEF current_rom_bank EQU $a24e
DEF current_nr34_value EQU $a43a
DEF game_uses_save_ram EQU 1


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $1fda


;*******************
;* save/load state *
;*******************

    free_space_romx $1d, $7800, $7800 + $600
    savestates_marker --- Super Mario Land 2 Save Patch ---
