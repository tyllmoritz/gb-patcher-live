; md5 b259feb41811c7e4e1dc200167985c84

; ROM "Super Mario Land (W) (V1.1) [!].gb"
; builds "savestates/Super Mario Land (W) (V1.1) [!] (savestates).gb"


;**********
;* config *
;**********

DEF joypad EQU $ff00+$80
DEF joypad_2 EQU $ff00+$81
DEF current_nr34_value EQU $df3a


;*****************************
;* relocated joypad read via *
;*****************************

SECTION "relocated read from joypad via", ROM0[$000b] ; length: $14
    INCLUDE "src/features/savestates/check_for_save_or_load_via_bank_0.asm"
ENDSECTION


;*************************
;* relocated joypad read *
;*************************

SECTION "relocated read from joypad", ROMX[$7FB0], BANK[$03] ; length: $30
    DEF check_for_save_or_load_via_bank_0 EQU 1
    INCLUDE "src/features/savestates/relocated_read_from_joypad.asm"
ENDSECTION


;*************
;* reset ram *
;*************

INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00f1, $00f1 + $F
    on_boot_inline reset_ram

    entry_point $0150


;***************
;* joypad read *
;***************

SECTION "joypad read", ROMX[$481E], BANK[$03] ; length: 4
    call relocated_read_from_joypad
    nop
ENDSECTION


;*******************
;* save/load state *
;*******************

SECTION "save/load state", ROMX[$7DC5], BANK[$01] ; length: $239
; no space    DB "--- Super Mario Land Save Patch ---"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
