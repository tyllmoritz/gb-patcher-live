; md5 b259feb41811c7e4e1dc200167985c84

; ROM "Super Mario Land (W) (V1.1) [!].gb"
; builds "Super Mario Land (W) (V1.1) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff00+$80
DEF joypad_2 EQU $ff00+$81
DEF current_nr34_value EQU $df3a


;*************
;* reset ram *
;*************

    free_space_rom0 $00f1, $00f1 + $F
    on_boot_inline reset_ram

    entry_point $0150


;*****************************
;* relocated joypad read via *
;*****************************

    free_space_rom0_b $000b, $000b + $14
    rom0_code_b
    INCLUDE "src/features/savestates/check_for_save_or_load_via_bank_0.asm"
    end_code


;*************************
;* relocated joypad read *
;*************************

; Both the hook site and relocated_read_from_joypad live in ROMX bank 3 (not
; the usual ROM0), calling back into the save/load payload's own bank (1)
; via the via_bank_0 stub above, so this doesn't fit joypad_hook's assumed
; ROM0 placement; both are hand-placed and JOYPAD_CUSTOM_RELOCATED_READ
; skips the framework's automatic relocated-read placement. No room for a
; save-patch marker in this game's tight free-space budget (its own legacy
; comment: "no space"), so SAVESTATES_MARKER is set to empty directly.
DEF JOYPAD_HOOK_VARIANT EQU 0
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
DEF SAVESTATES_MARKER EQUS ""
    patch_rom $03, $7FB0
    DEF check_for_save_or_load_via_bank_0 EQU 1
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    end_patch

    patch_rom $03, $481E
    call relocated_read_from_joypad
    nop
    end_patch


;*******************
;* save/load state *
;*******************

    free_space_romx $01, $7DC5, $7DC5 + $239
