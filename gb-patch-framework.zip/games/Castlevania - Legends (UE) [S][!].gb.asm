; md5 1475824e7262c0d6359f43c287e034a5

; ROM "Castlevania - Legends (UE) [S][!].gb"
; builds "savestates/Castlevania - Legends (UE) [S][!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c553
DEF joypad_2 EQU $c555
DEF swap_joypad EQU 1


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00eb, $00eb + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $00ab, $00ab + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $046c


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $3996, $3996 + $220
    savestates_payload_in_rom0_b
