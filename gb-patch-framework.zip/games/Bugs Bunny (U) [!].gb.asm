; md5 43189b859c0036119f233d46b1f2e9fd

; ROM "Bugs Bunny (U) [!].gb"
; builds "savestates/Bugs Bunny (U) [!] (savestates).gb" with _SAVESTATES


; config
DEF current_rom_bank EQU $ffcb


; reset ram
    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00c4, $00c4 + $F
    on_boot_inline reset_ram



; vblank
    savestates_vblank_hook $000c, $01a2


; save/load state
    free_space_romx $0001, $7AED, $7AED + $02a0
