; md5 cfc7edbc95e8df5305d117c6993d5f20

; ROM "Fire Fighter (U).gb"
; builds "Fire Fighter (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c2aa
DEF joypad_2 EQU $c2a7
DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a4, $00a4 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0063, $0063 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $0936


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7C57, $7C57 + $0220
