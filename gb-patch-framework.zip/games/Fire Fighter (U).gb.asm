; md5 cfc7edbc95e8df5305d117c6993d5f20

; ROM "Fire Fighter (U).gb"
; builds "savestates/Fire Fighter (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c2aa
DEF joypad_2 EQU $c2a7
DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a4, $00a4 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0063, $0063 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $0936


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7C57, $7C57 + $0220
