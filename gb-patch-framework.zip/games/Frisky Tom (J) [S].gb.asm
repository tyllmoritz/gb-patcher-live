; md5 f49fef0c5cc023462d7f84286dc19976

; ROM "Frisky Tom (J) [S].gb"
; builds "Frisky Tom (J) [S] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c007
DEF swap_joypad EQU 1
DEF cpl_joypad EQU 1


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $0062, $0062 + $40
    joypad_relocated_read_in_rom0_c

    joypad_hook $12a3


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $33cb, $33cb + $0220
    savestates_payload_in_rom0_b
