; md5 f49fef0c5cc023462d7f84286dc19976

; ROM "Frisky Tom (J) [S].gb"
; builds "savestates/Frisky Tom (J) [S] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c007
DEF swap_joypad EQU 1
DEF cpl_joypad EQU 1


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $0062, $0062 + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $12a3


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $33cb, $33cb + $0220
    savestates_payload_in_rom0_b
