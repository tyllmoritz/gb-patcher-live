; md5 211a15218fa66e4a09bc253ae064991c

; ROM "Defender-Joust (U) [S][!].gb"
; builds "savestates/Defender-Joust (U) [S][!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffbe
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $0181
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00b9, $00b9 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0079, $0079 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $0add


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220

SECTION "new bank", ROMX[$7FFF], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
