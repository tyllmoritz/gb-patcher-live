; md5 211a15218fa66e4a09bc253ae064991c

; ROM "Defender-Joust (U) [S][!].gb"
; builds "Defender-Joust (U) [S][!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ffbe
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $7fff


;*************
;* reset ram *
;*************

    entry_point $0181
    free_space_rom0 $00b9, $00b9 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0079, $0079 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $0add


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220

SECTION "new bank", ROMX[$7FFF], BANK[$0008] ; length: 1
    DB $8
ENDSECTION
