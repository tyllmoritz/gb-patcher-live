; md5 2bb0df1b672253aaa5f9caf9aab78224

; ROM "Final Fantasy Legend II (U) [!].gb"
; builds "savestates/Final Fantasy Legend II (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff89
DEF current_rom_bank EQU $ff88
DEF game_uses_save_ram EQU 1


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $172e, $174e


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $4343, $4343 + $02c5
