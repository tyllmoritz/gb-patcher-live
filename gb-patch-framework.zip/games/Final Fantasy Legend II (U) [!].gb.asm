; md5 2bb0df1b672253aaa5f9caf9aab78224

; ROM "Final Fantasy Legend II (U) [!].gb"
; builds "Final Fantasy Legend II (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff89
DEF current_rom_bank EQU $ff88
DEF SRAM_SIZE EQU CART_SRAM_8KB
;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $172e, $174e


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $4343, $4343 + $02c5
