; md5 05d5cf3404868efc22ac06e22ab5ba89

; ROM "Pop 'N TwinBee (E) [!].gb"
; builds "Pop 'N TwinBee (E) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $d806
DEF joypad_2 EQU $d807
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $7fff
DEF restore_wave_ram EQU 1


;*************************
;* relocated joypad read *
;*************************

; Custom shape: the ROMX hook site calls a ROM0 stub that bank-switches to
; relocated_read_from_joypad, which lives in the save/load payload's own
; ROMX bank — see Burning Paper for the same pattern.
DEF JOYPAD_HOOK_VARIANT EQU 1
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    free_space_rom0 $00b0, $00b0 + $30
    rom0_code
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    ret
    end_code


;***************
;* joypad read *
;***************

    patch_rom $01, $7112
    call invoke_relocated_read_from_joypad_in_other_bank
    nop
    end_patch


;*******************
;* save/load state *
;*******************

    savestates_marker --- Pop'n TwinBee Save Patch ---
    free_space_romx $08, $4000, $4000 + $4000
    romx_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    end_code

SECTION "bank 8", ROMX[$7FFF], BANK[$08] ; length: 1
    DB $8
ENDSECTION
