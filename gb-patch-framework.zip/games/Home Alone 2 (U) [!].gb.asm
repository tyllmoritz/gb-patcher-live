; md5 0611b365116b22c1aaa7e3ce4faed5ed

; ROM "Home Alone 2 (U) [!].gb"
; builds "savestates/Home Alone 2 (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8c


;*************
;* reset ram *
;*************

    entry_point $0444
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00ad, $00ad + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $006c, $006c + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $05f9


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $3cdd, $3cdd + $0220
    savestates_payload_in_rom0_b
