; md5 6993211741eea010f51b1c20b05d4c43

; ROM "Home Alone (U) [!].gb"
; builds "savestates/Home Alone (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffb3
DEF joypad_2 EQU $ffb4
DEF current_rom_bank EQU $c182


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0062, $0062 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $101e


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $756D, $756D + $0220
