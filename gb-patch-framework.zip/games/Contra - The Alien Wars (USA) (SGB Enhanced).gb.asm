; md5 8d885e185ad2a0cb5c9e3b152bd24583

; ROM "Contra - The Alien Wars (USA) (SGB Enhanced).gb"
; builds "Contra - The Alien Wars (USA) (SGB Enhanced) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF joypad EQU $ffec
DEF joypad_2 EQU $ffeb
DEF read_joypad_value_from_b_register EQU 1
DEF current_rom_bank EQU $ff8c


;*************************
;* relocated joypad read *
;*************************

; hook site is only 3 bytes (no trailing nop), which doesn't match
; joypad_hook's fixed 4-byte "call relocated_read_from_joypad / nop"
; emission, so it's patched manually; JOYPAD_HOOK_VARIANT is declared
; manually to match what joypad_hook would have set.
DEF JOYPAD_HOOK_VARIANT EQU 0
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    free_space_rom0 $6a, $6a + $40
    rom0_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    ret
    end_code

    patch_rom $00, $0744
    call relocated_read_from_joypad
    end_patch


;*******************
;* save/load state *
;*******************

    savestates_marker --- XXXXX Save Patch ---
    free_space_romx $08, $4000, $4000 + $0220

SECTION "bank 8", ROMX[$7FFF], BANK[$08] ; length: 1
    DB $8
ENDSECTION
