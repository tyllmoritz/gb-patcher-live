; md5 b48161623f12f86fec88320166a21fce

; ROM "Super Mario Land (W) (V1.0) [!].gb"
; builds "Super Mario Land (W) (V1.0) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $0159


; joypad
; Custom shape: the ROMX hook site calls a ROM0 stub that bank-switches to
; relocated_read_from_joypad, which lives in the save/load payload's own
; ROMX bank — see Burning Paper for the same pattern.
DEF joypad EQU $ff80
DEF joypad_2 EQU $ff81
DEF JOYPAD_HOOK_VARIANT EQU 1
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    free_space_rom0 $000c, $000c + 40
    rom0_code
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    ret
    end_code

    patch_rom $0003, $481E
    call invoke_relocated_read_from_joypad_in_other_bank
    nop
    end_patch


; save/load state
    free_space_romx $0004, $4000, $4000 + $02a0
    romx_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    end_code
