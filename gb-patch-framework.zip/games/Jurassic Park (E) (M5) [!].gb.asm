; md5 7173cecc94bcdb7aeb7240ae87491044

; ROM "Jurassic Park (E) (M5) [!].gb"
; builds "savestates/Jurassic Park (E) (M5) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff9c
DEF current_rom_bank EQU $ff91
DEF swap_joypad EQU 1
DEF current_nr34_value EQU $decb


;*************************
;* relocated joypad read *
;*************************

INCLUDE "src/features/savestates/reset_ram.asm"
        free_space_rom0 $0080, $0080 + $70
    on_boot_inline reset_ram


;*************
;* reset ram *
;*************

    entry_point $01d8


;***************
;* joypad read *
;***************

    savestates_joypad_hook $15fc
    savestates_marker --- Jurassic Park Save Patch ---


;*******************
;* save/load state *
;*******************

    free_space_romx $0e, $4A00, $4A00 + $1000
