; md5 7d76d2a9eaada93dc846efe1b2a815cc

; ROM "Kenyuu Densetsu Yaiba (Japan).gb"
; builds "Kenyuu Densetsu Yaiba (Japan) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $fffa
DEF joypad_2 EQU $fffb
DEF current_rom_bank EQU $ffc7


;*************************
;* relocated joypad read *
;*************************

; hook site is 8 bytes (5 trailing nops), which doesn't match joypad_hook's
; fixed 4-byte emission, so it's patched manually; JOYPAD_HOOK_VARIANT is
; declared manually to match what joypad_hook would have set.
; relocated_read.asm has a trailing ret beyond its own internal one, so its
; automatic placement is skipped too (preserves the exact byte layout).
DEF JOYPAD_HOOK_VARIANT EQU 0
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    free_space_rom0 $3ea0, $3ea0 + $40
    rom0_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    ret
    end_code

    patch_rom $00, $0af7
    call relocated_read_from_joypad
    nop
    nop
    nop
    nop
    nop
    end_patch


;*******************
;* save/load state *
;*******************

    savestates_marker --- XXXXX Save Patch ---
    free_space_romx $01, $4C00, $4C00 + $300
