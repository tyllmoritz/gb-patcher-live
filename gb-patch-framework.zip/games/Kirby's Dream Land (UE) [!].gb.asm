; md5 a66e4918edcd042ec171a57fe3ce36c3

; ROM "Kirby's Dream Land (UE) [!].gb"
; builds "savestates/Kirby's Dream Land (UE) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $d04f
DEF joypad_2 EQU $ff00+$8b
DEF current_rom_bank EQU $d02c
DEF current_nr34_value EQU $de14


;*************************
;* relocated joypad read *
;*************************

    free_space_rom0 $0080, $0080 + $70


;***************
;* joypad read *
;***************

    savestates_joypad_hook $06e7
    savestates_marker --- Kirby's Dream Land Save Patch ---


;*********************************
;* remap title screen key combos *
;*********************************

SECTION "configuration mode", ROMX[$4083], BANK[$06] ; length: 1
    DB $82  ; use "down + b" instead of "select + down + b"
ENDSECTION
SECTION "extra game", ROMX[$4088], BANK[$06] ; length: 1
    DB $41  ; use "up + a" instead of "select + up + a"
ENDSECTION


;*******************
;* save/load state *
;*******************

    free_space_romx $0f, $7D00, $7D00 + $2e0
