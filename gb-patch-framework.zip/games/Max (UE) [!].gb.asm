; md5 660a98b774e7d136e302dfe6557405e9

; ROM "Max (UE) [!].gb"
; builds "savestates/Max (UE) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $c0a0


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $0026, $0026 + $F
    on_boot_inline reset_ram



;**********
;* joypad *
;**********

DEF joypad EQU $c136
DEF joypad_2 EQU $c137

    savestates_joypad_hook_banked $00, $138a, $13c1


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $02a0
