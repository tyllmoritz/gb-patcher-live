; md5 b9df0bb1f84333a1e5ab4af563525cdc

; ROM "Baby T-Rex (E) [!].gb"
; builds "Baby T-Rex (E) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b
DEF current_rom_bank EQU $ffb1


;*************
;* reset ram *
;*************

    entry_point $0158
    free_space_rom0 $00a9, $00a9 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0069, $0069 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $0432


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220
