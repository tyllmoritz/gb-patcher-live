; md5 b9df0bb1f84333a1e5ab4af563525cdc

; ROM "Baby T-Rex (E) [!].gb"
; builds "savestates/Baby T-Rex (E) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b
DEF current_rom_bank EQU $ffb1


;*************
;* reset ram *
;*************

    entry_point $0158
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a9, $00a9 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0069, $0069 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $0432


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $0220
