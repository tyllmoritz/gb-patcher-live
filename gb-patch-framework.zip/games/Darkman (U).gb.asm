; md5 849c5fe4002dd4240020e9ec84c8dc29

; ROM "Darkman (U).gb"
; builds "savestates/Darkman (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $ffc0


;**********
;* vblank *
;**********

    savestates_vblank_hook $0001, $3dfe


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $7532, $7532 + $02a0
