; md5 849c5fe4002dd4240020e9ec84c8dc29

; ROM "Darkman (U).gb"
; builds "Darkman (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $ffc0


;**********
;* vblank *
;**********

    joypad_vblank_hook $0001, $3dfe


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $7532, $7532 + $02a0
