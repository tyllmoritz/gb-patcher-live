; md5 857fdafb5ababd641cc832cfb8fabd58

; ROM "Extra Bases! (U) [!].gb"
; builds "Extra Bases! (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ffb4
DEF current_rom_bank EQU $ffaa


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $02c7


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $78A0, $78A0 + $0220
