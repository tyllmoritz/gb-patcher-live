; md5 03ce24437224ff296a71f402663a0ee9

; ROM "Castle Quest (U) [!].gb"
; builds "Castle Quest (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF joypad EQU $ffd9
DEF current_rom_bank EQU $c000


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $0029, $0029 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $01d2, $01fa


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $7B04, $7B04 + $02a0
