; md5 f7caa11fcb8be738e1fd584ac8aad215

; ROM "F-1 Spirit (J) [!].gb"
; builds "savestates/F-1 Spirit (J) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c099
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $c0d4


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $09fa


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
