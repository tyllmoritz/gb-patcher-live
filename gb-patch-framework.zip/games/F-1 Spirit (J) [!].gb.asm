; md5 f7caa11fcb8be738e1fd584ac8aad215

; ROM "F-1 Spirit (J) [!].gb"
; builds "F-1 Spirit (J) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $c099
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $c0d4


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $09fa


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
