; md5 946a4a60bbd5328ca2250d5f9f0606c7

; ROM "Super Mario Land 2 DX - 6 Golden Coins (UE) (V1.0) (V1.8.1).gbc"
; builds "Super Mario Land 2 DX - 6 Golden Coins (UE) (V1.0) (V1.8.1) (savestates).gbc" with _SAVESTATES


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $a24e
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT
DEF restore_wave_ram EQU 1


;**********
;* joypad *
;**********

DEF joypad EQU $ff80
DEF joypad_2 EQU $ff81

    joypad_hook_banked $00, $1fd7


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $6541, $6541 + $0305
