; md5 57726c28dc09949029a154f63b891dd0

; ROM "Addams Family, The - Pugsley's Scavenger Hunt (U).gb"
; builds "Addams Family, The - Pugsley's Scavenger Hunt (U) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff9a
DEF current_rom_bank EQU $c144


;*************
;* reset ram *
;*************

    entry_point $0158
    free_space_rom0 $00cf, $00cf + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $08c1, $08e9


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
