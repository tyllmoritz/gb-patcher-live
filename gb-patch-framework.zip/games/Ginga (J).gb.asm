; md5 49eff735e839f8a57f75afcbf2c11ae4

; ROM "Ginga (J).gb"
; builds "savestates/Ginga (J) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $ff97


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0062, $0062 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $0266


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $79C8, $79C8 + $0220
