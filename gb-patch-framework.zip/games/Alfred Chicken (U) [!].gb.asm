; md5 cac921f8eec70d5ccd8a2db8f473a084

; ROM "Alfred Chicken (U) [!].gb"
; builds "Alfred Chicken (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff90
DEF current_rom_bank EQU $ff91


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $1d08


;*******************
;* save/load state *
;*******************

    free_space_romx $0005, $7DBC, $7DBC + $0220
