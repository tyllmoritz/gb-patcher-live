; md5 cac921f8eec70d5ccd8a2db8f473a084

; ROM "Alfred Chicken (U) [!].gb"
; builds "savestates/Alfred Chicken (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff90
DEF current_rom_bank EQU $ff91


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $1d08


;*******************
;* save/load state *
;*******************

    free_space_romx $0005, $7DBC, $7DBC + $0220
