; md5 ed2444afe317452e29c1c2258da6963c

; ROM "Adventure Island II (UE) [!].gb"
; builds "Adventure Island II (UE) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c
DEF current_rom_bank EQU $4000


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a1, $00a1 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0061, $0061 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $036e


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $7625, $7625 + $220
