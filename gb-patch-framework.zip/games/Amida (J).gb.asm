; md5 9642b7c599b47135cbd4e45e039d608d

; ROM "Amida (J).gb"
; builds "Amida (J) (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $0156


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $0025, $0025 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    joypad_vblank_hook $0002, $0d44


;*******************
;* save/load state *
;*******************

    free_space_romx $0002, $4000, $4000 + $02a0
