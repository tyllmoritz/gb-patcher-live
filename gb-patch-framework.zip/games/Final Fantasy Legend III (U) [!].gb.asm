; md5 db156bc96b528996ce1bf771195171af

; ROM "Final Fantasy Legend III (U) [!].gb"
; builds "Final Fantasy Legend III (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b
DEF current_rom_bank EQU $c0b1
DEF SRAM_SIZE EQU CART_SRAM_8KB
;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $36f6


;*******************
;* save/load state *
;*******************

    free_space_romx $0010, $4000, $4000 + $02c5
