; md5 db156bc96b528996ce1bf771195171af

; ROM "Final Fantasy Legend III (U) [!].gb"
; builds "savestates/Final Fantasy Legend III (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8a
DEF joypad_2 EQU $ff8b
DEF current_rom_bank EQU $c0b1
DEF game_uses_save_ram EQU 1


;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $36f6


;*******************
;* save/load state *
;*******************

    free_space_romx $0010, $4000, $4000 + $02c5
