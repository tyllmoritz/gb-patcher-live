; md5 119bdf89bdf38e489facd79cf251ccd0

; ROM "Super Mario Land DX (v2.0).gbc"
; builds "Super Mario Land DX (v2.0) (savestates).gbc" with _SAVESTATES


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $0159
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT


; joypad
; Custom shape: the ROMX hook site calls a ROM0 stub that bank-switches to
; relocated_read_from_joypad, which lives in the save/load payload's own
; ROMX bank — see Burning Paper for the same pattern.
DEF joypad EQU $ff80
DEF joypad_2 EQU $ff81
DEF JOYPAD_HOOK_VARIANT EQU 1
DEF JOYPAD_CUSTOM_RELOCATED_READ EQU 1
    free_space_rom0 $3fd0, $3fd0 + 40
    rom0_code
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"
    ret
    end_code

    patch_rom $0003, $481E
    call invoke_relocated_read_from_joypad_in_other_bank
    nop
    end_patch


; save/load state
    free_space_romx $0004, $6BDA, $6BDA + $0315
    romx_code
    INCLUDE "src/core/hooks/joypad/relocated_read.asm"
    end_code
