; md5 89bb0d67d5af35c2ebf09d9aef2e34ad

; ROM "Donkey Kong Land (U) [S][!].gb"
; builds "Donkey Kong Land (U) [S][!] (savestates).gb" with _MBC5 _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ca03
DEF joypad_2 EQU $ca01
DEF current_rom_bank EQU $4000
DEF preserve_registers EQU 1
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1_RAM_BAT
; deliberately targets MBC5 (not the ROM's real original header type)
; — the save-state payload's bank placement, or a bootleg-flash-cart
; requirement, needs MBC5's addressing; CHANGE_CARTRIDGE_TYPE forces
; the header patch since the real original isn't already MBC5
IF DEF(_MBC5)
    DEF CHANGE_CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT
ENDC
DEF restore_wave_ram EQU 1


;***************
;* joypad read *
;***************

; custom tail doesn't fit joypad_hook_banked's fixed ret/jp tail, so the hook
; site stays hand-placed; JOYPAD_HOOK_VARIANT is declared manually to match
; what joypad_hook_banked would have set.
DEF JOYPAD_HOOK_VARIANT EQU 1
    free_space_rom0 $1d86, $1d86 + $32
    rom0_code
    INCLUDE "src/core/hooks/joypad/call_in_other_bank.asm"

    ld a, [$ca03]
    ld c,a
    jp $1db9
    end_code


;*******************
;* save/load state *
;*******************

    savestates_marker --- Donkey Kong Land Save Patch ---
    free_space_romx $20, $4000, $4000 + $4000
    romx_code
    DB $20   ; rom bank number
    end_code
