; md5 bf4e4002ffa88b9be2c8b8a5b4cd9a48

; ROM "International Superstar Soccer (U) [S].gb"
; builds "International Superstar Soccer (U) [S] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $c002


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00cb, $00cb + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    joypad_vblank_hook $00a8, $0068


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $2bd2, $2bd2 + $02a0
    savestates_payload_in_rom0_b
