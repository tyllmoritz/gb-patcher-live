; md5 bf4e4002ffa88b9be2c8b8a5b4cd9a48

; ROM "International Superstar Soccer (U) [S].gb"
; builds "savestates/International Superstar Soccer (U) [S] (savestates).gb"


;**********
;* config *
;**********

DEF current_rom_bank EQU $c002


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00cb, $00cb + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

DEF vblank_handler EQU $00a8
DEF original_vblank_handler EQU $0068
INCLUDE "src/features/savestates/vblank_handler.asm"


;*******************
;* save/load state *
;*******************

SECTION "save/load state", ROM0[$2bd2] ; length: $02a0
    DB "--- Save Patch ---"
    INCLUDE "src/features/savestates/joypad_read_and_check.asm"
    INCLUDE "src/features/savestates/legacy_includes.asm"
ENDSECTION
