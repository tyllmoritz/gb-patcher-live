; md5 9c1efb1bd07fd91765f680e7e9bc44f1

; ROM "Hudson Hawk (U) [!].gb"
; builds "Hudson Hawk (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $de04
DEF joypad_2 EQU $de07
DEF joypad_3 EQU $de06
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $de0c


;***************
;* joypad read *
;***************

    joypad_hook_banked $00, $38d4, $3911


;*******************
;* save/load state *
;*******************

    free_space_romx $0008, $4000, $4000 + $02a0
