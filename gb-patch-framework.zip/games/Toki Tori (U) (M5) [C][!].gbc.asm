; md5 e1bf59102bcd5e3601f4b24b3e873fd2

; ROM "Toki Tori (U) (M5) [C][!].gbc"
; builds "Toki Tori (U) (M5) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $4000
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT


; joypad
DEF joypad EQU $c535
DEF joypad_2 EQU $c536

    joypad_hook_banked $00, $35ee


; save/load state
    free_space_romx $0001, $6EAE, $6EAE + $0315
