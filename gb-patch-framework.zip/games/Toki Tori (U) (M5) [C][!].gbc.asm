; md5 e1bf59102bcd5e3601f4b24b3e873fd2

; ROM "Toki Tori (U) (M5) [C][!].gbc"
; builds "savestates/Toki Tori (U) (M5) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF is_cgb EQU 1
DEF current_rom_bank EQU $4000
DEF game_uses_save_ram EQU 1
DEF uses_mbc5 EQU 1


; joypad
DEF joypad EQU $c535
DEF joypad_2 EQU $c536

    savestates_joypad_hook_banked $00, $35ee


; save/load state
    free_space_romx $0001, $6EAE, $6EAE + $0315
