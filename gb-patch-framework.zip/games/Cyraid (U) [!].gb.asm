; md5 e55ecbd33d5813fe6e9a4ca1d04e9f15

; ROM "Cyraid (U) [!].gb"
; builds "Cyraid (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF current_rom_bank EQU $c152


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $3ee9, $3ee9 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    joypad_vblank_hook $3ec6, $0f95


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $02a0
