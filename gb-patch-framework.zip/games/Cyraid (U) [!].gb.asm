; md5 e55ecbd33d5813fe6e9a4ca1d04e9f15

; ROM "Cyraid (U) [!].gb"
; builds "savestates/Cyraid (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF current_rom_bank EQU $c152


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $3ee9, $3ee9 + $F
    on_boot_inline reset_ram



;**********
;* vblank *
;**********

    savestates_vblank_hook $3ec6, $0f95


;*******************
;* save/load state *
;*******************

    free_space_romx $0004, $4000, $4000 + $02a0
