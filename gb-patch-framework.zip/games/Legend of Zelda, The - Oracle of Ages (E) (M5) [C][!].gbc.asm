; md5 825de040ea4dff66661693f8712b1bdb

; ROM "Legend of Zelda, The - Oracle of Ages (E) (M5) [C][!].gbc"
; builds "Legend of Zelda, The - Oracle of Ages (E) (M5) [C][!] (savestates).gbc" with _SAVESTATES


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $ffd8
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM_BAT


; joypad
DEF joypad EQU $c481
DEF joypad_2 EQU $c480
DEF joypad_3 EQU $c482

; hook site is only 3 bytes (no trailing nop), which doesn't match
; joypad_hook's fixed 4-byte emission, so it's patched manually;
; JOYPAD_HOOK_VARIANT is declared manually to match what joypad_hook would
; have set.
DEF JOYPAD_HOOK_VARIANT EQU 0
    free_space_rom0 $3ef8, $3ef8 + $003b

    patch_rom $00, $0290
    call relocated_read_from_joypad
    end_patch


; save/load state
    free_space_romx $0001, $7000, $7000 + $0315
