# Game configs

One file per game — see [docs/HOW-TO.md](../docs/HOW-TO.md) for how to add
one, starting from [`_template.asm`](_template.asm). Two configs
(`Pokemon - Crystal Version (USA, Europe)*.gbc.asm`) use the batteryless and
rtc features; the rest use savestates.

202 of the 261 savestates configs use the savestates macro API
(`savestates_joypad_hook`, `savestates_joypad_hook_banked`,
`savestates_vblank_hook`, `free_space_rom0`/`_b`/`_c`, `free_space_romx`,
`savestates_payload_in_rom0`/`_b`) instead of hand-written `SECTION`
blocks — see [../docs/CONFIG-KEYS.md](../docs/CONFIG-KEYS.md) and
[../src/features/savestates/macros.asm](../src/features/savestates/macros.asm).

## Remaining raw-style configs (59)

These still place their sections by hand and `INCLUDE
"src/features/savestates/legacy_includes.asm"` directly — fully
functional (covered by `tools/test.sh`), just not yet converted. Each
falls into one of a few shapes the mass migration
(`tools/migrations/01-04-*.py`) doesn't cover, because converting them
risks changing the emitted bytes rather than just the source
representation:

- **Non-default nop padding**: the tail hook is `call
  relocated_read_from_joypad` followed by 0, 2, or 4 `nop`s instead of
  the usual 1 (e.g. Castelian, Dig Dug, Kenyuu Densetsu Yaiba). Needs
  `savestates_joypad_hook` to accept an explicit nop count.
- **Combined single ROM0 region**: `relocated_read_from_joypad.asm` is
  `INCLUDE`d directly inside the payload `SECTION` instead of a separate
  region (e.g. Batman (JU), Hook, Megaman IV/V). The macro API can
  express this (`free_space_rom0` + `savestates_payload_in_rom0`), but
  the automatic placement order (relocated read, then payload) differs
  from these files' original byte order (payload marker, then relocated
  read) — same behavior, different bytes, so it needs its own
  golden-verified batch rather than folding into an existing script.
- **Banked-hook non-standard endings** (21 configs): the copied joypad
  routine ends in something other than plain `ret` or `jp ADDR` — `ei`,
  `ld a,[joypad]`, a custom "joypad read call" wrapper, or similar
  (Battletoads, Cool Spot, Donkey Kong Land 1-3, Mr Nutz, Star Wars,
  Super Mario Land, Xenon 2, …).
- **vblank-hook variants** (7 configs): `original_vblank_handler_pushes`
  (a game-specific inline macro; Oracle of Seasons, Rolan's Curse II) or
  a payload shape script 04 doesn't match (Dragon Heart, International
  Superstar Soccer, both Pac-Man releases, Sabrina).
- **Genuine one-offs**: Hammerin' Harry and Super Off Road (custom
  push/pop-wrapped joypad read, handled specially during the reset_ram
  conversion already), Burai Fighter Deluxe (three-part joypad hook:
  `_part_1`/`_part_2` patched into two ROM0 addresses *plus* a third,
  separate ROMX call site into a differently-named entry label — more
  than `savestates_joypad_hook_banked_split` was designed for),
  Kirby's Dream Land 2 (joypad read driven from the vblank *vector*
  directly, not the vblank *handler*), and a handful more with
  idiosyncratic section layouts (Contra, Legend of Zelda Oracle
  series/Link's Awakening variants, Wario Land SML3 [!], Ms. Pac-Man,
  R-Type II, Robocop/Robocop 2, Sagaia, Shanghai Pocket, Smurfs
  Nightmare, Tiny Toon Adventures).

None of this blocks using or extending the framework — new games should
always be written directly against the macro API (see `_template.asm`);
this list is a punch list for finishing the migration, not a defect list.
