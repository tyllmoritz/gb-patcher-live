; ------------------------------------------------------------------------------
; SPDX-FileCopyrightText: 2024 Marc Robledo
; SPDX-FileCopyrightText: 2026 Robin Bertram
; SPDX-License-Identifier: MIT
; ------------------------------------------------------------------------------
;
; Pokemon Red++ v3.0.2 (snowy, hard) — pokered-lineage ROM hack
;
; ROM "Pokemon - Red++ (v3.0.2) (snowy) (hard).gbc"
; SHA1 12cf0a63c6ddcfc4ba0dcb8c7497f8ab84ac130a
;
; builds "batteryless/Pokemon - Red++ (v3.0.2) (snowy) (hard) (batteryless).gbc" with _BATTERYLESS
;
; ------------------------------------------------------------------------------

; game properties
DEF sram_size_32kb EQU 1
DEF current_rom_bank EQU $ffb8         ; H_LOADEDROMBANK (pokered lineage)
DEF flash_data_bank EQU $40             ; first bank past the 1MB ROM

; free space in the original ROM/RAM
    free_space_rom0 $3ed0, $4000        ; zero padding after the game's
                                        ; bank-switch code ends at $3ecc
                                        ; (xxd-verified)
    free_space_romx $3f, $4000, $8000   ; whole bank is zero padding (xxd-verified)
; WRAM window from the pre-framework port (found with a debugger there);
; sized to the feature's current footprint — the build asserts on overflow
    free_space_wram $d000, $d000 + $ab, $3

; the entry at $0100 is a bare `jp $00be` (no leading nop) — the 3-byte
; entry hook at $0100 covers it exactly
    entry_point $00be

; the save site is not a call: the 3-byte `ld [wHaltAudio], a` right after
; SaveSAVtoSRAM completes is replaced and replayed in the generated stub
    save_hook_inline $1c, $6945
        ld [$c0fe], a                   ; original: ld [wHaltAudio], a
    end_save_hook_inline
