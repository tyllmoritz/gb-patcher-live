; md5 fb04c5e00adcbf031bd1971e68a6bca5

; ROM "Trip World DX.gbc"
; builds "Trip World DX (savestates).gbc" with _SAVESTATES


; config
DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_GBC
DEF current_rom_bank EQU $ff9b
DEF SRAM_SIZE EQU CART_SRAM_8KB
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC5_RAM


; joypad
DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c

    free_space_rom0 $0062, $0062 + $40

    joypad_hook $26b2


; save/load state
    free_space_romx $0002, $6B61, $6B61 + $0295
