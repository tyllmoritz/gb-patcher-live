; md5 fb04c5e00adcbf031bd1971e68a6bca5

; ROM "Trip World DX.gbc"
; builds "savestates/Trip World DX (savestates).gbc" with _SAVESTATES


; config
DEF is_cgb EQU 1
DEF current_rom_bank EQU $ff9b
DEF game_uses_save_ram EQU 1
DEF uses_mbc5 EQU 1


; joypad
DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c

    free_space_rom0 $0062, $0062 + $40

    savestates_joypad_hook $26b2


; save/load state
    free_space_romx $0002, $6B61, $6B61 + $0295
