; md5 f59dbce4cf5b51a5241806e1b35301fb

; ROM "Gremlins 2 - The New Batch (W) [!].gb"
; builds "Gremlins 2 - The New Batch (W) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $0062, $0062 + $40
    joypad_relocated_read_in_rom0_c

    joypad_hook $1f98


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $2b53, $2b53 + $0220
    savestates_payload_in_rom0_b
