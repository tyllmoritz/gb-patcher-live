; md5 f59dbce4cf5b51a5241806e1b35301fb

; ROM "Gremlins 2 - The New Batch (W) [!].gb"
; builds "savestates/Gremlins 2 - The New Batch (W) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ff8b
DEF joypad_2 EQU $ff8c


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00a3, $00a3 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_c $0062, $0062 + $40
    savestates_relocated_read_in_rom0_c

    savestates_joypad_hook $1f98


;*******************
;* save/load state *
;*******************

    free_space_rom0_b $2b53, $2b53 + $0220
    savestates_payload_in_rom0_b
