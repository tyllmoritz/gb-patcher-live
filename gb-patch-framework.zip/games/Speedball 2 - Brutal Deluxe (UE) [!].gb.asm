; md5 d7fb01dec29a52de74e5b335b8619e0a

; ROM "Speedball 2 - Brutal Deluxe (UE) [!].gb"
; builds "savestates/Speedball 2 - Brutal Deluxe (UE) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $ffd2
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $ffd5


;*************
;* reset ram *
;*************

    entry_point $0b89
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $001d, $001d + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $0e09


;*******************
;* save/load state *
;*******************

    free_space_romx $0007, $64C2, $64C2 + $02a0
