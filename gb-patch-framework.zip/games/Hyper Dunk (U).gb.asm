; md5 9add23b6cf3a5b76305192da693dfd21

; ROM "Hyper Dunk (U).gb"
; builds "savestates/Hyper Dunk (U) (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $c05f
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $c024


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00ed, $00ed + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    savestates_joypad_hook_banked $00, $0393, $03c4


;*******************
;* save/load state *
;*******************

    free_space_romx $0001, $66D6, $66D6 + $02a0
