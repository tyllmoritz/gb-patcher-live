; md5 f629f0b6d156bec6acb9e6b9da4ad4e3

; ROM "Addams Family, The (U) [!].gb"
; builds "savestates/Addams Family, The (U) [!] (savestates).gb" with _SAVESTATES


;**********
;* config *
;**********

DEF joypad EQU $dc80
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $ff8a


;*************
;* reset ram *
;*************

    entry_point $0150
INCLUDE "src/features/savestates/reset_ram.asm"
    free_space_rom0 $00b7, $00b7 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0077, $0077 + $40
    savestates_relocated_read_in_rom0_b

    savestates_joypad_hook $1a8a


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $7CD5, $7CD5 + $0220
