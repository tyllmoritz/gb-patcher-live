; md5 f629f0b6d156bec6acb9e6b9da4ad4e3

; ROM "Addams Family, The (U) [!].gb"
; builds "Addams Family, The (U) [!] (savestates).gb" with _SAVESTATES
DEF CARTRIDGE_TYPE EQU CART_ROM_MBC1
DEF SRAM_SIZE EQU CART_SRAM_NONE


;**********
;* config *
;**********

DEF GB_COMPATIBILITY EQU CART_COMPATIBLE_DMG
DEF joypad EQU $dc80
DEF swap_joypad EQU 1
DEF current_rom_bank EQU $ff8a


;*************
;* reset ram *
;*************

    entry_point $0150
    free_space_rom0 $00b7, $00b7 + $F
    on_boot_inline reset_ram



;***************
;* joypad read *
;***************

    free_space_rom0_b $0077, $0077 + $40
    joypad_relocated_read_in_rom0_b

    joypad_hook $1a8a


;*******************
;* save/load state *
;*******************

    free_space_romx $0003, $7CD5, $7CD5 + $0220
